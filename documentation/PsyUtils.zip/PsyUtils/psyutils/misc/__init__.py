"""
Misc submodule
---------------

This submodule contains miscellaneous functions.

----------
"""

from ._misc_funs import (fixation_cross)

__all__ = ['fixation_cross']
