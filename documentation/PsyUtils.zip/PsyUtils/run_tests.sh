#!/bin/bash

# run tests for psyutils, in both python 2 and 3 (assuming you're in the package root directory).
nosetests -v --nocapture
read -p "That was Python 2. Press [Enter] key to run tests under Python 3..."
nosetests-3.3 --py3where=./ -v --nocapture
