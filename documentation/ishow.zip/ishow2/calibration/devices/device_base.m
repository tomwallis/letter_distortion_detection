classdef device_base < handle
% classdef device_base < handle
%
% The base-class for all measurement devices. Not meant to be used
% directly.
%
% Currently implemented:
%  - spectrometer
%  - photometer
% 

    properties( SetAccess = protected )
        name;              % A name to identify the object
        port;              % A serial-port object for communication
        format;            % The data-format returned by the serial-port
        timeout = 2;       % How long to wait for response
        verbose = true;    % A flag to signal verbosity
    end


    methods
        
        function obj = device_base(verbose, timeout)
        %function device_base(verbose, timeout)
        %
        % Return a device_base. This constructor should never be called
        % directly, device_base only defines the behavior shared by all
        % devices, but does not do anything meaningful on its own.
        %
        % parameters:
        %  verbose - if true, print information to screen while running
        %            defaults to true
        %  timeout - time in seconds to wait for device to respond
        %            defaults to 2
        %
            if nargin < 1, verbose = true; end
            if nargin < 2, timeout = 2; end
            obj.verbose = verbose;
            obj.timeout = timeout;
        end
        
        
        function set_timeout(obj, timeout)
        %function set_timeout(obj, timeout)
        %
        % Set the reading timeout
        %
            obj.timeout = timeout;
            set(obj.port, 'Timeout', obj.timeout);
        end

        
        function write(obj, s)
        %function write(obj, s)
        %
        % Send string message s to the device
        %
            if ~isstr(s)
                error('You can only send string-messages to this device');
            end
            fprintf(obj.port, s);
        
        end
        
        
        function s = read(obj)
        %function s = read(obj)
        %
        % Return the raw-string read from the serial-port. Throw an error if
        % waiting longer than obj.timeout.
        %
            tic;
            s = fscanf(obj.port);
            t = toc;
            if t > obj.timeout
                error('%s timed out after %d seconds', obj.name, obj.timeout);
            end
        end
        
        function sout = talk(obj, sin)
        %function sout = talk(obj, sin)
        %
        % Send a string to the device and return the response.
        %
            obj.write(sin);
            sout = obj.read();
        end

        
        function delete(obj)
        %function delete(obj)
        %
        % Close the port before deleting the object
        %   
            fclose(obj.port);
            delete@handle(obj);
        end
        
        

    
    end
    
    methods (Abstract)
        measure(obj)
    end
    
end
