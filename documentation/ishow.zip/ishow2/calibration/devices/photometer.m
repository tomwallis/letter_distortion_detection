classdef photometer < device_base
% classdef photometer < device_base
%
% The interface object for a Gamma-Scientific photometer

    methods

        function obj = photometer(varargin)
        %function obj = photometer(varargin)
        %
        % Return a photometer object. Check device_base for arguments that
        % can be passed. Any arguments passed to photometer are directly
        % passed to device_base.
        %
            if nargin < 1, verbose = true; end
            if nargin < 2, timeout = 2; end
            
            obj = obj@device_base(varargin{:});
            obj.name = 'photometer';
            obj.port = serial('/dev/ttyS470', ...
                              'BaudRate', 38400, ...
                              'Terminator', 'CR/LF');
            obj.format = '';
            obj.set_timeout(obj.timeout);
            fopen(obj.port);
        end
        
        
        function s = read(obj)
        %function s = read(obj)
        %
        % Return a raw-string read from the serial port.
        % 
        % The photometer always returns a CR/LF before any output, therefore
        % we read it twice.
        %
        % If we wait longer than 2 seconds for a response, the reading has
        % timed out, and there was no input from the photometer.
        %
            
            % Read the first CR/LF and check if a message exists in the buffer
            s = read@device_base(obj);
            if ~strcmp(s, sprintf('\r\n'))
                error(['Photometer message did not start with CR/LF']);
            end
            % Read the message and trim the second CR/LF from the string
            s = read@device_base(obj);
            if strcmp(s(end-1 : end), sprintf('\r\n'))
                s = s(1 : end-2);
            else
                error(['Photometer message did not end with CR/LF']);
            end
        end
        
        
        function data = measure(obj)
        %function data = measure(obj)
        %
        % Return a brightness reading from the photometer
        %
            % Tell photometer to give us a reading
            obj.write('REA');
            
            % Read data and format it
            s = obj.read();
            data = str2num(s);        
        end
        
function data = measure_n(obj, n)
        %function data = measure_n(obj, n)
        %
        % Measure n points.
        % If n is a positive number (or 0) it will take that many
        % measurements and return. If n is negative (or NaN or Inf) it will
        % keep recording untill the user presses the spacebar. Spacebar can
        % also be used to interrupt positively numbered measurements.
        % 
            % Prepare variables
            n = floor(n);
            % msg_len = 0;
            % % if obj.verbose
            % %     fprintf('Hold spacebar to interrupt measurement\n');
            % % end
            data = zeros(n, 1);
            obj.write(sprintf('REA %d', n));
            fscanf(obj.port);
            % Run measurement loop
            for i = 1 : n
                % if obj.verbose
                %     msg = sprintf('Measurement %d of %d', i, n);
                %     fprintf(repmat('\b', 1, msg_len));
                %     fprintf(msg);
                %     msg_len = numel(msg);
                % end
                data(i) = (str2num(fscanf(obj.port)));
                
                % data(end + 1) = obj.measure();
                % i = i + 1;
                % [~,~,codes] = KbCheck();
                % if codes(space_i)
                %     break
                % end
            end
            % if obj.verbose
            %     fprintf('\n')
            % end
        end
        
        
            
       
    end
end
