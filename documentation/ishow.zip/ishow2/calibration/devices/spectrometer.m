classdef spectrometer < device_base
% classdef spectrometer < device_base
%
% The interface to the spectrometer

    properties

    methods

        
        function obj = spectrometer(verbose)
        %function obj = spectrometer(verbose)
        %
        % docstring
            if nargin > 0
                obj.verbose = verbose;
            end
            obj.name = 'spectrometer';
            obj.port = serial('/dev/ttyCS2000',...
                              'Timeout', 2);
            fopen(obj.port);
            obj.set_remote(true);
        end
        
        
        function set_remote(obj, flag)
        %function set_remote(obj, flag)
        %
        % Switch remote mode on or off, if flag is true, remote is turned
        % on, if flag is false, it is turned off again.
        %
            if flag
                s = 'RMTS,1'
            else
                s = 'RMTS,0';
            end
            obj.write(s);
            obj.check();
        end
        
        
        function good = check(obj, err)
        %function good = check(obj, err)
        %
        % Check if an instruction arrived correctly, this involves reading a
        % string from the device. If all went well, the string will start
        % with 'OK' and check will return true.
        % If there was a problem and 'err' is true, check will throw an
        % error. Otherwise it will return false but not throw an
        % error. 'err' defaults to true.
        %
            if nargin < 2
                err = true;
            end
            
            s = obj.read();
            if ~strcmp(s(1:2), 'OK')
                if err
                    error('Spectrometer failed with error: %s', err);
                else
                    good = false;
                end
            else
                good = true;
            end
        end
        
        
        function delete(obj)
        %function delete(obj)
        %
        % Turn of remote-mode, then continue deleting via device_base
        %
            obj.set_remote(false);
            delete@device_base(obj);
        end
        
    end
end
