function gamma_calibration(monitor,Nmeasures,savePath)
% function claibration(monitor,Nmeasures,savePath)
% this function creates a new calibration which is automatically checked
% and saved
% monitor must! be the monitor you want to calibrate
% in Nmeasures you may change the number of measurements to do(default=250)
% in savePath you may specify a path to save the files at. If you don't the
% defaultpath home/data/caibration is used.

if nargin<1 
    error('you have to specify a monitor!!')
end

if nargin<2
    Nmeasures=250;
end

if nargin<3
    savePath='/home/data/calibration';
end

saveFile=fullfile(savePath,monitor,[monitor,standard_now]);
% saveFile_cd=fullfile(savePath,monitor,[monitor,'_cdm2_',standard_now]);

if exist(saveFile,'file')==2                          % 2=non-matlab-file
    error('file %s does exist already!', saveFile)    % stop if already
end

if not( exist(savePath,'file')==7 )                   % 7=path
    error('path %s does not exist!', savePath)        % stop if not writable
end

%fixed parameters
%testvalues
input = linspace(0,1,256)';
%input = linspace(0,1,2^12)';                 % Test 12 Bit color resolution

linearClut=linspace(0,1,2^14)';

%% Open screen and photometer
win = window(monitor, 'bg_color', input(1),'clut',linearClut);
phot = photometer();
phot.talk('RNG 6');
phot.talk('SRT250');


%% Measure gamma curve
pause(3);


luminance_uncalibrated = zeros(length(input), Nmeasures);
for i = 1 : length(input)
    win.bg_color = input(i);
    win.clear(true);
    pause(0.2)
    luminance_uncalibrated(i,:)=phot.measure_n(Nmeasures);
    disp(['measurement',int2str(i),'of', int2str(length(input)), 'complete']);
end


clearvars win


%% calculate new clut

measurement=mean(luminance_uncalibrated,2);
maxLum=max(measurement)
% save(saveFile_cd,'input','measurement','maxLum')    % as is: I want cd/m^2

% unscale
measurement=(measurement-min(measurement))/(max(measurement)-min(measurement));

clut = spline(measurement,input,linspace(0,1,2^14)');

save(saveFile,'input','measurement','maxLum')

%% check measurement by remeasuring
pause(3);

win = window(monitor, 'bg_color', input(1),'clut',clut);

luminance_calibrated = zeros(length(input), Nmeasures);
for i = 1 : length(input)
    win.bg_color = input(i);
    win.clear(true);
    pause(0.2)
    luminance_calibrated(i,:)=phot.measure_n(Nmeasures);
    disp(['TESTmeasurement',int2str(i),'of', int2str(length(input)), 'complete']);
end


clearvars win

%% plot the two measurement curves

figure;

subplot(1,2,1)
title('uncalibrated measures');
plot(input,mean(luminance_uncalibrated,2),'.');
hold on
gamma=spline(input,maxLum*measurement,linspace(0,1,2^14));
plot(linspace(0,1,2^14),gamma,'k');
xlabel('input')
ylabel('luminance[cd/m^2]')

subplot(1,2,2)

title('calibrated measures');
plot(input,mean(luminance_calibrated,2),'.');
line=polyfit(input,mean(luminance_calibrated,2),1);
hold on 
plot(linspace(0,1,2^14),polyval(line,linspace(0,1,2^14)),'k')
xlabel('input')
ylabel('luminance[cd/m^2]')

end