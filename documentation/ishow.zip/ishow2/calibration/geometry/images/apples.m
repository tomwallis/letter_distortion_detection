function img = apples(screen_size, apple_size, bg, fg)
%function img = apples(screen_size, apple_size, bg, fg)
%
% Create a grid of 'apple-symbol' images for screen-testing purposes.
%
% parameters:
%  screen_size: size of screen in pixels
%  apple_size: size of whitespace inside 1 'block' of symbol
%  bg: background color, defaults to black
%  fg: forerground color, defaults to white
%

%% Parse arguments
if nargin < 2
    error('Please provide at least "screen_size", and "apple_size"');
end
if nargin < 3, bg = 0; end
if nargin < 4, fg = 1; end

%% Calculate dependent variables
symbol_size = 5 * (apple_size + 1);
n_symbols = floor((screen_size - 1) / symbol_size);
grid_size = n_symbols  * symbol_size + 1;
margins = [ceil(mod(screen_size(1) - 1, symbol_size) / 2), ...  % margins: LRTB
           floor(mod(screen_size(1) - 1, symbol_size) / 2), ...
           ceil(mod(screen_size(2) - 1, symbol_size) / 2), ...
           floor(mod(screen_size(2) - 1, symbol_size) / 2)];

%% Define index-rules

% Utility variables:
strt = margins(1) + 1;
w = grid_size(1);
stop = strt + w - 1;
nil = zeros(1, screen_size(1));
pad_l = zeros(1, margins(1));
pad_r = zeros(1, margins(2));
pad = @(x) [pad_l x 1 pad_r];

%% Initialize line rules

% Full horizontal line
whole_line = nil;
whole_line(strt : stop) = 1;

% Only the pixels of the vertical lines
emptiest = nil;
emptiest(strt : symbol_size : stop) = 1;

% The outside edges of the symbols
a = zeros(1, apple_size);
b = ones(1, apple_size + 2);
sym_out_edge = pad(repmat([1 a b a b a], 1, n_symbols(1)));

% The lines through the outside blocks of the symbol
sym_out_block = pad(repmat([1 a], 1, n_symbols(1) * 5));

% The border between the outside blocks and inside blocks
b = ones(1, apple_size * 3 + 4);
sym_in_edge = pad(repmat([1 a b a], 1, n_symbols(1)));

% Inside the central block of the symbol
b = [1 a 0 a 1 a 1 a 0 a];
sym_in_block = pad(repmat(b, 1, n_symbols(1)));


%% Create image

row = [whole_line; ...
       repmat(emptiest, apple_size, 1); ...
       sym_out_edge; ...
       repmat(sym_out_block, apple_size, 1); ...
       sym_in_edge; ...
       repmat(sym_in_block, apple_size, 1); ...
       sym_in_edge; ...
       repmat(sym_out_block, apple_size, 1); ...
       sym_out_edge; ...
       repmat(emptiest, apple_size, 1)];

img_map = [zeros(margins(3), screen_size(1)); ...
           repmat(row, n_symbols(2), 1); ...
           whole_line; ...
           zeros(margins(4), screen_size(1))];

img = zeros(screen_size(2), screen_size(1));
img(img_map == 0) = bg;
img(img_map == 1) = fg;