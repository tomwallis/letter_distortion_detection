function img = color(screen_size, color, framearound)
%function img = color(screen_size, color, framearound)
%
% Returns a grey-value image used for screen-testing purposes
%
% parameters:
%   screen_size - size of screen in pixels
%   mycolor     - grey-value 0(black) .. 1(white)
%   framearound blacks out except for area  x1..x2 X y1..y2;  #1<#2
%

%% Setup parameters

% WHITE = 1; BLACK = 0;

%% Parse arguments

if nargin < 1, error('Please provide a "screen_size [x y]"'); end
if nargin < 2, color = 1; end
if nargin < 3, framearound = [-1 -1 -1 -1]; end

%% Calculate dependent variables

w = screen_size(1);
h = screen_size(2);

%% Make image

img = color * ones(h, w);

if framearound(1) > 0 && framearound(1) > 0 && framearound(1) > 0 && framearound(1) > 0
    bg = 0;    % black
    % black out borders around frame
    img(1:framearound(2), :) = bg;
    img(framearound(4):h, :) = bg;
    img(:, 1:framearound(1)) = bg;
    img(:, framearound(3):w) = bg;
else
    % warning( 'no frame blocked' )
end


