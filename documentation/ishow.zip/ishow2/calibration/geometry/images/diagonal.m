function img = diagonal(screen_size, bg, fg)
%function img = diagonal(screen_size, bg, fg)
%
% Create two in the center intersecting diagonals for screen-testing (geometry) purposes
%
% parameters:
%  screen_size: size of screen in pixels
%  bg: background color, defaults to black
%  fg: forerground color, defaults to white
%
% img: (1,1) is upper left corner, x down ??

%% Parse arguments
if nargin < 1
    error('Please provide at least "screen_size"');
end
if nargin < 2, bg = 0; end
if nargin < 3, fg = 1; end

%% Create image
% due to an artefact, top most line #1 is not displayed. use #2 instead.
img = ones(screen_size(2), screen_size(1)) * bg;
if screen_size(1) > screen_size(2)
    for x = drange(1:screen_size(2)) 
        y = 1 + round( (x-1)/screen_size(2)*screen_size(1) );
        img(x,y) = fg;
        img(screen_size(2)-x+1,y) = fg;
    end
    img(1,1:4:end) = fg;
    img(screen_size(2),1:4:end) = fg;
    img(1:5:end,1) = fg;
    img(1:5:end,screen_size(1)) = fg;
else
    for y = drange(1:screen_size(1)) 
        x = 1 + round( (x-1)/screen_size(1)*screen_size(2) );
        img(x,y) = fg;
        img(x,screen_size(1)-y+1) = fg;
    end
    img(1,1:4:end) = fg;
    img(screen_size(2),1:4:end) = fg;
    img(1:5:end,1) = fg;
    img(1:5:end,screen_size(1)) = fg;
end
