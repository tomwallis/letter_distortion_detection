function img = dot_grid(screen_size, dot_dist, bg, fg)
%function img = line_grid(screen_size, line_size, ori, bg, fg)
%
% Create a grid of dots for screen-testing (geometry) purposes
%
% parameters:
%  screen_size: size of screen in pixels
%  dot_dist: distance of dots
%    if >=10, then dot_size = 2, else 1
%  bg: background color, defaults to black
%  fg: forerground color, defaults to white
%
% img: (1,1) is upper left corner, x down ??

%% Parse arguments
if nargin < 2
    error('Please provide at least "screen_size", and "dot_dist"');
end
if nargin < 3, bg = 0; end
if nargin < 4, fg = 1; end

%% Create image

img = ones(screen_size(2), screen_size(1)) * bg;
center_x = 1+floor(screen_size(1)/2);                        % center pattern
center_y = 1+floor(screen_size(2)/2);
start_x = mod( center_x, dot_dist );                       % Start of Pattern
start_y = mod( center_y, dot_dist );
if start_x == 0 
    start_x = dot_dist;
end
if start_y == 0 
    start_y = dot_dist;
end
img(start_y:dot_dist:screen_size(2), start_x:dot_dist:screen_size(1)) = fg; 
img(center_y,center_x+2) = (fg+bg)/2;                        % show center
img(center_y,center_x-2) = (fg+bg)/2;                        % show center
img(center_y+2,center_x) = (fg+bg)/2;                        % show center
img(center_y-2,center_x) = (fg+bg)/2;                        % show center
%if( dot_dist >= 10)
%   img(start_y+1:dot_dist:screen_size(2), start_x:  dot_dist:screen_size(1)) = fg;
%   img(start_y:  dot_dist:screen_size(2), start_x+1:dot_dist:screen_size(1)) = fg;
%   img(start_y+1:dot_dist:screen_size(2), start_x+1:dot_dist:screen_size(1)) = fg;
%end
