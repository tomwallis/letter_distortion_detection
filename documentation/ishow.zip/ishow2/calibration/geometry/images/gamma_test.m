function img = gamma_test(screen_size, n_rows, gamma_range)
%function img = gamma_test(screen_size, n_rows, gamma_range)
%
% Returns a complicated image used for screen-testing purposes
%
% The resulting image will be split into a number of rows (n_rows). Each row
% will alternating blocks of black-white stripes next to a uniform gray
% field. Between each row the gray-value of the field changes.
%
% parameters:
%   screen_size - size of screen in pixels
%   n_rows - amount of rows to create for comparison
%   gamma_range - beginning and ending value for gamma
%

%% Setup parameters

INSIDE_MARGIN = 5;
GRAY_LINE_WIDTH = 4;
SIDE_MARGIN = 60;
BLACK = 0;
WHITE = 1;
GRAY = 0.5;
N_BOX_ROW = 12;

%% Parse arguments

if nargin < 1
    error('Please provide a "screen_size" parameter')
end
if nargin < 2, n_rows = 8; end;
if nargin < 3, gamma_range = [2.6 1.9]; end

%% Calculate dependent variables

row_h = floor((screen_size(2) - GRAY_LINE_WIDTH) / n_rows);
boxes_w = screen_size(1) - 2 * (GRAY_LINE_WIDTH + SIDE_MARGIN);
extra_h = screen_size(2) - row_h * n_rows - GRAY_LINE_WIDTH;
pad_h = @(x) [false(1, ceil(extra_h / 2)) x false(1, floor(extra_h / 2))];

img = ones(screen_size(2), screen_size(1)) * BLACK;

%% Create gray lines

% Extra space
a = ~(pad_h(true(1, row_h * n_rows + GRAY_LINE_WIDTH)));
img(a, :) = GRAY;

% Row-outlines
a = true(1, GRAY_LINE_WIDTH);
b = false(1, row_h - GRAY_LINE_WIDTH);
gray_idx = pad_h([repmat([a b], 1, n_rows), a]);
img(gray_idx, :) = GRAY;
img(:, 1 : GRAY_LINE_WIDTH) = GRAY;
img(:, end - GRAY_LINE_WIDTH - 1 : end) = GRAY;


%% Create boxes

box_h = row_h - GRAY_LINE_WIDTH - 2 * INSIDE_MARGIN;
box_w = floor(boxes_w / N_BOX_ROW) - 1;
extra_w = (screen_size(1) - N_BOX_ROW * box_w) + 1;

line_box = zeros(box_h, box_w);
line_box(1:2:end, :) = 1;

box_start_l = floor(extra_w / 2);
gammas = linspace(gamma_range(1), gamma_range(2), n_rows);
for i = 1 : n_rows
    box_top = ceil(extra_h / 2) + ...
              (GRAY_LINE_WIDTH + INSIDE_MARGIN) * i + ...
              (box_h + INSIDE_MARGIN) * (i - 1) + 1;
    box_solid = ones(box_h, box_w) * (0.5 ^ (1 / gammas(i)));
    box_is_stripey = true;
    
    for j = 1 : N_BOX_ROW
        box_left = box_start_l + (box_w + 1) * (j - 1);
        if box_is_stripey
            box = line_box;
        else
            box = box_solid;
        end
        box_is_stripey = ~box_is_stripey;
        
        img(box_top : box_top + box_h - 1, box_left : box_left + box_w - 1) = box;
    end
end
