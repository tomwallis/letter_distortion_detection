function img = line_grid(screen_size, line_size, bg, fg)
%function img = line_grid(screen_size, line_size, ori, bg, fg)
%
% Create a grid of lines for screen-testing purposes
%
% parameters:
%  screen_size: size of screen in pixels
%  line_size: width of the line in pixels
%  bg: background color, defaults to black
%  fg: forerground color, defaults to white
%

%% Parse arguments
if nargin < 2
    error('Please provide at least "screen_size", and "line_size"');
end
if nargin < 3, bg = 0; end
if nargin < 4, fg = 1; end

%% Create image

img = ones(screen_size(2), screen_size(1)) * bg;
indcs = repmat([true(1, line_size) false(1, line_size)], ...
               1, ceil(screen_size(1) / (line_size * 2)));
indcs = indcs(1 : screen_size(1));
img(:, indcs) = fg;

