function img = noisewhite(screen_size, bg, fg, new, framearound)
%function img = noisewhite(screen_size[x y], bg, fg, new, framearound[x1 y1 x2 y2])
%
% Create a new / or use the standard white noise pattern
%
% parameters:
%  screen_size: size of screen in pixels
%  bg: background color, defaults to black
%  fg: forerground color, defaults to white
%  new: create and use a new random white noise image, defaults to FASLE
%  framearound blacks out except for area  x1..x2 X y1..y2;  #1<#2
% img: (1,1) is upper left corner

%% Parse arguments
if nargin < 1
    error('Please provide at least "screen_size"');
end
if nargin < 2, bg = 0; end
if nargin < 3, fg = 1; end
if nargin < 4, new = 0; end
if nargin < 5, framearound = [-1 -1 -1 -1]; end

%% Create image
img = ones(screen_size(2), screen_size(1)) * bg;
if new == 1
    scale = fg-bg;
    offset = bg;
    for x = drange(1:screen_size(2)) 
        for y = drange(1:screen_size(1)) 
            img(x,y) = offset + scale * rand;
        end
    end
else
    pseudodim = 10000*screen_size(1)+screen_size(2);
    % load fixed image; variable called "img" already
    switch pseudodim
        case 19201200
            load('noisewhite_1920x1200.mat');          % ViewPixx
        case 12800800
            load('noisewhite_1280x800.mat');           % CRT
        case 16001200
            load('noisewhite_1600x1200.mat');          % CRT
        otherwise
            error('no image of the requested size available, yet');
    end
end

if framearound(1) > 0 && framearound(2) > 0 && framearound(3) > 0 && framearound(4) > 0
    % black out borders around frame
    if framearound(2) > 1 
        img(1:framearound(2)-1, :) = bg;
    end
    if framearound(4) < screen_size(2) 
        img(framearound(4)+1:screen_size(2), :) = bg;
    end
    if framearound(1) > 1
        img(:, 1:framearound(1)-1) = bg;
    end
    if framearound(3) < screen_size(1)
        img(:, framearound(3)+1:screen_size(1)) = bg;
    end
else
    % warning( 'no frame blocked' )
end
