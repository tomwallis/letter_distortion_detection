function img = rectangles(screen_size, bar_sep)
%function img = rectangle(screen_size, bar_sep)
%
% Returns a complicated image used for screen-testing purposes
%
% The resulting image will consist of rows of different gray-values
% containing white and black blocks that can show bleeding-through effects.
%
% parameters:
%   screen_size - size of screen in pixels
%

%% Setup parameters

WHITE = 1; BLACK = 0;
FIELD_MARGIN_B = 10;              % space between gray-fields
FIELD_VALS = .75:-.25:.25;         % gray-values of fields
FIELD_ROWS = length(FIELD_VALS);  % amount of gray-fields
FIELD_MARGIN_W = 20;              % space between gray-border and first box

BOX_MARGIN_V = 3;                 % space between boxes vertically
BOX_MARGIN_H = 30;                % space between boxes horizontally
BOX_MARGIN_SIDES = 100;           % space between sides and start and end of boxes
BOX_COLS = 2;                     % number of columns
BOX_VALS = [WHITE WHITE BLACK BLACK WHITE WHITE BLACK BLACK WHITE WHITE];
    % box color values
BOX_ROWS = length(BOX_VALS);      % number of box rows per field

%% Parse arguments

if nargin < 1
    error('Please provide a "screen_size"');
end
if nargin > 1
    BOX_MARGIN_V = bar_sep;
end



%% Calculate dependent variables

w = screen_size(1);
h = screen_size(2);

field_h = floor((h - (FIELD_ROWS - 1) * FIELD_MARGIN_B) / FIELD_ROWS);
%f_xtra_h = h - (field_h * FIELD_ROWS) - (FIELD_MARGIN_B * (FIELD_ROWS - 1));
box_area_h = floor(field_h - (2 * FIELD_MARGIN_W));
box_h = floor((field_h - 2 * FIELD_MARGIN_W ...
                       - BOX_MARGIN_V * (BOX_ROWS - 1)) / BOX_ROWS);
box_w = floor((w - 2 * BOX_MARGIN_SIDES - (BOX_COLS - 1) * BOX_MARGIN_H) / BOX_COLS);


%% Draw image

img = BLACK * ones(h, w);

for i = 1 : FIELD_ROWS
    % draw fields
    field_top = 1 + ((field_h + FIELD_MARGIN_W) * (i - 1));
    img(field_top : field_top + field_h - 1, :) = FIELD_VALS(i);
    
    for j = 1 : BOX_COLS
        box_left = BOX_MARGIN_SIDES + (j - 1) * (box_w + BOX_MARGIN_H);
        for k = 1 : BOX_ROWS
            box_top = field_top + FIELD_MARGIN_W + ...
                      (k - 1) * (box_h + BOX_MARGIN_V);
            box = ones(box_h, box_w) * BOX_VALS(k);
            img(box_top : box_top + box_h - 1, ...
                box_left : box_left + box_w - 1) = box;
        end
    end
end

