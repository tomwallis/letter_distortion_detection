function mof_noise_white(win)
%function mof_noise_white(win)
%
% Run the geometry images from the list TO_RUN in images subdirectory
%

%% Setup parameters

IMG_DIR = 'images';
TO_RUN = {@(res) diagonal(res, 0, 0.6), ...
          @(res) color(res, 1, [897 547 1023 653]), ...
          @(res) noisewhite(res, 0, 1, 0, [897 547 1023 653]), ...
          @(res) color(res,0.2)};

%% Get window handle

if nargin < 1
    % NOTE: This is optimized for my local setup fix this when migrating downstairs.
    % win = window('debug', 'rect', [2560 0 1680 + 2560  1050]);
    win = window('lcd_gray')
end


%% Loop through functions

for i = 1 : length(TO_RUN)
    im_gen = TO_RUN{i};
    img = im_gen(win.resolution);
    tex = win.make_texture(img);
    win.draw(tex, 1, [0 0 win.resolution(1) win.resolution(2)]);
    win.flip();
    waitforbuttonpress;
end
