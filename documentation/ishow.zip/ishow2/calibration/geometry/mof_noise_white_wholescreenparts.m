function mof_noise_white(win)
%function mof_noise_white(win)
%
% Run the geometry images from the list TO_RUN in images subdirectory
%

%% Get window handle
if nargin < 1
    % NOTE: This is optimized for my local setup fix this when migrating downstairs.
    % win = window('debug', 'rect', [2560 0 1680 + 2560  1050]);
    win = window('lcd_gray')
end

%%% PS: imwrite(img, 'image.png');    % schreibt Pixelgenau das Array img raus.

%% Loop through functions
frame_width = 126;
frame_height = 106;
frame_overlap = 3;                                    % each side -> 2x3 total
resolution = win.resolution;
%%%resolution = [1920 1200];                          % oder doch 1200x1920?
framenumbers_w = ceil( resolution(1)/(frame_width-frame_overlap) );
framenumbers_h = ceil( resolution(2)/(frame_height-frame_overlap) );
frameoffset_w = resolution(1)/framenumbers_w;
frameoffset_h = resolution(2)/framenumbers_h;

for i = 0*framenumbers_h + 0 : framenumbers_w * framenumbers_h - 1
    iy = framenumbers_h - 1 - mod( i, framenumbers_h );% N-1..0 lines
    ix = floor( i/framenumbers_h );                    % 0..M-1 columns
    x1 = max(1, ix*frameoffset_w-frame_overlap);       % left  corners >0
    x2 = min(resolution(1), (ix+1)*frameoffset_w); % right corners <=max
    y1 = max(1, iy*frameoffset_h );                    % upper corners >0 
    y2 = min(resolution(2), (iy+1)*frameoffset_h); % lower corners <=max
    fprintf('ix= %d iy= %d (%d, %d)(%d, %d)\n', ix, iy, x1, y1, x2, y2);
    % white image (color 1) only between corners, black frame:
    img = color(resolution, 1, [x1 y1 x2 y2]);
    tex = win.make_texture(img);
    win.draw(tex, 1, [0 0 resolution(1) resolution(2)]);
    win.flip();
    waitforbuttonpress;
    % part of (fixed) noise image between same corners, black frame:
    img = noisewhite(resolution, 0, 1, 0, [x1 y1 x2 y2]);
    %%% fprintf('11= %.3f  12= %.3f  21=%.3f  22=%.3f\n', img(y1,x1), img(y1,x2), img(y2,x1), img(y2,x2));
    tex = win.make_texture(img);
    win.draw(tex, 1, [0 0 resolution(1) resolution(2)]);
    win.flip();
    waitforbuttonpress;
end
%disp('-->finished');
