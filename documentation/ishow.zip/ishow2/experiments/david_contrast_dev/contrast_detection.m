function contrast_detection(frequencies, phases, theta, contrasts, ...
                            block_length)
%function contrast_detection(frequencies, phases, thetas, contrasts, block_length)

%% Setup parameters

if nargin < 5
    block_length = 25;
end
    
img_size = [800 800];
bg_color = 0.5;

aud_volume = 0.5;
contrasts = michelson_to_scale(contrasts, bg_color);
verbose = true;
if any(bg_color + contrasts > 1)
    error('too much')
end
% Trial durations in ms
ms_stim = 240;
ms_resp = 800;
ms_isi = 500;
ms_iti = 700;

datadir = '/home/heiko/temp';

%% Dirty gamma-correction
% dat = load('~/Documents/patrick/temp_data/calibration/photometer_luminance_13-04-20_controlled.mat');
% typicalGammaInput = dat.voi';
% typicalGammaData = mean(dat.data,2)  / max(mean(dat.data,2));
% output = linspace(0,1,(2^14))';
% clut = spline(typicalGammaData, typicalGammaInput, output);
% clut(1:10) = 0;

%% start the hardware
%
% %Datapixx-initialization:
% win = window('viewpixx_gray', 'bg_color', bg_color, 'clut', clut);
% aud = dpixx_audio_port('volume', aud_volume);
% list_wait = listener_buttonbox;
% list_stop = listener_buttonbox('does_interrupt', true);

win = window('debug', 'rect', [0 0 1000 1000], 'bg_color', bg_color);
aud = local_audio_port('volume', aud_volume);
list_wait = listener_keyboard;
list_stop = listener_keyboard('does_interrupt', true);


%% Calculate framecount per trial

n_frames_stim = ms_stim * win.framerate / 1000;
n_frames_resp = ms_resp * win.framerate / 1000;
n_frames_isi = ms_isi * win.framerate / 1000;
n_frames_iti = ms_iti * win.framerate / 1000;
%n_frames_stim = 120;


%% Define the timecourse
timecourse = curve_tapered_cosine('size', n_frames_stim, ...
                                  'alpha', .3);

%% Create textures

textures = cell(length(frequencies), length(phases));
for i = 1 : length(frequencies)
    f = frequencies(i);
    for j = 1 : length(phases)
        p = phases(j);
        grating = grating_sine(...
            'size', img_size, ...
            'frequency', f, ...
            'phase', p, ...
            'theta', theta);
        textures{i, j} = win.make_texture(grating);
    end
end
cross_grate = patch_crosshair('size', img_size, ...
    'length', 20, 'color', .4);
cross_tex = win.make_texture(cross_grate.patch);
% win_grate = distrib_tapered_cosine('size', img_size, ...
%                                    'alpha', .3);
window_tex = win.make_mask_texture('tapered_cosine', ...
                                   'size', img_size, ...
                                   'alpha', .3);


%% Generate sounds

aud.create_beep('short_low', 'low', .15, 0.25);
aud.create_beep('short_med', 'med', .15, 0.25);
aud.create_beep('short_high', 'high', .15, 0.25);
aud.create_beep('long_low', 'low', .4, 0.25);
aud.create_beep('long_high', 'high', .4, 0.25);


%% Define a trial

    function response = trial(f, c, pos)
    %function trial(f, c, pos)
    %
    % Run one trial
        
        % ITI
        for itic = 1 : n_frames_iti
            win.draw(cross_tex);
            win.flip();
        end
                
        % First interval
        aud.play('short_low');
        for itic = 1 : length(timecourse)
            if pos == 1
                win.draw_additive(f, c * timecourse(itic));
                win.draw_mask(window_tex);
            end
            win.draw(cross_tex);
            win.flip();
        end
        aud.play('short_med');
        
        % ISI
        for itic = 1 : n_frames_isi
            win.draw(cross_tex);
            win.flip();
        end
        
        % Second interval
        aud.play('short_high');
        for itic = 1 : length(timecourse)
            if pos == 2
                win.draw(f, c * timecourse(itic));
                win.draw_mask(window_tex);
            end
            win.draw(cross_tex);
            win.flip();
        end
        aud.play('short_med');
        
        % Response interval
        list_wait.start();
        for itic = 1 : n_frames_resp
            win.draw(cross_tex);
            win.flip();
        end
        response = list_wait.stop();
        
        % Give feedback
        if pos == 1
            aud.play('long_low');
        else
            aud.play('long_high');
        end
    end

%% Define the clean-up function

    function wrap_up
        win.flip();
        fname = ['blocks_' standard_now];
        save(fullfile(datadir, fname), 'blocks', 'frequencies', 'contrasts');
        disp(sprintf('Data saved in: %s', fname));
    end
    
    
%% Run the pexperiment

blocks = {};
try
    % Wait untill subject is ready
    win.pause_trial(list_stop, 'Press a button when you are ready to start');
    
    % Loop through textures and contrasts
    for u = 1 : length(frequencies)
        for s = 1 : length(contrasts)

            % Preallocate data for this block
            locations = zeros(block_length, 1);
            presses = zeros(block_length, 1);
            times = zeros(block_length, 1);
            
            for k = 1 : block_length
                
                % Run the trial
                pos = randi(2);
                stim_phase_pos = randi(length(phases));
                stim_tex = textures{u, stim_phase_pos};
                locations(k) = pos;
                resp = trial(stim_tex, contrasts(s), pos);
                
                % Save the responses
                [press, rt] = resp.get_presses('first');
                presses(k) = press;
                times(k) = rt;                
            end

            % Store and summarize the data
            blocks{u, s, 1} = horzcat(presses(:), locations(:), times(:));
            blocks{u, s, 2} = summarize_2fc_data(locations, presses, times, verbose);
            
            % If this wasn't the last block of trials, take a break
            if u < length(frequencies) || s < length(contrasts)
                win.pause_trial(list_stop, ['Press a button when you are ready ' ...
                                    'to continue']);
            end
        end
    end
catch e
    wrap_up();
    rethrow(e);
end

wrap_up();

end