frequencies = [1 2];
phases = linspace(0, 1, 10);
thetas = 2;

param = level_data('frequency', frequencies, ...
                   'phase', phases, true, ...
                   'theta', thetas);

f = @(varargin) grating_sine('size', [300 300], varargin{:});
f = @(varargin) varargin{4};
param.fill(f);
param.select('frequency', 1);
