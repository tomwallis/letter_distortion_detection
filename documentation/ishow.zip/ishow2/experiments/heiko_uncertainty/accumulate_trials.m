function summary = accumulate_trials(trials)
%ACCUMLATE_TRIALS summarizes single trials per types.
%
% input:
%  trials  [n, 3] matrix containing results for n trials where
%            trials(:, 1)    type
%            trials(:, 2)    true value
%            trials(:, 3)    chosen value
%
% output:
%  summary  [m, 3] matrix containing summaries for m types where
%            summary(i, 1)    type
%            summary(i, 2)    percetage of correct answers
%            summary(i, 3)    number of trials
%
% Heiko Schuett * 2013-09-27

n      = size(trials, 1);                           % number of trials
types  = unique(trials(:, 1));                      % types appearing during the trials
m      = length(types);                             % number of types
summary = zeros(m, 3);                              % initialize summary matrix
correct = (trials(:, 2) == trials(:, 3));           % binary vector whether a trial is correct
for i = 1:m                                         % iterate over all types
  t            = types(i);                          % pick a type
  sel          = find(trials(:, 1) == t);           % pick indices by type
  summary(i, 1) = t;                                % store the type
  summary(i, 3) = length(sel);                      % number of trials of this type
  summary(i, 2) = sum(correct(sel)) ;               % number of correct answers
end
return
