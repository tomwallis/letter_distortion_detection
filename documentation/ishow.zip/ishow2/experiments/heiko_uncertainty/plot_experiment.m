function plot_experiment(results,meanN)
%function plot_experiment(results)
% this function plots the most relevant infos about an experiment from the
% results matrix.
% This is mainly meant for an immediate look at your data after the
% experiment

if ~exist('meanN','var') || isempty(meanN)
    meanN=10;
end

n=size(results,1);

blocks=find((results(1:(end-1),2)~=results(2:end,2))|(results(1:(end-1),1)~=results(2:end,1)));
blocks=[blocks;n];
blocks0=[0;blocks];

correct=(results(:,3)==results(:,4));
left=(results(:,3)==1);
right=~left;
nleft=sum(left);
nright=sum(right);

noAnswer=isnan(results(:,4));

reactionTimes=results(:,6);
reactionTimes(noAnswer)=max(reactionTimes(~noAnswer));

if any(noAnswer)
    fprintf('You missed %d trials! (%d left, %d right)\n',sum(noAnswer),sum(noAnswer(left)),sum(noAnswer(right)));
end
pcorrect_total=sum(correct)/n;
pcorrect_left=sum(correct(left))/sum(left);
pcorrect_right=sum(correct(right))/sum(right);

pConf=binocdf(sum(correct(left)),nleft,pcorrect_right);
pConf2=binocdf(sum(correct(right)),nright,pcorrect_left);

if pConf>.95 || pConf<.05 || pConf2>.95 || pConf2<.05
    if pcorrect_left>pcorrect_right
        disp('You have a bias for one side!');
        disp('You are significantly better for the first interval/left button');
    else
        disp('You have a bias for one side!');
        disp('You are significantly better for the second interval/right button');
    end
    
end


figure('name',sprintf('total: %d %% (N = %d),left: %d %% (N = %d), right: %d %% (N = %d)',round(100*pcorrect_total),n,round(100*pcorrect_left),nleft,round(100*pcorrect_right),nright))

subplot(2,1,1)
plot(correct,'.');
hold on
plot(find(noAnswer),correct(noAnswer),'r.')
mov_average=conv(+correct,ones(meanN,1)/meanN,'same');
plot(mov_average,'k');

if length(blocks)<25 && length(blocks)>1
    plot([blocks,blocks]'+.5,repmat([0;1],1,length(blocks)),'k--');
    for i=1:length(blocks)
        plot([(blocks0(i)+1);blocks(i)],repmat(mean(correct((blocks0(i)+1):blocks(i))),2,1),'y');
        plot([(blocks0(i)+1);blocks(i)],repmat(1/meanN*icdf('bino',.95,meanN,mean(correct((blocks0(i)+1):blocks(i)))),2,1),'k:');
        plot([(blocks0(i)+1);blocks(i)],repmat(1/meanN*icdf('bino',.05,meanN,mean(correct((blocks0(i)+1):blocks(i)))),2,1),'k:');
    end
else
    plot([1,n],[pcorrect_total,pcorrect_total],'k');
    plot([1,n],repmat(1/meanN*icdf('bino',.95,meanN,mean(+correct)),2,1),'k:');
    plot([1,n],repmat(1/meanN*icdf('bino',.05,meanN,mean(+correct)),2,1),'k:');
end

axis tight
xlabel('trials')
ylabel('perc. correct')

subplot(2,1,2)
plot(reactionTimes,'.')
hold on
plot(find(noAnswer),reactionTimes(noAnswer),'r.')
mov_average_RT=conv(reactionTimes,ones(meanN,1)/meanN,'same');
plot(mov_average_RT,'k');

if length(blocks)<25 && length(blocks)>1
    plot([blocks,blocks]'+.5,repmat([min(reactionTimes);max(reactionTimes)],1,length(blocks)),'k--');
    for i=1:length(blocks)
        plot([(blocks0(i)+1);blocks(i)],repmat(mean(reactionTimes((blocks0(i)+1):blocks(i))),2,1),'y');
    end
end

plot([1,n],[mean(reactionTimes),mean(reactionTimes)],'k');

axis tight
xlabel('trials');
ylabel('reaction time[s]')