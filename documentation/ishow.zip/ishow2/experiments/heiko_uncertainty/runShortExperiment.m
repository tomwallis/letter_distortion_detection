function runShortExperiment(name)
% this function starts the next block of the uncertainty experiment.
%function runShortExperiment(name)
% name is the proband name you chose

% for the strange MATLAB error....
ones(10)*ones(10);


folder    = '/home/data/heiko/short';
contrasts = [.003,.004 ,.005,.0055,.006,.0065,.007,.0075,.008,.009,.01 ,.012;...
             .003,.004 ,.005,.006 ,.007,.0075,.008,.0085,.009,.01 ,.011,.012;...
             .015,.0175,.02 ,.0225,.025,.0275,.03 ,.0325,.035,.04 ,.045,.05];

if strcmp(name,'Silke')
    contrasts(3,:) = contrasts(3,:).*.6;
end
         
if ~exist(folder,'dir')
    mkdir(folder);
end

if ~exist(fullfile(folder,[name,'.mat']),'file')
    rng('shuffle');
    blocks = [3,.75,12,3,.75,12];
    blocks = blocks(randperm(length(blocks)));
    for i = 1:5
        newblocks = [3,.75,12,zeros(1,10)];
        blocks    = [blocks,newblocks(randperm(length(newblocks)))];
    end
    newblocks = [3,.75,12,3,.75,12];
    blocks    = [blocks,newblocks(randperm(length(newblocks)))];
    blocks    = [blocks',zeros(size(blocks'))];
    save(fullfile(folder,[name,'.mat']),'blocks');
else
    load(fullfile(folder,[name,'.mat']))
end

iblock    = find(~blocks(:,2),1,'first');

if ~isempty(iblock)
    switch blocks(iblock)
        case 0
            contrasts = contrasts;
            if strcmp(name,'Silke')
                contrasts(3,:) = [.015,.02 ,.025,.0275,.03 ,.035,.04 ,.045,.05,.06,.07,.08];
            end
            frequencies = [3,.75,12];
            repetitions = [18,1,1];
        case .75
            contrasts = contrasts(2,:);
            frequencies = .75;
            repetitions = 20;
        case 3
            contrasts = contrasts(1,:);
            frequencies = 3;
            repetitions = 20;
        case 12
            contrasts = contrasts(3,:);
            frequencies = 12;
            repetitions = 20;
    end
    short_trials(frequencies,linspace(0,1-1/12,12),contrasts,repetitions,name);
    blocks(iblock,2) = 1;
    save(fullfile(folder,[name,'.mat']),'blocks');
    fprintf('%d of %d blocks completed',sum(blocks(:,2)),size(blocks,1));
else
    fprintf('For this subject-name all blocks have been run already');
end
