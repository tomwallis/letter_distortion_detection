function P = ask_settings(path, varargin )
%ASK_SETTINGS Summary of this function goes here
%   Detailed explanation goes here

    
    answers = inputdlg([{'Subject Pseudonym', 'Monitor distance (mm)', ...
                          'Notes'} , varargin(:)]);
    
    P.subject = answers{1};
    P.screen_distance = str2double(answers{2});
    P.notes = answers{3};
    
    while ~isdir(fullfile(path, P.subject))
        c = questdlg(['Subject pseudonym does not exist yet. Do you want to ' ...
               'create a new subject? If you press No you will be able to ' ...
               'reenter the subject pseudonym.'],['Unrecognized subject ' ...
               'pseudonym'],'Yes','No','No');
        if strcmpi(c, 'Yes')
            mkdir(fullfile(path, P.subject));
            msgbox('The subject folder has been created.')
        elseif strcmpi(c, 'No')
            temp_name = inputdlg('Subject Pseudonym');
            P.subject = temp_name{1};
        end
    end
    
    
    for i = 1:length(varargin)
        P.(varargin{i}) = answers{i + 3};
    end
    
    msgbox('All manual options have been successfully set.')
end

