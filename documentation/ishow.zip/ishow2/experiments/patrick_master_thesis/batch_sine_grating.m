function patches = batch_sine_grating( varargin )
%BATCH_SINE_GRATING Summary of this function goes here
%   Detailed explanation goes here

%% Define defaults

P = grating_defaults();


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    patches = P;
    return
end

P = update_struct(P, varargin{:},'add');

patches = cell(1, length(P.phase));
for i = 1 : length(P.phase)
    patches{i} = grating_sine('size', P.size, 'frequency', P.frequency, ...
                              'theta', P.theta, 'phase', P.phase(i));
end

end

