xset -dpms
xset s off

matlab -r screen_saver_demo
