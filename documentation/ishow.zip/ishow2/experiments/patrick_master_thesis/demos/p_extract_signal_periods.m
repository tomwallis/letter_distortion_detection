function extracted_periods = p_extract_signal_periods(signal)

%Envelope Detection based on Low pass filter and then FFT
[a,b] = butter(2,0.1);%butterworth Filter of 2 poles and Wn=0.1
sig_abs = abs(signal - mean(signal)); % Can be used instead of squaring, then filtering and

y = sqrt(filtfilt(a,b,sig_abs)); %applying LPF

%advantages of taking square and then Square root rather than abs, brings
%out some hidden information more efficiently
N = length(y);
sig_f = abs(fft(y)); sig_f = sig_f(2:end);
sig_n = sig_f / norm(sig_f);

[~, idx] = max(sig_n); % Number of periods
period = floor(N / idx); % length of a single period

extracted_periods = reshape(signal(1 : end - mod(N, period)), period, idx);