clearvars;

%% Preparation of the session
if ispc % If we are on a windows machine
    path_home = getenv('USERPROFILE');
else
    path_home = getenv('HOME');
end

addpath(fullfile(path_home, 'Documents', 'Calibration'))

path_calibration = fullfile(path_home,'Documents','experiments', ...
    'patrick_thesis', 'calibration');
calibration_time = standard_now;
path_measurement = fullfile(path_home,'Documents','experiments', ...
    'patrick_thesis', 'calibration', ...
    ['measurement_' calibration_time]);
path_clut = fullfile(path_home,'Documents','experiments', ...
    'patrick_thesis', 'calibration', ...
    ['clut_' calibration_time]);

% the input values we are interestedin
input = linspace(0,1,256)';
output = linspace(0,1,2^14)';
N_REP = 50; % number of repeated measurements
N_SAMPLE = 1500;
SCREEN_NAME = 'CRT EIZO';
RESOLUTION = Screen('Resolution', max(Screen('Screens')));

%% Parameters
BG_COLOR_CONTRAST = 0.5;
CONTRASTS = [0.0001, 0.0005, 0.0008, 0.001, 0.002; ...
    0.002, 0.005, 0.01, 0.02, 0.05; ...
    0.02, 0.05, 0.1, 0.2, 0.4];
N_REP_CONTRAST = 50;

%% Open screen and photometer
win = window('viewpixx_gray', 'bg_color', input(1));
phot = photometer();
phot.talk('RNG 6');
sampling_frequency = phot.talk('SRT 250');

aud = dpixx_audio_port('volume', [0.7 0; 0.7, 0],'when','now');
% Generate auditory stimuli
aud.create_beep('long_low', 'low', 5, 0.25);
aud.create_beep('long_high', 'high', 5, 0.25);

%% Measure gamma curve
pause(6);

aud.play('long_low');

luminance_uncalibrated = zeros(length(input), N_REP);
r_luminance_uncalibrated = cell(length(input),1);
c_luminance_uncalibrated = cell(length(input), 1);
for i = 1 : length(input)
    win.bg_color = input(i);
    win.clear(true);
    pause(0.2)
    temp_luminance = [];
    temp_periods = [];
    while size(temp_periods,2) < N_REP
        measure = phot.measure_n(N_SAMPLE);
        temp_luminance = [temp_luminance; measure];
        temp_periods = [temp_periods, p_extract_signal_periods(measure)];
    end
    r_luminance_uncalibrated{i} = temp_luminance;
    c_luminance_uncalibrated{i} = temp_periods;
    luminance_uncalibrated(i, :) = mean(c_luminance_uncalibrated{i}(:,1:N_REP), 1)';
end

clearvars win

%% Directly interpolate the inverse gamma function

luminance_unscale = mean(luminance_uncalibrated,2);
luminance_unscale = luminance_unscale / max(luminance_unscale);

% data_luminance_unscale = luminance_uncalibrated(:) / max(luminance_uncalibrated(:));
% data_input = repmat(input, 1, N_REP); data_input = data_input(:);
% Fit the inverse gamma function
gamma_pred = interp1(input, luminance_unscale, input,'spline');
% gamma_param = polyfit(data_input, data_luminance_unscale, 8);
% gamma_pred = polyval(gamma_param, input);
% First value is always beyond good and evil, but we want it to be 0

% Fit the inverse gamma function
gamma_inv_pred = interp1(luminance_unscale, input, input,'spline');
% gamma_inv_param = polyfit(data_luminance_unscale, data_input, 5);
% gamma_inv_pred = polyval(gamma_inv_param, input);
% First value is always beyond good and evil, but we want it to be 0

figure;
subplot(1,2,1)
hold on
% Plot the spline interpolation
plot(input,gamma_pred,'k')
% Plot the raw data
plot(input(1:4:end), luminance_unscale(1:4:end), '+g', 'Markersize', 5);
title('Gamma function')
xlabel('Input to dac')
ylabel('Normalized luminance')
axis square

subplot(1,2,2)
hold on
% Plot the spline interpolation
plot(input,gamma_inv_pred,'k')
% Plot the raw data
plot(luminance_unscale(1:4:end), input(1:4:end),'+r', 'Markersize', 5);

title('Inverse Gamma function')
xlabel('Normalized luminance')
ylabel('Input to dac')
axis square

% Output the new gamma table which should be used by Psychtoolbox
new_gamma_table = repmat(gamma_inv_pred,1,3);


%% Measure gamma curve
clut = interp1(luminance_unscale, input, output,'spline');
win = window('viewpixx_gray', 'bg_color', input(1), 'clut', clut);
aud.play('long_low');
pause(5);

luminance_calibrated = zeros(length(input), N_REP);
r_luminance_calibrated = cell(length(input),1);
c_luminance_calibrated = cell(length(input), 1);
for i = 1 : length(input)
    win.bg_color = input(i);
    win.clear(true);
    pause(0.2)
    temp_luminance = [];
    temp_periods = [];
    while size(temp_periods,2) < N_REP
        measure = phot.measure_n(N_SAMPLE);
        temp_luminance = [temp_luminance; measure];
        temp_periods = [temp_periods, p_extract_signal_periods(measure)];
    end
    r_luminance_calibrated{i} = temp_luminance;
    c_luminance_calibrated{i} = temp_periods;
    luminance_calibrated(i, :) = mean(c_luminance_calibrated{i}(:,1:N_REP), 1)';
end

clearvars win

%% Plot the luminance measurements after applying the clut

luminance_scale = mean(luminance_calibrated,2);
luminance_scale = luminance_scale / max(luminance_scale);

figure;
subplot(1,2,1)
hold on
plot([min(luminance_scale), max(luminance_scale)], ...
    [min(luminance_scale), max(luminance_scale)], 'k', 'LineWidth', 2)
plot(input(1:4:end), luminance_scale(1:4:end), '+g', 'Markersize', 5)
title('Gamma function after applying the clut')
xlabel('Input to dac')
ylabel('Normalized luminance')
legend('Perfect linearization','Photometer measurements', ...
    'location','NorthWest')
axis square


luminance_deviation = bsxfun(@minus, mean(luminance_calibrated,2), ...
    max(mean(luminance_calibrated, 2)) * input);
subplot(1,2,2)
hold on

% Plot the mean deviation from the theoretical luminance value
plot([0 max(mean(luminance_calibrated, 2))], [mean(luminance_deviation), mean(luminance_deviation)], ...
    'r','LineWidth', 2)

plot([0 max(mean(luminance_calibrated, 2))], [mean(luminance_deviation) - 3 * std(luminance_deviation), ...
    mean(luminance_deviation) - 3 * std(luminance_deviation)], ...
    'r--','LineWidth', 2)
plot([0 max(mean(luminance_calibrated, 2))], [mean(luminance_deviation) + 3 * std(luminance_deviation), ...
    mean(luminance_deviation) + 3 * std(luminance_deviation)], ...
    'r--','LineWidth', 2)

% Plot the deviation from the theoretical luminance value
plot(max(mean(luminance_calibrated, 2)) * input, luminance_deviation, 'LineWidth', 2)

title('Inverse Gamma function')
xlabel('Expected luminance in cd/m^2')
ylabel('Measured photiation from expectation in cd/m^2')
axis square


%% Preparation
% Open a gray screen with 16bit
win = window('viewpixx_gray', 'bg_color', BG_COLOR_CONTRAST(1), 'clut', clut);
aud.play('long_low');
pause(1)
%% Measurement
luminance_contrast = cell(length(BG_COLOR_CONTRAST), size(CONTRASTS,1), ...
    size(CONTRASTS,2));
for b = 1:length(BG_COLOR_CONTRAST)
    win.bg_color = BG_COLOR_CONTRAST(b);
    win.clear(true);
    pause(0.5)
    for r = 1:size(CONTRASTS,1)
        for c = 1:size(CONTRASTS,2)
            luminance_contrast{b,r,c} = nan(3,N_REP_CONTRAST);
            
            % Minus contrast
            win.bg_color = BG_COLOR_CONTRAST(b) ...
                - michelson_to_scale(CONTRASTS(r,c), BG_COLOR_CONTRAST(b));
            win.clear(true);
            
            pause(0.5)
            temp_luminance = [];
            temp_periods = [];
            while size(temp_periods,2) < N_REP_CONTRAST
                measure = phot.measure_n(N_SAMPLE);
                temp_luminance = [temp_luminance; measure];
                temp_periods = [temp_periods, p_extract_signal_periods(measure)];
            end
            luminance_contrast{b,r,c}(1,:) = mean(temp_periods(1:N_REP_CONTRAST), 1);
            
            % Mean luminance
            win.bg_color = BG_COLOR_CONTRAST(b);
            win.clear(true);
            
            pause(0.5)
            temp_luminance = [];
            temp_periods = [];
            while size(temp_periods,2) < N_REP_CONTRAST
                measure = phot.measure_n(N_SAMPLE);
                temp_luminance = [temp_luminance; measure];
                temp_periods = [temp_periods, p_extract_signal_periods(measure)];
            end
            luminance_contrast{b,r,c}(2,:) = mean(temp_periods(1:N_REP_CONTRAST), 1);
            
            % Plus contrast
            win.bg_color = BG_COLOR_CONTRAST(b) ...
                + michelson_to_scale(CONTRASTS(r,c), BG_COLOR_CONTRAST(b));
            win.clear(true);
            
            pause(0.5)
            temp_luminance = [];
            temp_periods = [];
            while size(temp_periods,2) < N_REP_CONTRAST
                measure = phot.measure_n(N_SAMPLE);
                temp_luminance = [temp_luminance; measure];
                temp_periods = [temp_periods, p_extract_signal_periods(measure)];
            end
            luminance_contrast{b,r,c}(3,:) = mean(temp_periods(1:N_REP_CONTRAST), 1);
        end
    end
end
clearvars win

%% Save the data
save(path_measurement)
save(path_clut, 'clut', 'luminance_calibrated', 'calibration_time', ...
    'SCREEN_NAME', 'RESOLUTION')

%% Plotting
for b = 1:length(BG_COLOR_CONTRAST)
    figure;
    for r = 1:size(CONTRASTS,1)
        subplot(1,size(CONTRASTS,1),r)
        hold all
        for c = 1:size(CONTRASTS,2)
            mean_luminance = mean(luminance_contrast{b,r,c},2) / ...
                mean(max(luminance_uncalibrated));
             errorbar(1:3, mean_luminance, ...
                 std(luminance_contrast{b,r,c}' / ...
                mean(mean(max(luminance_uncalibrated,1)))), 'LineWidth', 2.5)
        end
        for c = 1:size(CONTRASTS,2)
            mean_luminance = mean(luminance_contrast{b,r,c},2) / ...
                mean(max(luminance_uncalibrated));
            mean_luminance = mean_luminance(2);
            theoretical_values = [mean_luminance - CONTRASTS(r,c) * mean_luminance, ...
                mean_luminance, ...
                mean_luminance + CONTRASTS(r,c) * mean_luminance];
            
            plot(theoretical_values, '-sk')
        end
        axis square
        grid on
        set(gca,'Xtick',1:3,'XTickLabel',{'-', '0', '+'})
        legend(num2str(100*CONTRASTS(r,:)'), 'Location','NorthWest')
        title(['Mean luminance: ' num2str(BG_COLOR_CONTRAST(b))])
        xlabel('Stimulus relative to mean luminance')
        ylabel('Measured luminance in cd/m^2')
    end
end

aud.play('long_high')