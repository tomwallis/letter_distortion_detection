IMG_SIZE = [512, 512];

s_window = distrib_tapered_cosine('size', IMG_SIZE,'alpha',0.6);
crosshair = patch_crosshair('size',IMG_SIZE, 'length', ...
IMG_SIZE(1) / 20, 'color', 0);
crosshair = crosshair.patch;


freq = cdeg_to_cimg(3, mm_to_vangle(500,1000));
gratings = batch_sine_grating( 'size', IMG_SIZE, ...
'frequency', freq, ...
'theta', 0.25, ...
'phase', 0);
grating = gratings{1};


crosshair(crosshair == 0) = 0.5;
crosshair(crosshair == 1) = 0.3;

h = figure;
imagesc(crosshair(:,:,2))
hold all
imagesc(2:IMG_SIZE(1)+1, 2:IMG_SIZE(1)+1, 0.5 + 0.5 * grating.*s_window, [0, 1])
axis image
axis off
colormap gray

truesize(h,IMG_SIZE + 2)

h = figure;
imagesc(crosshair(:,:,2))
hold all
imagesc(2:IMG_SIZE(1)+1, 2:IMG_SIZE(1)+1, 0.5 + 0.5 * zeros(size(grating)).*s_window, [0, 1])
axis image
axis off
colormap gray
truesize(h,IMG_SIZE + 2)