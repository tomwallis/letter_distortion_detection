function p_sweet = uml_sweetpoints( params )
%UML_SWEETPOINTS Summary of this function goes here
%   Detailed explanation goes here

alpha = params(1);
beta = 1 / params(2);
gamma = params(3);
lambda = params(4);

p_sweet(1) = fminsearch(@(p) alphavar_est(p,alpha,beta,gamma,lambda),0.5);
p_sweet(2) = fminsearch(@(p) betavar_est(p,alpha,beta,gamma,lambda),0.835);
p_sweet(3) = 0.999;
p_sweet(4) = fminsearch(@(p) betavar_est(p,alpha,beta,gamma,lambda),0.1);

p_sweet = sort(p_sweet,'descend') * (1 - gamma - lambda) + gamma;

p_sweet = min(max(gamma * ones(size(p_sweet)) + eps, p_sweet), ...
            ones(size(p_sweet)) - lambda - eps);
end

function sigmaalphasq = alphavar_est(p,alpha,beta,gamma,lambda)

logit_p = log(p ./ (1 - p));
term1 = exp( 2 * logit_p); % exp( 2 * beta * (alpha - x));
term2 = (1 ./ p).^2; % (1+exp(beta*(x-alpha))).^2;
term3 = -gamma + (lambda - 1) * (1./p - 1); %-gamma+(lambda-1)*exp(beta*(x-alpha));
term4 = 1 - gamma + lambda * (1./p - 1); %1-gamma+lambda*exp(beta*(x-alpha));
term5 = beta^2 * (-1 + gamma + lambda)^2;

sigmaalphasq = -term1.*term2.*term3.*term4./term5;

end

function sigmabetasq = betavar_est(p,alpha,beta,gamma,lambda)

logit_p = log(p ./ (1 - p));
term1 = exp( 2 * logit_p); %term1 = exp(2*beta*(alpha-x));
term2 = (1 ./ p).^2; % (1+exp(beta*(x-alpha))).^2;
term3 = -gamma + (lambda - 1) * (1./p - 1); % -gamma+(lambda-1)*exp(beta*(x-alpha));
term4 = 1 - gamma + lambda * (1./p - 1); % 1-gamma+lambda*exp(beta*(x-alpha));
term5 = (logit_p / beta).^2 *(-1 + gamma + lambda)^2; % (x - alpha).^2*(-1+gamma+lambda)^2;

sigmabetasq = -term1.*term2.*term3.*term4./term5;
end