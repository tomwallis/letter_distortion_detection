xset -dpms
xset s off

matlab -r exp_contrast_detection 
