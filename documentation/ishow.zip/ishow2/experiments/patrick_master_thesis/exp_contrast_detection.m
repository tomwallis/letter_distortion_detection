clearvars

%% Preparation of the session
if ispc % If we are on a windows machine
    path_home = getenv('USERPROFILE');
else
    path_home = getenv('HOME');
end

% Set the paths
path_data = fullfile(path_home,'Documents','patrick', 'data');

addpath(genpath(fullfile(path_home,'Documents','patrick')));

%% Experimental parameters - constants
LUMINANCE_MEAN = 400; % in candela/m^2
LUMINANCE_SAVER = 20;
SCREEN_NAME = 'CRT EIZO';
SCREEN_ID = max(Screen('Screens'));
SCREEN_DISTANCE = 1250;

T_STIM = 200;
T_ISI = 400;
T_RESP = 700;
T_ITI = 800;

IMG_SIZE = [512 512];

psign_prefs = psignifit_batch('shape', 'logistic', 'n_intervals', 2, 'runs', 0, 'slope_opt','log');


%% Ask subject for information and grab the next task

P = p_exproperties(path_data, LUMINANCE_MEAN, SCREEN_NAME, SCREEN_ID, ...
    SCREEN_DISTANCE, T_STIM, T_ISI, T_RESP, T_ITI, IMG_SIZE);

% Make sure that the folder we want to save in exists
if ~exist(fullfile(P.path_subject, P.mask, P.paradigm),'dir')
    mkdir(fullfile(P.path_subject, P.mask, P.paradigm))
end

protocol_id = fopen(fullfile(P.path_subject,[P.name_subject,'_protocol.txt']), 'a');
fprintf(protocol_id, ['\n ------------------------------------------- \n',...
    'Time: %s \n  taks_n = %4.d \n  cdeg = %6.2f \n  paradigm: %s \n  ', ...
    'procedure: %s \n  mask: %s \n  mask contrast: %6.2f \n  mask cdeg: %6.2f \n', ...
    '  mask orientation: %6.2f \n'], ...
    standard_now(), P.task_n, P.grating_cycles_deg, P.paradigm, ...
    P.procedure, P.mask, P.mask_orientation, P.mask_cycles_deg, P.mask_contrast);
fclose(protocol_id);

%% Set the file paths
path_pretrial = fullfile(P.path_subject, P.mask, P.paradigm, ...
    [num2str(P.grating_cycles_deg), 'cdeg_', num2str(P.mask_orientation), 'mtheta_',...
    num2str(P.mask_cycles_deg), 'mdeg_', num2str(P.mask_contrast), 'mcontrast_pretrial.mat']);

path_block1 = fullfile(P.path_subject, P.mask, P.paradigm, ...
    [num2str(P.grating_cycles_deg), 'cdeg_', num2str(P.mask_orientation), 'mtheta_',...
    num2str(P.mask_cycles_deg), 'mdeg_', num2str(P.mask_contrast), 'mcontrast_', P.procedure,'1.mat']);

path_block2 = fullfile(P.path_subject, P.mask, P.paradigm, ...
    [num2str(P.grating_cycles_deg), 'cdeg_', num2str(P.mask_orientation), 'mtheta_',...
    num2str(P.mask_cycles_deg), 'mdeg_', num2str(P.mask_contrast), 'mcontrast_', P.procedure,'2.mat']);

%% Define the paradigm specific option: Messages, trial_executers, Number of trials
m_iterator = choose_constant(P.mask_contrast);

switch P.paradigm
    case '2ifc'
        trial_executer = @trial_2ifc_contrast;
        msg_paradigm = sprintf(...
            ['2IFC - In this task you respond whether you saw the horizontal \n', ...
            'grating in the first (green button) or in the second (red button) \n', ...
            'interval. It will be equally distributed among both intervals. \n \n' ...
            'Press any botton to continue.']);
        N_PRETRIAL = 50;
        N_BLOCK = 50;
    case 'siam'
        trial_executer = @trial_siam_contrast;
        msg_paradigm = sprintf(['Yes/No - In this task you respond whether you saw the horizontal grating \n', ...
            'Yes or No. For a Yes answer press the green button and for a No answer press \n', ...
            'the red button. The grating will be present in 50 Percent of the trials. \n \n' ...
            'Press any botton to continue.']);
        N_PRETRIAL = 70;
        N_BLOCK = 70;
end
N_TRAINING = 30;

msg_adj = sprintf(...
    ['This is a single trial with the use of the method of adjustment. \n', ...
    'Your task is to adjust the contrast of the horizontal grating such \n', ...
    'that you can only faintly see it. You can increase the contrast \n', ...
    'by pressing the red button, and you decrease it by pressing the green \n', ...
    'button. By pressing the yellow button you increase the step size, \n', ...
    'whereas by pressing the blue button you decrease the step size. \n', ...
    'Once you have adjusted the contrast press the white button to confirm \n \n.' ...
    'Press any botton to continue.']);
%% Initialize Datapixx and Screen

% Opens the PTB window with color correction and specified mean luminance
win = window('viewpixx_gray', 'bg_color', P.bg_color, 'clut', P.clut_data.clut);

aud = dpixx_audio_port('volume', [0.7 0; 0.7, 0],'when','now');
% Generate auditory stimuli
aud.create_beep('short_low', 'low', .15, 0.25);
aud.create_beep('short_med', 'med', .15, 0.25);
aud.create_beep('short_high', 'high', .15, 0.25);
aud.create_beep('long_low', 'low', .4, 0.25);
aud.create_beep('long_high', 'high', .4, 0.25);

% Response box objects
L.list_wait = listener_buttonbox;
L.list_stop = listener_buttonbox('does_interrupt', true);
L.list_adj = listener_buttonbox('does_interrupt', true, 'names', ...
    {'Green', 'Red', 'White', 'Yellow', 'Blue'});

%% Generate stimuli
t_window = curve_tapered_cosine('size', P.n_frames_stim, 'alpha', 0.5);

s_window = distrib_tapered_cosine('size', P.img_size,'alpha',0.6);

crosshair = patch_crosshair('size', [600, 600], 'length', ...
    ceil(P.img_size(1) / 20), 'color', 0);
crosshair = crosshair.patch;

% Generate the signal grating in different phases
freq = cdeg_to_cimg(P.grating_cycles_deg, P.v_angle);
gratings = batch_sine_grating( 'size', P.img_size, ...
    'frequency', freq(1), ...
    'theta', P.grating_orientation, ...
    'phase', P.grating_phases);

% Generate the maskers in different phases
m_freq = cdeg_to_cimg(P.mask_cycles_deg, P.v_angle);
if strcmpi(P.mask, 'plaid')
    masks = batch_sine_plaid( 'size', P.img_size, ...
        'frequency', m_freq(1), ...
        'theta', P.mask_orientation, ...
        'phase', P.mask_phases);
elseif strcmpi(P.mask, 'grating')
    masks = batch_sine_grating( 'size', P.img_size, ...
        'frequency', m_freq(1), ...
        'theta', P.mask_orientation, ...
        'phase', P.mask_phases);
else
    masks{1} = zeros(P.img_size);
end

% Generate OpenGL textures
crosshair_tex = win.make_texture(crosshair);
s_window_tex = win.make_mask_texture(s_window);
gratings_tex = NaN(size(gratings));
for i = 1:length(gratings)
    gratings_tex(i) = win.make_texture(gratings{i});
end
masks_tex = NaN(size(masks));
for i = 1:length(masks)
    masks_tex(i) = win.make_texture(masks{i});
end

% Write all stimuli into an object for easy data handling
stimuli = p_exstimuli(gratings, P.grating_phases, gratings_tex,...
    masks, P.mask_phases, masks_tex, ...
    t_window, s_window, s_window_tex, ...
    crosshair, crosshair_tex);

%% Start of experimental part

%% Run method of adjustment - we run it every session to remind the
%  subject of the stimuli that are going to be used in the session.

if ~exist(path_block2, 'file')
    
    win.pause_trial(L.list_stop, msg_adj);
    % Starts with the highest possible contrast for the given condition
    data_adj = trial_adj_contrast(stimuli, randi(length(stimuli.gratings_tex)), ...
        P.range(2), P.mask_contrast, randi(length(stimuli.masks_tex)), P, L, win);
    
    %% Training trials
    training_pvals = 0.75;
    training_init = data_adj;
    
    data_training = p_exdata(N_TRAINING, P.paradigm);
    
    win.pause_trial(L.list_stop, msg_paradigm);
    pauser = pauser_block(N_TRAINING,N_TRAINING);
    s_iterator = choose_staircase('range', P.range, ...
        'init', training_init * training_pvals, ...
        'threshold_p', training_pvals, ...
        'paradigm', P.paradigm, ...
        'log_scale', true);
    data_training = exp_contrast_runner(P, L, data_training, stimuli, ...
        win, aud, trial_executer, s_iterator, m_iterator, pauser);
    
    %% Pretrials to find the initial sampling points
    
    if ~exist(path_pretrial, 'file')
        
        % We assume zero lapse rate for the pretrials, this moves the p-values
        % to their extremes
        pretrial_pvals = uml_sweetpoints( [1,1,0.5,0.01] );
        pretrial_init = data_adj;
        
        data_pretrial = p_exdata(length(pretrial_pvals) * N_PRETRIAL, P.paradigm);
        
        for i = 1:length(pretrial_pvals)
            pauser = pauser_block(N_PRETRIAL,N_PRETRIAL);
            s_iterator = choose_staircase('range', P.range, ...
                'init', pretrial_init * pretrial_pvals(i), ...
                'threshold_p', pretrial_pvals(i), ...
                'paradigm', P.paradigm, ...
                'log_scale', true);
            data_pretrial = exp_contrast_runner(P, L, data_pretrial, stimuli, ...
                win, aud, trial_executer, s_iterator, m_iterator, pauser);
            pretrial_init = data_pretrial.contrast(data_pretrial.n);
        end
        
        % Set fitting properties
        outputPrefs = psignifit_batch('write_pa', 'pa_pretrial', 'write_th', 'th');
        psignifit(data_pretrial.get_psignifit_data('log10'), [psign_prefs outputPrefs]);
        P.time_off = now;
        P_pretrial = P;
        save(path_pretrial, 'P_pretrial', 'data_pretrial', 'pa_pretrial');
    end
    load(path_pretrial, 'P_pretrial', 'data_pretrial', 'pa_pretrial');
    
    %% Run blocked stimulus
    
    if ~exist(path_block1, 'file')
        
        block_p = uml_sweetpoints( pa_pretrial.est );
        block_contrasts = 10.^findthreshold('logistic', pa_pretrial.est, block_p,...
            'performance');
        block_contrasts = min(max(P.range(1) * ones(size(block_contrasts)), block_contrasts), ...
            P.range(2) * ones(size(block_contrasts)));
        
        pauser = pauser_block(N_BLOCK,length(block_p) * N_BLOCK);
        data_block = p_exdata(2 * length(block_p) * N_BLOCK, P.paradigm);
        
        switch P.procedure
            case 'block'
                s_iterator = choose_block(block_contrasts,N_BLOCK);
                data_block = exp_contrast_runner(P, L, data_block, stimuli, win, aud, ...
                    trial_executer, s_iterator, m_iterator, pauser);
            case 'interleaved'
                s_iterator = choose_interleaved(block_contrasts,N_BLOCK);
                data_block = exp_contrast_runner(P, L, data_block, stimuli, win, aud, ...
                    trial_executer, s_iterator, m_iterator, pauser);
            case 'adaptive'
                for i = 1:length(block_p)
                    pauser = pauser_block(N_BLOCK,N_BLOCK);
                    sample_range = [max(block_p(i) - 0.1, pa_pretrial.est(3) + eps), ...
                        min(block_p(i) + 0.1, 1 - pa_pretrial.est(4) - eps)];
                    sample_range = 10.^findthreshold('logistic', pa_pretrial.est, ...
                        sample_range, 'performance');
                    sample_range = [max(sample_range(1), P.range(1)), ...
                        min(sample_range(2), P.range(2))];
                    s_iterator = choose_staircase('range', sample_range, ...
                        'init', block_contrasts(i), ...
                        'threshold_p', block_p(i), ...
                        'paradigm', P.paradigm, ...
                        'log_scale', true);
                    data_block = exp_contrast_runner(P, L, data_block, stimuli, ...
                        win, aud, trial_executer, s_iterator, m_iterator, pauser);
                end
        end
        
        %Fit the data
        outputPrefs = psignifit_batch('write_pa', 'pa_block1', 'write_th', 'th');
        psignifit(data_block.get_psignifit_data('log10'), [psign_prefs outputPrefs]);
        P.time_off = now;
        P_block1 = P;
        save(path_block1, 'P_block1', 'P_pretrial', 'data_pretrial', 'pa_pretrial', ...
            'data_block', 'pa_block1');
    end
    
    if ~exist(path_block2, 'file')
        % Second block of trials
        load(path_block1, 'P_block1', 'P_pretrial', 'data_pretrial', 'pa_pretrial', ...
            'data_block', 'pa_block1');
        
        pretrial_p = uml_sweetpoints( pa_pretrial.est );
        pretrial_contrast = 10.^findthreshold('logistic', pa_pretrial.est, pretrial_p,...
            'performance');
        pretrial_p = ppsi('logistic', pa_block1.est, log10(pretrial_contrast));
        block_p = uml_sweetpoints( pa_block1.est );
        
        for b = 2:length(block_p)
            if  abs(block_p(b) - pretrial_p(b)) <= 0.04
                block_p(b) = pretrial_p(b) + sign(block_p(b) - pretrial_p(b)) * 0.04;
            end
            if block_p(b) > 1 - pa_block1.est(4) - eps
                block_p(b) = 1 - pa_block1.est(4) - eps;
            end
            if block_p(b) < pa_block1.est(3) + eps
                block_p(b) = pa_block1.est(3) + eps;
            end
        end
        
        block_contrasts = 10.^findthreshold('logistic', pa_block1.est, block_p,...
            'performance');
        block_contrasts = min(max(P.range(1) * ones(size(block_contrasts)), block_contrasts), ...
            P.range(2) * ones(size(block_contrasts)));
        
        pauser = pauser_block(N_BLOCK,length(block_p) * N_BLOCK);
        
        switch P.procedure
            case 'block'
                s_iterator = choose_block(block_contrasts,N_BLOCK);
                data_block = exp_contrast_runner(P, L, data_block, stimuli, win, aud, ...
                    trial_executer, s_iterator, m_iterator, pauser);
            case 'interleaved'
                s_iterator = choose_interleaved(block_contrasts,N_BLOCK);
                data_block = exp_contrast_runner(P, L, data_block, stimuli, win, aud, ...
                    trial_executer, s_iterator, m_iterator, pauser);
            case 'adaptive'
                for i = 1:length(block_p)
                    pauser = pauser_block(N_BLOCK,N_BLOCK);
                    sample_range = [max(block_p(i) - 0.1, pa_block1.est(3) + eps), ...
                        min(block_p(i) + 0.1, 1 - pa_block1.est(4) - eps)];
                    sample_range = 10.^findthreshold('logistic', pa_block1.est, ...
                        sample_range, 'performance');
                    sample_range = [max(sample_range(1), P.range(1)), ...
                        min(sample_range(2), P.range(2))];
                    s_iterator = choose_staircase('range', sample_range, ...
                        'init', block_contrasts(i), ...
                        'threshold_p', block_p(i), ...
                        'paradigm', P.paradigm, ...
                        'log_scale', true);
                    data_block = exp_contrast_runner(P, L, data_block, stimuli, ...
                        win, aud, trial_executer, s_iterator, m_iterator, pauser);
                end
        end
        
        %Fit the data
        outputPrefs = psignifit_batch('write_pa', 'pa_block2', 'write_th', 'th');
        psignifit(data_block.get_psignifit_data('log10'), [psign_prefs outputPrefs]);
        
        P.time_off = now;
        P_block2 = P;
        save(path_block2, 'P_pretrial', 'P_block1', 'P_block2', 'data_pretrial', 'pa_pretrial', ...
            'data_block', 'pa_block1', 'pa_block2');
    end
end

P.update_session_task();

msg_goodbye = sprintf('This session is finished. Thank you for participating.');
win.pause_trial(L.list_stop, msg_goodbye);

clearvars win

%p_screen_saver(LUMINANCE_SAVER / mean(P.clut_data.luminance_calibrated(end,:)), ...
%    P.clut_data.clut)