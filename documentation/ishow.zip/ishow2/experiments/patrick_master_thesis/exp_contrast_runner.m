function data = exp_contrast_runner(P, L, data, stimuli, win, aud, trial_executer, ...
    stimulus_iterator, mask_iterator, ...
    pauser)

old_randseed = rng;
% Use shuffle randseed which is fed by the current time. This ensure that
% no reoccuring sequences are generated.
rng('shuffle');
try
    trial_n = 0;
    
    target = NaN;
    response = NaN;
    contrast = NaN;
    mask_contrast = NaN;
    
    % Open the welcome screen
    win.draw(stimuli.crosshair_tex);
    win.flip();
    WaitSecs(2);
    trial_offset = GetSecs;
    while pauser(trial_n) < 2
        
        win.draw(stimuli.crosshair_tex);
        win.flip();
        
        trial_n = trial_n + 1;
        
        
        % Define stimuli
        contrast = stimulus_iterator(trial_n, contrast, ...
            abs(target-2), abs(response-2));
        phase = randi(length(stimuli.gratings));
        
        mask_contrast = mask_iterator(trial_n, mask_contrast, ...
            abs(target-2), abs(response-2));
        mask_phase = randi(length(stimuli.masks));
        
        
        target = randi(2);
        WaitSecs('UntilTime', trial_offset + P.t_iti/1000);
        
        trial_now = now;
        trial_onset = GetSecs;
        buttons = trial_executer(stimuli, phase, contrast, ...
            mask_contrast, mask_phase, ...
            target, P, L, win, aud);
        trial_offset = GetSecs;
        
        % Save the responses and random variables
        [response, response_time] = buttons.get_presses('first');
        
        data.append(contrast, phase, mask_contrast, mask_phase, ...
            target, response, response_time, buttons, ...
            trial_now, trial_onset, trial_offset);
        
        % Store and summarize the data
        if pauser(trial_n)
            block_summary = data.summarize_block();
            display(block_summary);
            data.update_block();
            
            protocol_id = fopen(fullfile(P.path_subject,[P.name_subject,'_protocol.txt']), 'a');
            fprintf(protocol_id, block_summary);
            fclose(protocol_id);
            % If this wasn't the last block of trials, take a break
            if pauser(trial_n) == 1
                win.pause_trial(L.list_stop, ...
                    [sprintf('Break time, push any button to continue. \n'), ...
                    block_summary]);
            else
                win.pause_trial(L.list_stop, ...
                    [sprintf('Session finished, push any button to continue. \n'), ...
                    block_summary]);
            end
            
            win.draw(stimuli.crosshair_tex);
            win.flip();
            WaitSecs(2)
        end
    end
    
    % restore old random seed
    rng(old_randseed);
catch e
    % restore old random seed
    rng(old_randseed);
    % If an error occured, save our progress, close the window, and rethrow
    % the error.
    sca
    rethrow(e);
end