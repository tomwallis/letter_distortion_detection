classdef p_exdata < handle
    %P_EXDATA Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        % Memory preallocation
        contrast;
        phase;
        mask_contrast;
        mask_phase;
        
        target;
        response;
        response_time;
        buttons;
        block;
        
        trial_now;
        trial_onset;
        trial_offset;
        
        n = 0;
        b = 1;
        type; % '2ifc' / 'yn'
    end
    
    methods
        function this = p_exdata(n_trials, type)
            this.contrast = NaN(n_trials, 1);
            this.phase = NaN(n_trials, 1);
            this.mask_contrast = NaN(n_trials, 1);
            this.mask_phase = NaN(n_trials, 1);
            
            this.target = NaN(n_trials, 1);
            this.response = NaN(n_trials, 1);
            this.response_time = NaN(n_trials, 1);
            this.buttons = button_press.empty(n_trials,0);
            this.block = NaN(n_trials,1);
            
            this.trial_now = NaN(n_trials, 1);
            this.trial_onset = NaN(n_trials, 1);
            this.trial_offset = NaN(n_trials, 1);
            
            this.type = type;
        end
        
        function append(this, contrast, phase, mask_contrast, mask_phase, ...
                target, response, response_time, buttons, ...
                trial_now, trial_onset, trial_offset)
            this.n = this.n + 1;
            k = this.n;
            
            this.contrast(k) = contrast;
            this.phase(k) = phase;
            this.mask_contrast(k) = mask_contrast;
            this.mask_phase(k) = mask_phase;
            
            this.target(k) = target;
            this.response(k) = response;
            this.response_time(k) = response_time;
            this.buttons(k) = buttons;
            this.block(k) = this.b;
            
            this.trial_now(k) = trial_now;
            this.trial_onset(k) = trial_onset;
            this.trial_offset(k) = trial_offset;
        end
        
        function data = get_concat(this,k)
            if nargin < 2
                k = this.n;
            end
            data = [this.block(1:k), this.trial_now(1:k), this.trial_onset(1:k), ...
                this.trial_offset(1:k), this.contrast(1:k), this.phase(1:k), ...
                this.mask_contrast(1:k), this.mask_phase(1:k), ...
                this.target(1:k), this.response(1:k), this.response_time(1:k)];
        end
        
        function data = get_psignifit_data(this, scale, k)
            if nargin < 2
                scale = 'linear';
            end
            if nargin < 3
                k = this.n;
            end
            
            switch scale
                case 'linear'
                    data = [this.contrast(1:k), ...
                        this.target(1:k) == this.response(1:k), ones(k,1)];
                case 'log10'
                    data = [log10(this.contrast(1:k)), ...
                        this.target(1:k) == this.response(1:k), ones(k,1)];
            end
        end
        
        function data = get_correct(this, k)
            if nargin < 2
                k = this.n;
            end
            
            data = this.target(1:k) == this.response(1:k);
        end
        
        function update_block(this)
            this.b = this.b + 1;
        end
        
        function summary = summarize_block(this, k)
            if nargin < 2
                k = this.b;
            end
            range = this.block == k;
            locations = this.target(range);
            presses = this.response(range);
            
            misses = isnan(presses);
            press_hit = presses(~misses);
            loc_hit = locations(~misses);
            
            n_misses = sum(misses);
            percent_correct = mean(press_hit == loc_hit);
            avg_rtime = nanmean(this.response_time(range));
            
            summary = [sprintf('\n---- Summary of the last block -----'), ...
                sprintf('\n Number of misses: %.2f', n_misses), ...
                sprintf('\n Percent correct: %.2f', percent_correct * 100), ...
                sprintf('\n Average response time in ms: %.2f', 1000 * avg_rtime)];
            
        end
    end
    
end

