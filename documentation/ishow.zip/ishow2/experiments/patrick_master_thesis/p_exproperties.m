classdef p_exproperties < handle
    %P_EXPROPERTIES Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        
        name_subject;
        path_subject;
        path_data;
        time_on;
        time_off;
        notes;
        
        task_n;
        paradigm;   % '2ifc' / 'siam'
        procedure;  % 'block' / 'interleaved' / 'adaptive'
        mask;       % 'no' / 'grating' / 'plaid'
        
        grating_orientation;
        grating_cycles_deg;
        grating_phases;
        
        mask_orientation;
        mask_cycles_deg;
        mask_contrast;
        mask_phases;
        
        
        clut_data;
        luminance_max;
        luminance_mean;
        bg_color;
        screen_distance;
        screen_name;
        screen_id;
        resolution;
        range;
        
        t_stim;
        t_isi;
        t_resp;
        t_iti;
        img_size;
        
        n_frames_stim;
        v_angle;
        
    end
    
    methods
        function this = p_exproperties(path_data, luminance_mean, ...
                screen_name, screen_id, screen_distance, t_stim, t_isi, ...
                t_resp, t_iti, img_size)
            manual_settings = p_exproperties.ask_settings(path_data);
            
            this.name_subject = manual_settings.subject;
            this.path_subject = fullfile(path_data, this.name_subject);
            this.path_data = path_data;
            this.time_on = now;
            this.time_off = NaN;
            
            this.t_stim = t_stim;
            this.t_isi = t_isi;
            this.t_resp = t_resp;
            this.t_iti = t_iti;
            this.img_size = img_size;
            
            % The next task is picked from a schedule file
            task = this.get_session_task;
            this.task_n = str2num(regexp(task{1}, '\d+','match','once'));
            this.mask = task{2};      % 'no' / 'grating' / 'plaid'
            this.paradigm = task{3};  % '2ifc' / 'siam'
            this.procedure = task{4}; % 'block' / 'interleaved' / 'adaptive'
            this.grating_orientation = str2num(task{5});
            this.grating_cycles_deg = str2num(task{6});
            this.grating_phases = linspace(0,1,10);
            this.mask_orientation = str2num(task{7});
            this.mask_cycles_deg = str2num(task{8});
            this.mask_contrast = str2num(task{9});
            this.mask_phases = linspace(0,1,10);
            
            this.clut_data = p_exproperties.get_latest_clut(this.path_data);
            this.luminance_max = mean(this.clut_data.luminance_calibrated(end,:));
            this.luminance_mean = luminance_mean;
            this.bg_color = this.luminance_mean /  this.luminance_max;
            this.screen_distance = screen_distance;
            this.screen_name = screen_name;
            this.screen_id = screen_id;
            
            % Possible contrast range for the signal
            % The lower limit is defined by the precision of the clut
            % The upper limit is defined bg_color and the mask contrast
            this.range = [1 / length(this.clut_data.clut), ...
               min(this.bg_color, 1 - this.bg_color) / this.bg_color ...
                - this.mask_contrast];
            
            this.resolution = Screen('Resolution', this.screen_id);
            
            this.v_angle = pixel_to_vangle(this.img_size, ...
                this.screen_distance, ...
                this.screen_id);
            this.n_frames_stim = msec_to_nframes(this.t_stim, this.screen_id);
        end
        
        function task = get_session_task(this)
            if ~exist(fullfile(this.path_subject, ...
                    [this.name_subject '_schedule.txt']),'file')
                available = dir(fullfile(this.path_data, 'schedules', 'schedule*.txt'));
                pick = randi(length(available));
                path_file = fullfile(this.path_data, 'schedules', ...
                    available(pick).name);
                movefile(path_file, fullfile(this.path_subject, ...
                    [this.name_subject '_schedule.txt']));
                copyfile(fullfile(this.path_subject, [this.name_subject '_schedule.txt']), ...
                    fullfile(this.path_subject, [this.name_subject '_schedule_backup.txt']));
            end
            % Open the subject specific schedule file
            file_id = fopen(fullfile(this.path_subject, ...
                [this.name_subject '_schedule.txt']));
            
            % Find the number of the last executed task and increase by 1
            n = fscanf(file_id, '%*s %*s\nlast_n=%d\n\n', 1) + 1;
            
            % Find the line for the n-th task
            last_line = fgetl(file_id);
            while ischar(last_line)
                matches = strfind(last_line, ['n=' num2str(n)]);
                if any(matches)
                    fprintf(last_line);
                    break;
                else
                    last_line = fgetl(file_id);
                end
            end
            fclose(file_id);
            task = regexp(last_line, '\s*','split');
        end
        
        function update_session_task(this)
            % Open the subject specific schedule file
            file_id = fopen(fullfile(this.path_subject, ...
                [this.name_subject '_schedule.txt']));
            replaceLine = 2;
            
            fid2=fopen(fullfile(this.path_subject, ...
                [this.name_subject '_schedule2.txt']),'wt');
            id = 0;
            a = fgets(file_id);
            while(ischar(a))
                id = id + 1;
                if id == replaceLine
                    a = ['last_n=', num2str(this.task_n), '\n'];
                    continue
                else
                    fprintf(fid2,a);
                end
                a=fgets(file_id);
            end
            fclose(file_id); fclose(fid2);
            movefile(fullfile(this.path_subject, ...
                [this.name_subject '_schedule2.txt']), ...
                fullfile(this.path_subject, [this.name_subject '_schedule.txt']));
        end
    end
    
    methods (Static)
        function clut_data = get_latest_clut(path_data)
            available = dir(fullfile(path_data, 'calibration', 'clut*.mat'));
            [~, pick] = max([available.datenum]);
            path_file = fullfile(path_data, 'calibration', ...
                available(pick).name);
            clut_data = load(path_file);
        end
        
        function P = ask_settings(path, varargin )
            %ASK_SETTINGS Summary of this function goes here
            %   Detailed explanation goes here
            
            
            answers = inputdlg([{'Subject Pseudonym', 'Monitor distance (mm)', ...
                'Notes'} , varargin(:)]);
            
            P.subject = answers{1};
            P.screen_distance = str2double(answers{2});
            P.notes = answers{3};
            
            while ~isdir(fullfile(path, P.subject))
                c = questdlg(['Subject pseudonym does not exist yet. Do you want to ' ...
                    'create a new subject? If you press No you will be able to ' ...
                    'reenter the subject pseudonym.'],['Unrecognized subject ' ...
                    'pseudonym'],'Yes','No','No');
                if strcmpi(c, 'Yes')
                    mkdir(fullfile(path, P.subject));
                    h = msgbox('The subject folder has been created.','modal');
                    pause(1);
                    delete(h);
                elseif strcmpi(c, 'No')
                    temp_name = inputdlg('Subject Pseudonym');
                    P.subject = temp_name{1};
                end
            end
            
            
            for i = 1:length(varargin)
                P.(varargin{i}) = answers{i + 3};
            end
            
            h = msgbox('All manual options have been successfully set.','modal');
            pause(1);
            delete(h);
        end
    end
end

