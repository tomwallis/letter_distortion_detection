classdef p_exstimuli < handle
    %P_EXPROPERTIES Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        
        gratings;
        gratings_phase;
        gratings_tex;
                
        masks;
        masks_phase;
        masks_tex;
                
        t_window;
        s_window;
        s_window_tex;
        
        crosshair;
        crosshair_tex;
    end
    
    methods
        function this = p_exstimuli(gratings, gratings_phase, gratings_tex,...
                                    masks, masks_phase, masks_tex, ...
                                    t_window, s_window, s_window_tex, ...
                                    crosshair, crosshair_tex)
        this.gratings = gratings;
        this.gratings_phase = gratings_phase;
        this.gratings_tex = gratings_tex;
                
        this.masks = masks;
        this.masks_phase = masks_phase;
        this.masks_tex = masks_tex;
                
        this.t_window = t_window;
        this.s_window = s_window;
        this.s_window_tex = s_window_tex;
        
        this.crosshair = crosshair;
        this.crosshair_tex = crosshair_tex;
        end
    end
    
end

