%% Define trial function

function response = trial_2ifc_contrast(stimuli, phase, contrast, ...
                                 mask_contrast, mask_phase, ...
                                 target, P, L, win, aud)

s_contrast = michelson_to_scale(contrast, win.bg_color);
m_contrast = michelson_to_scale(mask_contrast, win.bg_color);

% First interval
aud.play('short_low');
for i = 1 : P.n_frames_stim
    if target == 1
        win.draw_additive(stimuli.gratings_tex(phase), ...
                            stimuli.t_window(i) * s_contrast);
    end
    win.draw_additive(stimuli.masks_tex(mask_phase), ...
                        stimuli.t_window(i) * m_contrast);
    win.draw_mask(stimuli.s_window_tex);
    win.draw(stimuli.crosshair_tex);
    win.flip();
end
aud.play('short_med');


% ISI
t = GetSecs; % Start time of inter stimulus interval
win.draw(stimuli.crosshair_tex); % Empty the screen
win.flip();
WaitSecs('UntilTime', t + P.t_isi/1000);

% Second interval
aud.play('short_high');
for i = 1 : P.n_frames_stim
    if target == 2
        win.draw_additive(stimuli.gratings_tex(phase), ...
                            stimuli.t_window(i) * s_contrast);
    end
    win.draw_additive(stimuli.masks_tex(mask_phase), ...
                        stimuli.t_window(i) * m_contrast);
    win.draw_mask(stimuli.s_window_tex);
    win.draw(stimuli.crosshair_tex);
    win.flip();
end
aud.play('short_med');


% Response interval
L.list_wait.start(); % start listening to input

t = GetSecs; % Start time of response interval
win.draw(stimuli.crosshair_tex); % Empty the screen
win.flip();
WaitSecs('UntilTime', t + P.t_resp/1000);

response = L.list_wait.stop(); % stop listening to input

% Give feedback
if target == 1
    aud.play('long_low');
else
    aud.play('long_high');
end

end