%% Define trial function

function contrast = trial_adj_contrast(stimuli, phase, contrast, ...
                                       mask_contrast, mask_phase, ...
                                       P, L, win)

step_size = 0.01;
m_scale = michelson_to_scale(mask_contrast, P.bg_color);

listener = L.list_adj;

while true    
    
    win.draw_additive(stimuli.gratings_tex(phase), ...
                        michelson_to_scale(contrast, P.bg_color));
    win.draw_additive(stimuli.masks_tex(mask_phase), m_scale);
    win.draw_mask(stimuli.s_window_tex);
    win.draw(stimuli.crosshair_tex);
    win.flip();
    
    % Wait for response
    listener.start();
    while true
        try
            listener.check();
        catch e
            if strcmp(e.identifier, 'iShow:ResponseInterrupt')
                resp = listener.stop();
                break
            else
                rethrow(e);
            end
        end        
    end
    
    % Handle responses
    resp.button_states;
    
    switch resp.get_presses()
      case 1
        contrast = contrast - step_size;
        if contrast < P.range(1)
            contrast = P.range(1);
        end
        %fprintf('Contrast is %0.4f\n', s_contrast);
      case 2
        contrast = contrast + step_size;
        if contrast > P.range(2)
            contrast = P.range(2);
        end
        %fprintf('Contrast is %0.4f\n', s_contrast);
      case 3
        break;
      case 4
        step_size = step_size * 2;
        %fprintf('Step size is %0.4f\n', step_size);
      case 5
        step_size = step_size / 2;
        %fprintf('Step size is %0.4f\n', step_size);
    end
end

end