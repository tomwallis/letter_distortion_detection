function [rect_pos, rect_in, rect_out] = define_multirect(varargin)
%define_multirect returns rects for spatial mAFC centered inside of a
%bigger rect
%   Inputs:
%   'size' - Defines the arrangement of patches according to matrix
%   dimensions (default [1 1])
%   'size_patch' - specifies the size of an individual patch
%   'margin_patch' - the margin is added on each side of an individual
%   patch rect. It specifies the distance between neighbouring patches,
%   where margin = 1/2 distance.
%   'rect_patch' - rect of an individual patch. If 'size' is specified this
%   parameter will be ignored and overwritten.
%   'rect_window' - rect of the window in which the multirect should be
%   centered.
%
%   Output:
%   rect_pos - Final postitions of each patch sorted from left to right
%   rect_in  - Like rect_pos but including the margin to each side
%   rect_out - The rect surrounding all rect_pos
%
%   Example:
%   define_multirect('size',[2 2],'rect_win',[0 0 1024 800],...
%                     'margin_patch', 10, 'size_patch',[100 100]);
%   Returns a 2 by 2 multirect  for 100 by 100 sized patches centered 
%   inside of a window with rect [0 0 1024 800]. Between individual patches
%   the distance is 2 times the 'margin_patch': 20.
%
%   Winrect
%   -------------------------------------------------
%   .                                               .
%   .                                               .
%   .           -------- --------                   .
%   .          |   --   |        |                  .
%   .          |  |  |  |        |                  .
%   .          |   --   |        |                  .
%   .           -------- --------                   .
%   .                                               .
%   .                                               .
%   .                                               .
%   .                                               .
%   .                                               .
%   .                                               .
%   .                                               .
%   -------------------------------------------------
%
%

%% Define defaults

D.size = [1 1];
D.size_patch = [];
D.margin_patch = 0;
D.rect_patch = [0 0 300 300];
D.rect_win = [0 0 400 400];


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    rect_pos= D;
    return
end

D = update_struct(D, varargin{:}, 'ignore');

if ndims(D.size) == 1
   D.size = [D.size D.size];
end

% Overwrites rect_patch if size_patch is given
if ~isempty(D.size_patch)
    D.rect_patch = RectOfMatrix(ones(D.size_patch));
end


%% Find rects

% Find the rect which surround all subrects
N = D.size(1) * D.size(2);
rect_margin = InsetRect(D.rect_patch,-D.margin_patch,-D.margin_patch);
rect_out = ScaleRect(rect_margin,D.size(2),D.size(1));
rect_out = CenterRect(rect_out,D.rect_win);

if sum(SizeOfRect(rect_out) > SizeOfRect(D.rect_win))
    warning(['rect_patch is too large for the proposed multirect. ', ...
    'Using rect_pos might result in overlapping patches.']);
end

% Place all rects inside of rect rect_out just next to each other
rect_in = ArrangeRects(N,rect_margin,rect_out);
% Find the final rects for each single patch
rect_pos = NaN(size(rect_in));
for n = 1:N
    rect_pos(n,:) = InsetRect(rect_in(n,:),D.margin_patch,D.margin_patch);
end

end
