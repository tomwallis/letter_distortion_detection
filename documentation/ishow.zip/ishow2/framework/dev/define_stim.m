function R = define_stim(varargin)
%function R = define_stim(varargin)
%

P = stim_defaults();
R = update_struct(P, varargin{:}, 'add');



if ~iscell(R.variable_param)
    R.variable_param = {R.variable_param};
end
