function R = patch_crosshair(varargin)
%patch_crosshair generates an rgb or grayscale crosshair patch
%   Input variables:
%   'type' - type of crosshair ('corner','center')
%   'size' - size of the patch on which we want to put the crosshair
%   'rect' - rect of the patch on which we want to put the crosshair. If
%            specified this overwrites 'size'
%   'h_window' - window handle, necessary to create a texture
%   'thickness' - thickness of the crosshair lines
%   'length' - length of the crosshair lines
%   'color' - color of crosshair lines [grayscale, rgb]
%   'opacity' - alpha level of the crosshair
%
%   Output:
%   'patch' - rgb or grayscale image of the specified crosshair with 
%   size(patch) = [M,N,3+1] for rgb and size(patch) = [M,N,1+1] for
%   grayscale, where the last layer of dimension 3 is an alpha layer
%   'h_texture' - texture handle for the crosshair. Is only returned of
%   'h_window' has been specified.

% Default values
P = patch_defaults;
P.type = 'corner';
P.rect = [];
P.thickness = 1;    
P.length = 5;       
P.color = 1;
P.opacity = 1;
P.h_texture = NaN;
P.h_window = NaN;
P.draw_rule.function = @draw_with_alpha;
P.draw_rule.contrast = NaN;

% Returns the default values
if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    R = P;
    return
end

P = update_struct(P, varargin{:}, 'ignore');

if ~isempty(P.rect)
    P.size = SizeOfRect(P.rect);
end

%% Error throwing
if (length(P.color(:)) ~= 1 && length(P.color(:)) ~= 3) || ...
   sum(P.color(:) > 1) || sum(P.color(:) < 0)
    error(['color must be specified as a one-dimensional grayscale ',...
          'value in the interval [0,1] or as a 3-dimensional rgb vector'...
          'with each dimension in the interval [0,1]'])
end

%% Patch generation
switch lower(P.type)
  case 'corner'
    make_crosshair = @(n) corner(P);
  case 'center'
    make_crosshair = @(n) center(P);
    if    ((mod(P.length,2) || mod(P.thickness,2)) ...
       && (~mod(P.size(1),2) || ~mod(P.size(2),2))) || ...
          ((~mod(P.length,2) || ~mod(P.thickness,2)) ...
       && (mod(P.size(1),2) || mod(P.size(2),2)))
        
        error(['Crosshair length and thickness should be even or odd ',...
               'dependent on whether the patch size is even or odd!']);
    end
  otherwise
    error(['Unrecognized crosshair type : "',P.type]);
end

R = make_crosshair(P);

%% For OpenGL textures
if isnan(P.h_window)
    R.h_texture = NaN;
else
    R.h_texture = Screen('MakeTexture', P.h_window, R.patch, [], [], 1);
end

%% Fill return structure with properties
R = update_struct(P,R,'add');
R = define_stim(R);

end

function R = corner(P)
    % Resize crosshair patch
    patch = ones([P.size+2*P.thickness, length(P.color)]);
    for i = 1:length(P.color)
        patch(:,:,i) = patch(:,:,i)*P.color(i);
    end
    % Make first corner
    alpha_chan = zeros(size(patch(:,:,1)));
    alpha_chan(1:P.thickness,1:P.length) = 1;
    alpha_chan(1:P.length,1:P.thickness) = 1;
    
    % Replicate corner
    alpha_chan = alpha_chan + fliplr(alpha_chan);
    alpha_chan = alpha_chan + flipud(alpha_chan);

    patch(:,:,end+1) = alpha_chan * P.opacity;
    R.patch = patch;
    
    % Rect size has been changed since the crosshair will be attached to the
    % outside of the orginial patch
    if ~isnan(P.rect)
        R.rect = InsetRect(P.rect,-P.thickness,-P.thickness);
    end
    R.size = size(patch(:,:,1));
end

function R = center(P)
    % Make crosshair patch
    patch = ones([P.size, length(P.color)]);
    for i = 1:length(P.color)
        patch(:,:,i) = patch(:,:,i)*P.color(i);
    end
    % Prepare alpha layer
    alpha_chan = zeros(size(patch(:,:,1)));
    
    % Set alpha level to one for all pixels within the crosshair
    
    % Vertical line - find it's upper left corner
    % Upmost pixel
    row_offset = floor((P.size(1) - P.length)/2)+1;
    % Leftmost pixel
    column_offset = floor((P.size(2) - P.thickness)/2)+1;
    % Draw vertical line
    alpha_chan(row_offset:(row_offset + P.length - 1), ...
               column_offset:(column_offset + P.thickness - 1)) = 1;
    
    % Horizontal line - find it's upper left corner
    % Upmost pixel
    row_offset = floor((P.size(1) - P.thickness)/2)+1;
    % Leftmost pixel
    column_offset = floor((P.size(2) - P.length)/2)+1;
    % Draw horizontal line
    alpha_chan(row_offset:(row_offset + P.thickness - 1), ...
               column_offset:(column_offset + P.length - 1)) = 1;
    
    patch(:,:,end+1) = alpha_chan * P.opacity;
    R.patch = patch;
end