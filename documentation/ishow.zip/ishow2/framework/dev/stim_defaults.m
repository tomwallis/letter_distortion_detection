function R = stim_defaults()
%function R = stim_defaults()
%
% Define default values shared by all stimulus structures:
%  - name : how the session knows this stimulus, defaults to empty str, which
%           is sufficient for any stimulus that does not need to be adressed
%           directly. For stimuli that do need to be target (because their
%           parameters need to be changed from trial to trial) it is
%           recommend to provide a meaningful name
%  - onset : the frame on which the stimulus starts running during its
%            interval, this defaults to 1.
%  - variable_param : Cellstring of the names of the parameters that change on
%                     a trial-by-trial bases. This defaults to empty.
% 

R.name = '';
R.onset = 1;
R.variable_param = {};
