function R = summarize_2fc_data(locations, presses, times, verbose)
%function R = summarize_data(locations, presses, times, verbose)
%
% Return a structure with fields summarizing the data. If verbose is
% true, display this information on the screen as well.
%
if nargin < 4
    verbose = true;
end

R.misses = isnan(presses);
press_hit = presses(~R.misses);
loc_hit = locations(~R.misses);

R.n_misses = sum(R.misses);
R.misses = find(R.misses);



R.percent_correct = mean(press_hit == loc_hit);
left = loc_hit == 1;
right = loc_hit == 2;
R.percent_correct_distrib = ...
    [mean(press_hit(left) == loc_hit(left)), ...
     mean(press_hit(right) == loc_hit(right))];
R.location_distrib = [mean(locations == 1), mean(locations == 2)];
R.presses_distrib = [mean(press_hit == 1), mean(press_hit == 2)];

if verbose
    disp(sprintf('\n'));
    disp(sprintf('---- trial summary -----'));
    disp(sprintf('n misses: %.2f', R.n_misses));
    disp(sprintf('%% correct: %.2f',R.percent_correct));
    disp(sprintf('%% correct on left: %.2f', ...
                 R.percent_correct_distrib(1)));
    disp(sprintf('%% correct on right: %.2f', ...
                 R.percent_correct_distrib(2)));
    disp(sprintf('\n'));                        
end
