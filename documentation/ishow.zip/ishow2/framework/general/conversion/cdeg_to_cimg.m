function c_img = cdeg_to_cimg( c_deg, v_angle )
%CDEG_TO_CIMG converts cylces/degree into cycles/image
%   c_deg - the number of cycles per degree of visual angle
%   v_angle - the visual angle that an image occupies on the retina
%
% Output
%   c_img - the number of cycles/image
c_img = c_deg * v_angle;


end

