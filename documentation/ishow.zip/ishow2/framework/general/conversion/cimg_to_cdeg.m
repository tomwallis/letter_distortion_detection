function c_deg = cimg_to_cdeg( c_img, v_angle )
%CDEG_TO_CIMG converts cycles/image into cylces/degree of visual angle
%   c_img - the number of cycles/image
%   v_angle - the visual angle that an image occupies on the retina
%
% Output
%   c_deg - the number of cycles per degree of visual angle
c_deg = c_img / v_angle;

end
