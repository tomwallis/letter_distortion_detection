function scale = michelson_to_scale( contrast, mean_luminance )
%MICHELSON_TO_SCALE returns the scale of the maximum and minimum luminance
% a periodic signal with a given michelson contrast.
% 
% contrast - the michelson contrast of the periodic signal defined as
%            c = (l_max - l_min) / (l_max + l_min)
%              = (l_max - l_min) / (2 * l_mean)
%              = (1*scale - (-1 * scale)) / (2 * l_mean)
%              = (2*scale) / (2 * l_mean)
% mean_luminance - the mean luminance of the screen: l_mean
%
% Output:
% scale - the scale of the luminances around their mean, i.e. 
%         l_min = l_mean - scale; l_max = l_mean + scale;
%         From above: scale = c / l_mean;
    
scale = contrast * mean_luminance;

end

