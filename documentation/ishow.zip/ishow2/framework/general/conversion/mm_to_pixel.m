function [ pixel, exact_mm ] = mm_to_pixel( x_mm, screen_id )
%MM_TO_PIXEL converts width (x(1)) and height (x(2)) from mm into the
%            number of pixel for the given screen with screen_id.
%   x_mm(1) - width in millimeter
%   x_mm(2) - height in millimeter
%   screen_id - system assigned id of the screen
%  
%   Output:
%   pixel - pixel.width, number of pixels in the horizontal direction
%           pixel.height, number of puxels in the vertical direction
%           pixel.res, a vector of [pixel.width; pixel.height]
%   exact_mm - due to pixel size and rounding issues the corrected values 
%              for x_mm are returned.
[screen_w, screen_h]=Screen('DisplaySize', screen_id);
screen_res = Screen('Resolution', 0);

% Pixel width and height in millimeter
pixel_w = screen_w / screen_res.width;
pixel_h = screen_h / screen_res.height;

% Calculate the number of pixels in every dimension
pixel.width = ceil(x_mm(1) / pixel_w); % round up!
pixel.height = ceil(x_mm(2) / pixel_h);
pixel.res = [pixel.width; pixel.height];

% Since we round up the number of pixels the effective size in millimeter
% is calculated
exact_mm(1) = pixel.width * pixel_w;
exact_mm(2) = pixel.height * pixel_h;

end

