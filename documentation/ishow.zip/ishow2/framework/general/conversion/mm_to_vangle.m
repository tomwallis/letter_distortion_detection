function v_angle = mm_to_vangle( diameter, distance )
%MM_TO_VANGLE converts a size of a projected image to the respective visual
%             angle for a screen with specified distance.
% 
% diameter - diameter of the projected image on the screen in millimeter
% distance - the distance of eye to screen in millimeter
% 
% Output:
% v_angle - visual angle in degrees

v_angle = 2 * atand(diameter / (2 * distance));

end