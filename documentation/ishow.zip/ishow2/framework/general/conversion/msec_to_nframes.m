function [n_frames, exact_msec] = msec_to_nframes(m_sec, screen_id)
% MSEC_TO_NFRAMES converts milliseconds into a corresponding number of
% frames dependent on the refresh rate of a given screen.
%
%   m_sec - time in milliseconds
%   screen_id - system assigned id of the screen
% 
% Output
%   n_frames - number of frames that can be shown in the specified  number
%              of milliseconds. n_frames is always rounded up.
%   exact_msec - since n_frames is always rounded up, the exact time
%                needed to show n_frames is calculated.

    screen_res = Screen('Resolution', screen_id);
    frame_msec = 1000 / screen_res.hz;
    n_frames = ceil(m_sec / frame_msec);
    
    exact_msec = nframes_to_msec(n_frames, screen_id);
end