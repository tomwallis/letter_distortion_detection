function m_sec = nframes_to_msec(n_frames, screen_id)
% NFRAMES_TO_MSEC corresponds a number of frames into tim in milliseconds
% dependent on the resfresh rate of a given screen.
%
%   n_frames - number of frames
%   screen_id - system assigned id of the screen
% 
% Output
%   m_sec - time in milliseconds

    screen_res = Screen('Resolution', screen_id);
    frame_msec = 1000 / screen_res.hz;
    m_sec = n_frames * frame_msec;
end