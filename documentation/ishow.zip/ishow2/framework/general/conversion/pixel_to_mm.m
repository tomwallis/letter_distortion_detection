function x_mm = pixel_to_mm( pixel, screen_id )
%PIXEL_TO_MM converts a resolution in pixels into the size of the 
%            projection on a specified screen (in mm).
%            number of pixel for the given screen with screen_id.
%   pixel(1) - number of pixels in the horizontal direction
%   pixel(2) - number of pixels in the vertical direction
%   screen_id - system assigned id of the screen
%  
%   Output:
%   x_mm(1) - width in millimeter
%   x_mm(2) - height in millimeter

[screen_w, screen_h] = Screen('DisplaySize', screen_id);
screen_res = Screen('Resolution', screen_id);

% Pixel width and height in millimeter
pixel_w = screen_w / screen_res.width;
pixel_h = screen_h / screen_res.height;

x_mm(1) = pixel(1) * pixel_w;
x_mm(2) = pixel(2) * pixel_h;

end