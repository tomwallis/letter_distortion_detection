function v_angle = pixel_to_vangle(pixel, distance, screen_id)
% VANGLE_TO_PIXEL converts a number of pixels on a given screen to a visual
% angle given the distance to teh screen.
%
% pixel(1) - number of pixels in the horizontal direction
% pixel(2) - number of pixels in the vertical direction
% distance - the distance of eye to screen in millimeter
% screen_id - system assigned id of the screen
% 
% Output:
%   v_angle - visual angle in degrees
    
    % Conert pixel to size in mm
    x_mm = pixel_to_mm( pixel, screen_id );
    
    % Convert the diameter into the pixel resolution on the screen
    v_angle = mm_to_vangle( x_mm, distance);
end