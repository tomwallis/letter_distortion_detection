function diameter = vangle_to_mm( v_angle, distance )
%VANGLE_TO_MM converts a visual angle to the a projection size on a screen
%             with specified distance.
% v_angle - visual angle in degrees
% distance - the distance of eye to screen in millimeter
% 
% Output:
% diameter - diameter of the projected image on the screen in millimeter

diameter = tand(0.5 * v_angle) * 2 * distance;

end

