function [ pixel, exact_angle ] = vangle_to_pixel(v_angle, distance, screen_id)
% VANGLE_TO_PIXEL converts a visual angle to a pixel resolution onf a given
%                 screen.
% v_angle - visual angle in degrees
% distance - the distance of eye to screen in millimeter
% screen_id - system assigned id of the screen
% 
% Output:
%   pixel - pixel.width, number of pixels in the horizontal direction
%           pixel.height, number of puxels in the vertical direction
%           pixel.res, a vector of [pixel.width; pixel.height]
%   exact_angle - due to pixel size and rounding issues the corrected 
%                 values for v_angle in the horizontal and vertical 
%                 direction, respectively.

    % Convert angle into diameter on screen
    diameter = vangle_to_mm( v_angle, distance );
    
    % Convert the diameter into the pixel resolution on the screen
    [ pixel, exact_mm ] = mm_to_pixel( [diameter; diameter], screen_id );
    
    % Correction for rounding and different pixel sizes in the horizontal
    % and vertical direction
    exact_angle(1) = mm_to_vangle(exact_mm(1), distance);
    exact_angle(2) = mm_to_vangle(exact_mm(2), distance);
end