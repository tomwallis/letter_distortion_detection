function curve = curve_gauss(varargin)
%function curve = curve_gauss(varargin)
%
% Return a 2-d gaussian curve.
%
% Inputs:
%   size - length of the resulting curve
%   var or std - width of the gaussian (var = std^2)
%   mean - mean of the gaussian
%   normalize - if true, normalizes the integral of the gaussian to 1,
%               otherwise the maximum point of the gaussian equals 1
%   cutoff - borders of the axis [left right]
%
% More information on how to pass arguments can be accessed via:
% help argument_passing


%% Define defaults

D.size = 300;
D.var = 1;
D.std = NaN;
D.mean = 0;
D.normalize = false;
D.cutoff = [-3, 3];


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    curve = D;
    return
end

D = update_struct(D, varargin{:}, 'ignore');

if ~isnan(D.std)
    D.var = D.std^2;
end


%% Generate curve

x = linspace(D.cutoff(1), D.cutoff(2), D.size);

if D.normalize
    Z = 1 / ((2 * pi * D.var)^.5);
else
    Z = 1;
end

curve = Z * exp(-0.5 * (x - D.mean).^2 / D.var);


