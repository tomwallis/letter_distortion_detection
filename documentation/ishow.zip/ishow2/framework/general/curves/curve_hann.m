function curve = curve_hann(varargin)
%function curve = curve_hann(varargin)
%
% Return a 2-d hann curve.
%
% Inputs:
%   size - length of the resulting curve
%
% More information on how to pass arguments can be accessed via:
% help argument_passing


%% Define defaults

D.size = 300;

%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    curve = D;
    return
end

D = update_struct(D, varargin{:}, 'ignore');


%% Generate curve

curve = hann(D.size);


