function curve = curve_tapered_cosine(varargin)
%function curve = curve_tapered_cosine(varargin)
%
% Return a 1-d tapered cosine curve with a plateau.
%
% Inputs:
%   size - length of the resulting curve (default 300)
%
%   alpha - relative size of the hann: alpha * size = length of the hann
%   component. The rest of the curve, i.e. (1-alpha) * size is covered by a
%   rectangular window. The hann curve is halved and attached to the ends
%   of the rectangular window. (default 0.5). A value of alpha = 1 leads to
%   a regular hann window, whereas alpha = 0 leads to a rectanguar window.
%
% See also: tukeywin, argument_passing
%
% More information on how to pass arguments can be accessed via:
% help argument_passing


%% Define defaults

D.size = 300;
D.alpha = 0.5;

%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    curve = D;
    return
end

D = update_struct(D, varargin{:}, 'ignore');


%% Generate curve

curve = tukeywin(D.size,D.alpha);