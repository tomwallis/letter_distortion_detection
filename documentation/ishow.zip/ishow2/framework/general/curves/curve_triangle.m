function curve = curve_triangle(varargin)
%function curve = curve_triangle(varargin)
%
% Return a 2-d triangle curve.
%
% Inputs:
%   size - length of the resulting curve
%
% More information on how to pass arguments can be accessed via:
% help argument_passing


%% Define defaults

D.size = 300;

%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    curve = D;
    return
end

D = update_struct(D, varargin{:}, 'ignore');


%% Generate curve

half = linspace(0, 1, floor(D.size / 2));
% if size is even paste two halves together
if mod(D.size, 2) == 0
    curve = [half fliplr(half)];
% else paste two halves together, skipping apex of second half
else
    curve = [half fliplr(half(1 : end-1))];
end