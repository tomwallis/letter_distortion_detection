function h = choose_block(orders, n_repeat)
%function h = choose_circular(orders)
%
% Return a function handle that, when called, iterates through the columns
% in orders, repeating each column 'n_repeat' times.

n = size(orders, 2);
i = 0;
idx = 1;
    function order = chooser(varargin)
        order = orders(:, idx);
        i = i + 1;
        idx = floor(i / n_repeat) + 1;
    end
    
h = @chooser;

end
