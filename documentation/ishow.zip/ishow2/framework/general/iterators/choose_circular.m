function h = choose_circular(orders)
%function h = choose_circular(orders)
%
% Return a function handle that, when called, iterates through the columns
% in orders, and after having returned the last column, returns to the first
% column.

n = size(orders, 2);
i = 1;    
    function order = chooser(varargin)
        order = orders(:, i);
        i = mod(i, n) + 1;
    end
    
h = @chooser;

end
