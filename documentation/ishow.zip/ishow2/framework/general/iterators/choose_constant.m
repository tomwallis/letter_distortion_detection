function h_adapt = choose_constant(value)

%% Define defaults
h_adapt = @constant;

    function signal = constant(varargin)
        signal = value;
    end
end
