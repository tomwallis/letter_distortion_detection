function h = choose_interleaved(orders, n_repeat)
%function h = choose_circular(orders)
%
% Return a function handle that, when called, randomly returns one of the 
% values defined in orders.

    function order = chooser(varargin)
        order = orders(randi(length(orders(:))));
    end
    
h = @chooser;

end
