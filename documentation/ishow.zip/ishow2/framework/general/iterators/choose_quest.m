function h_adapt = choose_quest(varargin)
%function h = choose_circular(orders)
%
% Return a function handle that, when called, iterates according to the
% quest rule.
% 
% Input:
%
% 'chance' - the chance level of the given task (0.5)
% 'lapse_rate' - the assumed rate at which the subject lapses (0.01)
% 'slope' - assumed slope of the psychometric function (3.5)
% 'threshold_mu' - initial guess or mean of the threshold prior (2)
% 'threshold_std' - standard deviation of the threshold_prior (4). It is
%                   recommended to choose a big value here.
% 'range' - the absolute range of possible signal intensities. The function
%           handle will not return any values outside of this interval 
%           ([0, 5]).
% 'threshold_p' - p-value at which quest should sample (0.75). This value
%                 should be chosen dependent on the chance level of the
%                 task. Recommended is choosing the p-value of the
%                 infliction point on the psychometric function.
%
%% Define defaults

D = struct('chance',0.5, ...
           'lapse_rate', 0.01, ...
           'slope', 3.5, ...
           'threshold_mu', 2, ...
           'threshold_std', 4, ...
           'range', [0, 5], ...
           'threshold_p', 0.75, ...
           'forced_choice', true);
P = update_struct(D, varargin{:});

% Initialization of the quest routine
P.quest = QuestCreate((P.threshold_mu), P.threshold_std, P.threshold_p, ...
                P.slope, P.lapse_rate, P.chance);
P.quest.normalizePdf = 0;

h_adapt = @adaptive;

    function signal = adaptive(~, last_signal, last_target, last_response)
        %last_signal = log10(last_signal);
        % Update the quest struct in case there is a new observation

        if nargin >=3 && ~ (isnan(last_signal) || isnan(last_target) ...
                                               || isnan(last_response))
            if P.forced_choice
                P.quest = QuestUpdate(P.quest, last_signal, ...
                                      last_target == last_response);
            else
                P.quest = QuestUpdate(P.quest, last_signal, last_response);
            end
        end
        
        % Get a signal recommendation from the quest routine
        signal = QuestMean(P.quest); % 10^QuestQuantile(P.quest); % QuestMean(P.quest);
        
        % Sanity check for teh range of the recommended signal
        if signal < min(P.range)
            signal = min(P.range);
        elseif signal > max(P.range)
            signal = max(P.range);
        end
    end
end
