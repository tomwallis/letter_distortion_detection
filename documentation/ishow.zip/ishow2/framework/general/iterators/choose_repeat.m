function iter = choose_repeat(vals, repeats, circular)
%function choose_repeat(vals, repeats, circular)
%
% Return a function handle that returns each value in vals its corresponding
% entry in repeats times. If circular is true, it then returns back to the
% first value and keeps going.
%
% p.ex.:
%
% choose_repeats([1, 2, 3], [1, 2, 3], false)
% Gets, in order, when called
% 1 2 2 3 3 3
% after the last three, if it's called again, it throws a StopIteration
% error. If circular were true, it would start over and repeat this pattern
% infinitely.
%
% circular defaults to true
%

if nargin < 3
    circular = true;
elseif nargin < 2
    error('Input at least a vals and repeats value');
end

assert(length(vals) == length(repeats), 'vals and repeats do not match');

vector = [];
for i = 1 : length(vals)
    vector = [vector repmat(vals(i), 1, repeats(i))];
end

if circular
    iter = iterate_circular(vector);
else
    iter = iterate(vector);
end
