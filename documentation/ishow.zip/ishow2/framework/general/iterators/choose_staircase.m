function h_adapt = choose_staircase(varargin)
%function h_adapt = choose_stairacse(varargin)
%
% Return a function handle that, when called, iterates according to the
% quest rule.
%
% Input:
%
% 'range' - the absolute range of possible signal intensities. The function
%           handle will not return any values outside of this interval
%           ([0.00001, 1]).
% 'init' - Starting value of the staircase (1).
% 'threshold_p' - p-value at which quest should sample (0.75). This value
%                 should be chosen dependent on the chance level of the
%                 task. Recommended is choosing the p-value of the
%                 infliction point on the psychometric function.
% 'paradigm' - defines which experimental paradigm is used. Choose between
%              '2ifc' and 'siam' (see Kaernbach, 1990). (default = '2ifc')
% 'log_scale' - defines whether the staircase should operate on a log10
%               scale. (default = false)
%% Define defaults

D = struct('range', [0.00001, 1], ...
    'init', 1, ...
    'threshold_p', 0.75, ...
    'paradigm', '2ifc', ...
    'log_scale', false);
P = update_struct(D, varargin{:},'ignore');

if P.log_scale
    P.step = 10^(diff(log10(P.range)));
else
    P.step = diff(P.range);
end

switch P.paradigm
    case '2ifc'
        P.iterator = @choose_afc;
    case 'siam'
        P.iterator = @choose_siam;
    otherwise
        error('Please specify a legal experimental paradigm!')
end

saved_signal = P.init;
saved_response = 0;
reversals = 0;
count = 0;

h_adapt = @adaptive;
    function signal = adaptive(~, last_signal, last_target, last_response)
        
        if nargin >= 4
            signal = P.iterator(last_signal, last_target, last_response);
        else 
            signal = P.iterator(NaN, NaN, NaN);
        end
        
        % Sanity check for teh range of the recommended signal
        if signal < min(P.range)
            signal = min(P.range);
        elseif signal > max(P.range)
            signal = max(P.range);
        end
    end

    function signal = choose_afc(last_signal, last_target, last_response)
        
        if ~isnan(last_signal)
            signal = last_signal;
        else
            signal = saved_signal;
        end
        
        response = saved_response;
        if ~(isnan(last_signal) || isnan(last_target) || isnan(last_response))
            count = count + 1;
            response = last_target == last_response;
            % Accelerated stochastic approximation
            if P.log_scale
                signal = 10^(log10(last_signal) ...
                    - (log10(P.step)) / (2 + reversals) * (response - P.threshold_p));
            else
                signal = last_signal ...
                    - P.step / (2 + reversals) * (response - P.threshold_p);
            end
            if count > 1 && response ~= saved_response
                reversals = reversals + 1;
            end
        end
        saved_signal = signal;
        saved_response = response;
    end

    function signal = choose_siam(last_signal, last_target, last_response)

        if ~isnan(last_signal)
            signal = last_signal;
        else
            signal = saved_signal;
        end
        response = saved_response;
        
        if ~(isnan(last_signal) || isnan(last_target) || isnan(last_response))
            count = count + 1;
            t = 2 * P.threshold_p - 1;
            m = (-1)^(last_response && last_target) ...
                * (t / (1 - t))^(~last_response && last_target) ...
                * (1 / (1 - t))^(last_response && ~last_target) ...
                * (0)^(~last_response && ~last_target) ...
                / (1 + (t / (1 - t)) + (1 / (1 - t)));
                
            
            % Accelerated stochastic approximation
            if P.log_scale
                signal = 10^(log10(last_signal) ...
                    + log10(P.step) / (2 + reversals) * m);
            else
                signal = last_signal ...
                    + P.step / (2 + reversals) * m;
            end
            
            if m == 0
                response = saved_response;
            else
                response = m < 0;
            end
            if count > 1 && response ~= saved_response
                reversals = reversals + 1;
            end           
        end
        saved_signal = signal;
        saved_response = response;
    end

end