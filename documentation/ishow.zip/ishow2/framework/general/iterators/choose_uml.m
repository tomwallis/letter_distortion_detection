function h_adapt = choose_uml(varargin)
%function h = choose_circular(orders)
%
% Return a function handle that, when called, iterates according to the
% quest rule.
%
% Input:
%
% 'chance' - the chance level of the given task (0.5)
% 'lapse_rate' - the assumed rate at which the subject lapses (0.01)
% 'slope' - assumed slope of the psychometric function (3.5)
% 'threshold_mu' - initial guess or mean of the threshold prior (2)
% 'threshold_std' - standard deviation of the threshold_prior (4). It is
%                   recommended to choose a big value here.
% 'range' - the absolute range of possible signal intensities. The function
%           handle will not return any values outside of this interval
%           ([0, 5]).
% 'threshold_p' - p-value at which quest should sample (0.75). This value
%                 should be chosen dependent on the chance level of the
%                 task. Recommended is choosing the p-value of the
%                 infliction point on the psychometric function.
%
%% Define defaults

D = struct('n_intervals',2, ...
    'shape', 'logistic',...
    'slope_opt', 'linear', ...
    'range', [-2,10]);
P = update_struct(D, varargin{:});

signal = nan(1000,1);
response = nan(1000,1);
count = ones(1000,1);
n = 0;

% Make a batch string out of the preferences: 999 bootstrap replications
% assuming 2AFC design. All other options standard.
% Type "help psych_options" for a list of options that can be specified for
% psignifit.mex. Type "help batch_strings" for an explanation of the format.
prefs = batch('shape', P.shape, 'n_intervals', P.n_intervals, 'verbose', 0);
outputPrefs = batch('write_pa_est', 'pa_adapt_est');
pa_est = [3,0.5,0.5,0.02];
p_vals = [0.999, 0.917, 0.8];%, 0.083]; %([0.999, 0.917, 0.8, 0.6] - 0.5) ./ 0.5;

uml = UML(exp_config_logit());
uml.setPhi0(pa_est);

m_glob = 0;
n_glob = 0;
last_idx = 1;

h_adapt = @adaptive;

    function signal_out = adaptive(~, last_signal, last_target, last_response)
        idx = randi(length(p_vals));
        % Update the quest struct in case there is a new observation
        if nargin >=2 && ~ (isnan(last_signal) || isnan(last_response))
            % Fit the data, according to the preferences we specified (999 bootstraps).
            % The specified output preferences will mean that two structures, called
            % 'pa' (for parameters) and 'th' (for thresholds) are created.
            n = n + 1;
            signal(n) = last_signal;
            response(n) = last_response;
%             if n > 100
%                 dat = [signal(1:n), response(1:n), count(1:n)];
%                 pa_est = psignifit(dat, [prefs outputPrefs]);
%             end
            idx = up_down(3,1,last_response);
            uml.update(last_response);
        end
        %p_vals = uml_sweetpoints( pa_est );
        
        signal_out = uml.xnext;%findthreshold(P.shape, pa_est, p_vals(idx));
        
        % Sanity check for teh range of the recommended signal
        if signal_out < min(P.range)
            signal_out = min(P.range);
        elseif signal_out > max(P.range)
            signal_out = max(P.range);
        end
    end

    function idx = up_down(m,n,r)
        if r == 1
            m_glob = m_glob + 1;
            n_glob = 0;
            if m_glob >= m
                last_idx = last_idx + 1;
                m_glob = 0;
                n_glob = 0;
            end
        elseif r == 0
            n_glob = n_glob + 1;
            m_glob = 0;
            if n_glob >= n
                last_idx = last_idx - 1;
                m_glob = 0;
                n_glob = 0;
            end
        end
        if last_idx < 1
            last_idx = 1;
        elseif last_idx > length(p_vals)
            last_idx = length(p_vals);
        end
        idx = last_idx;            
    end

    function swpts = logit_sweetpoints(phi)
        
        %calculate the sweet points for a logit psychometric function, for
        %parameter alpha, beta and lambda.
        
        alpha = phi(1);
        beta = phi(2);
        gamma = phi(3);
        lambda = phi(4);
        
        swpts(1) = fminsearch(@(x) betavar_est(x,alpha,beta,gamma,lambda)+(x>=alpha)*1e10,alpha-10);
        swpts(3) = fminsearch(@(x) betavar_est(x,alpha,beta,gamma,lambda)+(x<=alpha)*1e10,alpha+10);
        swpts(2) = fminsearch(@(x) alphavar_est(x,alpha,beta,gamma,lambda),alpha);
        swpts = sort(swpts);
        
        function sigmaalphasq = alphavar_est(x,alpha,beta,gamma,lambda)
            
            term1 = exp(2*beta*(alpha-x));
            term2 = (1+exp(beta*(x-alpha))).^2;
            term3 = -gamma+(lambda-1)*exp(beta*(x-alpha));
            term4 = 1-gamma+lambda*exp(beta*(x-alpha));
            term5 = beta^2*(-1+gamma+lambda)^2;
            
            sigmaalphasq = -term1.*term2.*term3.*term4./term5;
        end
        
        function sigmabetasq = betavar_est(x,alpha,beta,gamma,lambda)
            
            term1 = exp(2*beta*(alpha-x));
            term2 = (1+exp(beta*(x-alpha))).^2;
            term3 = -gamma+(lambda-1)*exp(beta*(x-alpha));
            term4 = 1-gamma+lambda*exp(beta*(x-alpha));
            term5 = (x-alpha).^2*(-1+gamma+lambda)^2;
            
            sigmabetasq = -term1.*term2.*term3.*term4./term5;
        end
        
    end
end
