function h = choose_uniform_random(orders)
%function h = uniform_random(n)
%
% Return a function handle that, when called, randomly chooses and returns a
% column from the matrix orders.

n = size(orders, 2);
    
    function order = chooser(varargin)
        i = randi(n);
        order = orders(:, i);
    end
    
h = @chooser;

end
