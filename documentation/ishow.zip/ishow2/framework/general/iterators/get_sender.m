function send = get_sender(matrix)
%function send = get_sender(matrix)
%
% Define a function that returns a specific value from variable matrix
% dependent on its type.

if iscell(matrix)
    send = @(i) matrix{i};
elseif ndims(matrix) == 1
    send = @(i) matrix(i);
elseif ndims(matrix == 2)
    send = @(i) matrix(:, i);
else
    error('Unsupported iteration type');
end
