function iter = iterate(matrix)
%function iter = iterate(matrix)
%
% Return matrix columns one by one

n = size(matrix, 2);
i = 0;
send = get_sender(matrix);

    function column = next(varargin)
    % Return the next column
    if i >= n
        stop_iteration();
    end
    i = i + 1;
    column = send(i);

    end

iter = @next;

end
