function iter = iterate_block(matrix, n_repeat)
%function iter = iterate_block(matrix, n_repeat)
%
% Iterate through a matrix, repeating each column n_repeat times

n = size(matrix, 2) * n_repeat;
i = 0;
idx = 0;
send = get_sender(matrix);

    function column = next(varargin)
    % Return the next column        
    if i >= n
        stop_iteration();
    end
    if ~mod(i, n_repeat)
        idx = idx + 1;
    end
    
    i = i + 1;
    column = send(idx);
    end

iter = @next;

end
