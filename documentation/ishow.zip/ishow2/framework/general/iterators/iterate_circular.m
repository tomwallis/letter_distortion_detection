function iter = iterate_circular(matrix)
%function h = iterate_circular(matrix)
%
% Return a function handle that, when called, iterates through the columns
% in orders, and after having returned the last column, returns to the first
% column.

n = size(matrix, 2);
i = 0;
send = get_sender(matrix);

    function out = next(varargin)
        i = mod(i, n) + 1;
        out = send(i);
    end
    
iter = @next;

end
