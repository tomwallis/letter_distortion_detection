function R = distrib_defaults()
%function R = distrib_defaults()
%
% Return a structure containing all the default-values shared between all
% distributions.

R = patch_defaults();