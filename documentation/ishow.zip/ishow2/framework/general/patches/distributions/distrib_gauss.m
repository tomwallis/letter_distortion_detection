function distribution = distrib_gauss(varargin)
%function distribution = distrib_gauss(varargin)
%
% Return a 2-d gaussian patch.
%
% The gaussian patch is always specified on an axis between -3 and 3. Therefore
% a variance of 1 will contain 3 standard deviations of patch. Variances > 1
% are advised against, as they will introduce noticeable border effects.
%
% Inputs:
%   size - size in amount of array fields
%   cov - covariance matrix (2 x 2)
%   mean - mean of gaussian (2 x 1)
%   normalize - if true, normalizes the integral of the gaussian to 1,
%               otherwise the maximum point of the gaussian equals 1
%   cutoff - borders of the axis [left right bottom top]
%


%% Define defaults

D = distrib_defaults();
D.cov = eye(2);
D.mean = [0 0];
D.normalize = false;
D.cutoff = [-3, 3, -3, 3];


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    R = D;
    return
end

D = update_struct(D, varargin{:});


%% Generate patch

[x y] = meshgrid(linspace(D.cutoff(1), D.cutoff(2), D.size(1)), ...
                 linspace(D.cutoff(4), D.cutoff(3), D.size(2)));
coors = [x(:) y(:)] - repmat(D.mean, numel(x), 1);

if D.normalize
    Z = 1 / ((2 * pi * det(D.cov))^.5);
else
    Z = 1;
end

distribution = Z * exp(-0.5 * sum((inv(D.cov) * coors') .* coors', 1));
distribution = reshape(distribution, D.size);
