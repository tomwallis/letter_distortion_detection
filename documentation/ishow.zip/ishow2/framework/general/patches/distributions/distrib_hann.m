function distribution = distrib_hann(varargin)
%function distribution = distrib_hann(varargin)
%
% Create a 2-D Hann distribution.
%
% NOTE: For the moment, this distrib is isotropic only. In the future we can
% extend this into non-isotropic versions.
%
% parameters:
%   size - size of the hann distribution [width, height]


%% Define defaults

D = distrib_defaults();


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    distrib = D;
    return
end

D = update_struct(D, varargin{:});


%% Calculate the Hann patch

[x y] = meshgrid(linspace(-1, 1, D.size(1)), ...
                 linspace(-1, 1, D.size(2)));
z = sqrt(x.^2 + y.^2) * pi;
z(z > pi) = pi;
distribution = 0.5 * (1 + cos(z));