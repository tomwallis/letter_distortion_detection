function distribution = distrib_pulse(varargin)
%function distribution = distrib_pulse(varargin)
%
% Create a 2-D Pulse distrib.
%
%
% parameters:
%   size - size of the pulse distribution [width, height]
%
% For more information on argument passing, call 'help argument_passing'


%% Define defaults

D = distrib_defaults();


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    distrib = D;
    return
end

D = update_struct(D, varargin{:});


%% Calculate the Pulse distribution

distribution = ones(D.size);