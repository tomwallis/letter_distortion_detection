function distribution = distrib_tapered_cosine(varargin)
%function distribution = distrib_tapered_cosine(varargin)
%
% Create a 2-D tapered cosine distribution.
%
% NOTE: For the moment, this distrib is isotropic only. In the future we can
% extend this into non-isotropic versions.
%
% parameters:
%   size - size of the tapered hann distribution [width, height]
%
%   alpha - relative size of the hann: alpha * size = length of the hann
%   component. The rest of the curve, i.e. (1-alpha) * size is covered by a
%   rectangular window. The hann curve is halved and attached to the ends
%   of the rectangular window. (default 0.5). A value of alpha = 1 leads to
%   a regular hann window, whereas alpha = 0 leads to a rectanguar window.
%
% See also: curve_tapered_hann, tukeywin


%% Define defaults

D = distrib_defaults();
D.alpha = 0.5;


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    distrib = D;
    return
end

D = update_struct(D, varargin{:});


%% Calculate the tapered cosine patch

% Ratio of the length of hann part and the length of the rectengular part
r = D.alpha;% / (1- D.alpha);

% Leads to a round aperture
[x, y] = meshgrid(linspace(-1, 1, D.size(1)), ...
                 linspace(-1, 1, D.size(2)));
z = sqrt(x.^2 + y.^2);

% Invert z to follow equations from tukeywin. Divide by two due to
% symmetricity from the center to teh edges
z = (1 - z) / 2;

% See help of tukeywin for equations
distribution = 0.5 * (1 + cos( (2 * pi / r) * (z - r / 2)));
distribution(z >= r / 2) = 1;

% Points outside the aperture are set to zero
distribution(z < 0) = 0;

