function axes = grating_axes(P);
%function axes = grating_axes(varargin);
%
% Return the axes on which a grating is defined. The input P is a structure
% which must contain the fields:
%  - size
%  - theta (0 -> 1)
%

% Convert phase and angle to radians
theta = P.theta * 2 * pi;

% Generate axes
[x, y] = meshgrid(linspace(-0.5, 0.5, P.size(1)), ...
                  linspace(-0.5 ,0.5 ,P.size(2)));
x = x * cos(theta);
y = y * sin(theta);
axes = x + y;

