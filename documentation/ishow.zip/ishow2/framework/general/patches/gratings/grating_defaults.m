function R = grating_defaults()
%function R = grating_defaults()
%
% Return the default values shared by all gratings
%

R = patch_defaults();
R.frequency = 5;
R.theta = 0;
R.phase = 0;