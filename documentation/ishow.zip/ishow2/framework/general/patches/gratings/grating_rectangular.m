function grating = grating_rectangular(varargin)
%function grating = grating_rectangular(varargin)
%
% Return a rectangular grating
%
% parameters:
%   size - size of the axes [width, height]
%   frequency - amount of oscilations in the image if the grating
%               orientation is vertical.
%   theta - orientation away from 0. [0 -> 1]
%   phase - phase offset from 0. [0 -> 1]
%   duty_cycle - ratio: (positive width)/(negative width)
%
% NOTE: This function does not handle non-square patch sizes correctly. Fix
% this in the future. 

%% Define defaults

P = grating_defaults();
P.duty_cycle = 1; 


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    grating = P;
    return
end

P = update_struct(P, varargin{:});


%% Generate patch

% Convert phase and angle to radians
phase = P.phase * 2 * pi;
theta = P.theta * 2 * pi;

% Generate axes
xy = grating_axes(P);

xy = mod((xy * P.frequency * 2 * pi) + phase,2*pi);

grating = zeros(size(xy));
grating(xy <= 2*pi * (1 - (1/ (P.duty_cycle + 1)))) = 1 / P.duty_cycle;
grating(xy > 2*pi * (1 - (1/ (P.duty_cycle + 1)))) = - P.duty_cycle;
