function grating = grating_sawtooth(varargin)
%function grating = grating_sawtooth(varargin)
%
% Return a sawtooth grating
%
% parameters:
%   size - size of the axes [width, height]
%   frequency - amount of oscilations in the image if the grating
%               orientation is vertical.
%   theta - orientation away from 0. [0 -> 1]
%   phase - phase offset from 0. [0 -> 1]
%
% NOTE: This function does not handle non-square patch sizes correctly. Fix
% this in the future. Also non-vertical and non-horizontal gratings show strong
% pixelation.
% 

%% Define defaults

P = grating_defaults();


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    grating = P;
    return
end

P = update_struct(P, varargin{:});

if P.theta ~= 0 && P.theta ~= 1 && P.theta ~= 1/4 && P.theta ~= 3/4 
    %NOTE: Implement some anti-aliasing algorithm here
    warning(['Grating will look ugly for non-horizontal' ...
             ' or non-vertical orientation']) 
end


%% Generate patch

% Convert phase and angle to radians
phase = P.phase * 2 * pi;

% Generate axes
xy = grating_axes(P);
grating = sawtooth((xy * P.frequency * 2 * pi) + phase);

%% Generate output structure


