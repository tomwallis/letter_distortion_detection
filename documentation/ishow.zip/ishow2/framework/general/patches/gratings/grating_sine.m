function grating = grating_sine(varargin)
%function grating = grating_sine(varargin)
%
% Return a sine-wave grating
%
% parameters:
%   size - size of the axes [width, height]
%   frequency - amount of oscilations in the image if the grating
%               orientation is vertical.
%   theta - orientation away from 0. [0 -> 1]
%   phase - phase offset from 0. [0 -> 1]
%
% NOTE: This function does not handle non-square gratings correctly. Fix
% this in the future.
% 

%% Define defaults

P = grating_defaults();


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    grating = P;
    return
end

P = update_struct(P, varargin{:});


%% Generate patch

% Convert phase and angle to radians
phase = P.phase * 2 * pi;

% Generate axes
xy = grating_axes(P);
grating = sin((xy * P.frequency * 2 * pi) + phase);

