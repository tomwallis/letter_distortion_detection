function grating = grating_triangle(varargin)
%function grating = grating_triangle(varargin)
%
% Return a triangular grating
%
% parameters:
%   size - size of the axes [width, height]
%   frequency - amount of oscilations in the image if the grating
%               orientation is vertical.
%   theta - orientation away from 0. [0 -> 1]
%   phase - phase offset from 0. [0 -> 1]
%
% NOTE: This function does not handle non-square patch sizes correctly. Fix
% this in the future. 

%% Define defaults

P = grating_defaults();


%% Parse inputs

if ~isempty(varargin) && strcmpi(varargin{1}, 'defaults')
    grating = P;
    return
end

P = update_struct(P, varargin{:});

%% Generate patch

% Generate axes
xy = grating_axes(P);
phase = P.phase * 2 * pi;

% Normalize to [-1,1]
grating = mod((xy * P.frequency * 2 * pi) + phase - 0.5 * pi, 2 * pi) - pi;
grating = tripuls(grating, 2 * pi);
grating = (grating - 0.5) * 2;
