function R = patch_defaults()
%function R = patch_defaults()
%
% Return a structure containing the default-values shared between all
% patches

R.size = [300 300];
