function h = pauser_block( ntrials_block, ntrials_total )
%PAUSER_BLOCK returns a function handle which  defines the state of an
%experiment given a number of trials has passed.
%   ntrials_block - the number of trials in a single block. After the
%           specified number of trials the handle will senda break command.
%   ntrials_total - the total amount oftrials that will be performed in the
%                   experiment.
%
% Output:
% pauser(ntrials) - returns three type of state signals
%                   0 - regular state, continue with the experiment
%                   1 - break state, the block has ended here
%                   2 - final state, the experiment is finished

h = @pauser;
    function state = pauser(ntrial)
        % PAUSER returns three type of state signals
        %   0 - regular state, continue with the experiment
        %   1 - break state, the block has ended here
        %   2 - final state, the experiment is finished
        if ntrial >= ntrials_total
            state = 2;
        elseif mod(ntrial, ntrials_block) == 0
            state = 1;
        else
            state = 0;
        end
    end
end

