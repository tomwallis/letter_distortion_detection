function s = standard_now
%function s = standard_now
%
% Return the current date and time in a standard format that is file-name
% compatible.
%
% The format is:
% yyyy_mm_dd_HHMM
%

s = datestr(now, 'yyyy_mm_dd_HHMM');