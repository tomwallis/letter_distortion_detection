function out = strjoin(strs, joiner)
%function out = strjoin(strs, joiner)
%
% Return a string which consists of all the strings in cellstr 'strs' joined
% together with the string joiner.
%
% example
%   >>> strjoin({'a', 'b', 'c'}, ':')
%    yields: a:b:c
%

out = strs{1};
for i = 2 : length(strs)
    out = [out joiner strs{i}];
end
