function substr = strsplit(s, delimiter)
%function substr = strsplit(s, delimiter)
%
% Return a cellstring constructed by splitting string s at each delimiter
% character. The delimiter characters no longer occur in any substr
%

idx = strfind(s, delimiter);

substr = cell(length(idx) + 1, 1);
for i = 1 : length(idx)
    substr{i} = s(1 : idx(i) - 1);
    s(1 : idx(i)) = [];
    idx = idx - idx(i);
end

substr{end} = s;