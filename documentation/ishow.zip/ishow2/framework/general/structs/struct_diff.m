function A = struct_diff(A, B)
%function S = struct_diff(A, B)
%
% Return a structure containing fields in A that do not occur in B

names = fieldnames(B);
for i = 1 : length(names)
    try
        A = rmfield(A, names{i});
    end
end



