function B = struct_fields_fun(A, f)
%function B = struct_fields_fun(A, f)
%
% Return structure B containing the same values as A but in fieldnames
% created by calling function 'f' on the corresponding fieldnames in A.

names = fieldnames(A);
B = struct();

for i = 1 : length(names)
    B.(f(names{i})) = A.(names{i});
end
