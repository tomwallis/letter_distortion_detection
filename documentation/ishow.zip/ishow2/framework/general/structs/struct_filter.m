function B = struct_filter(A, re)
%function B = struct_filter(A, re)
%
% Return structure B, containing only fields matching re
%

names = cellstr_filter(fieldnames(A), re);
B = struct_subset(A, names);
