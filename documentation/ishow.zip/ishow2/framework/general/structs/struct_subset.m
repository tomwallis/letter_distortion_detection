function P = struct_subset(S, names)
%function P = struct_subset(S, names)
%
% Return a struct that contains only the fields of S specified by names

P = struct();
for i = 1 : length(names)
    P.(names{i}) = S.(names{i});
end
