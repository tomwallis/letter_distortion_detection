function target = update_struct(target, varargin)
%function target = update_struct(target, source, type)
%
% Return target structure updated with arguments passed via varargin
%
% NOTE: update this help string
%
% type (default = 'error'):
%   'error' - give an error
%   'ignore' - the field is ignored
%   'add' - the field is added to target
%
% Additionally, a series of 'name'-value pairs can be provided in
% varargin. These will then be added to target as well. Note that
% 'name'-value pairs specified in varargin will overwrite any fields in the
% source structure.
%

%% Check inputs

% If no inputs, error.
if nargin == 0
    error('Provide at least a target structure');
end

% If the last input is a 'type', set type. Otherwise default to error.
if ~isempty(varargin) && ...
        isstr(varargin{end}) && ...
        any(strcmpi(varargin{end}, {'error', 'ignore', 'add'}))
    type = lower(varargin{end});
    varargin(end) = [];
else
    type = 'error';
end

% If exactly one input, return target unchanged.
if isempty(varargin)
    return
end

% If the first entry in varargin is a struct, update it with the rest of the
% varargin. If not, create source as a struct of the key-value pairs.
if isstruct(varargin{1})
    source = update_struct(varargin{1}, varargin{2:end}, 'add');
else
    source = struct();
    for i = 1 : 2 : length(varargin)
        source.(varargin{i}) = varargin{i + 1};
    end
end


%% Update target
    
def_fields = fieldnames(target);
in_fields = fieldnames(source);

for i = 1 : length(in_fields)
    
    % If a field in source does not exist in target
    if ~any(strcmpi(in_fields{i}, def_fields))
        switch lower(type)
          case 'error'
            error('Non-existant field: %s', in_fields{i});
          case 'ignore'
            continue
          case 'add'
            % Do  nothing, field will get added down below
          otherwise
            error('Unrecognized ''type'': %s', type);
        end
    end

    target.(in_fields{i}) = source.(lower(in_fields{i}));
end