function out = cellstr_filter(cs, re)
%function cellstr_filter(cs, re)
%
% Return a cellstring that is a subset of cs containing all those cells
% that match the regular expression 're'

filter = @(s) ~isempty(regexp(s, re));
map = cellfun(filter, cs);
out = cs(map);