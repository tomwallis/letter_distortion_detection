function out = choose(in, n, f)
%function out = choose(in, n, f)
%
% Return n entries chosen from in using f to generate random indeces. 'f'
% must be a function that takes 1 input, n, and returns a vector of integer
% indeces to in.
%
% n defaults to 1
% f defaults to:
%    function idcs = f(n)
%        idcs = randperm(length(in));
%        idcs = idcs(1 : n);
%    end

    function idcs = my_f(n)
        idcs = randperm(length(in));
        idcs = idcs(1 : n);
    end
    
if nargin < 2
    n = 1;
end

if nargin < 3
    f = @my_f;
end

idcs = f(n);
out = in(idcs);
end
