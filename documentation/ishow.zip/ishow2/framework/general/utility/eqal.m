function b = eqal(p, q)
%function b = eqal(p, q)
%
% Return true if:
%  p & q are strings and they strcmp
%  p & q are numbers and they ==
%
% Else false
%

if isnumeric(p) && isnumeric(q)
    b = p == q;
elseif isstr(p) && isstr(q)
    b = strcmp(p, q);
else
    b = false;
end