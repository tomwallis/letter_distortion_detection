function s = hashstring(varargin)
%function s = hashstring(varargin)
%
% Turn variable v into string s. v must be 1 dimensional. If more than a
% single value is provided, a hashstring for a cell-array containing all the
% provided inputs is returned.
%

if length(varargin) == 1
    v = varargin{1};
else
    v = varargin;
end

if ischar(v)
    s = v;
elseif isnumeric(v)
    s = strrep(mat2str(v), ' ', ',');
elseif iscellstr(v)
    s = ['{' strjoin(v, ',')  '}'];
elseif iscell(v)
    s = cell(size(v));
    for i = 1 : length(v)
        s{i} = hashstring(v{i});
    end
    s = hashstring(s);
else
    error('Object type: %s not supported', class(v))
end