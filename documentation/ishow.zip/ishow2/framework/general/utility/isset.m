function b = isset(in)
%function b = isset(in)
%
% Return true if all the values in in occur only once, false
% otherwise. Currenlty only works for:
%  matrices
%  cellstrings
%  numerical cell-arrays
%

check = @(in) numel(unique(in)) == numel(in);

try
    b = check(in);
catch
    try
        in = cell2mat(in);
        b = check(in);
    end
end
