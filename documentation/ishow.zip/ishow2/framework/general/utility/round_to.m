function val = round_to(val, n)
%function val = round_to(val, n)
%
% Round val to the nearest n
%

val = round(val / n) * n;

