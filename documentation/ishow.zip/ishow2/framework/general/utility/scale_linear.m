function out = scale_linear(in, new, old)
%function out = scale_linear(in, new, old)
%
% Perform a linear scaling on the matrix 'in' which is defined on the
% interval of 'old' to the interval 'new'.
%
% parameters:
%   in  - a value, vector, or matrix of numbers
%   new - a [min max] range in which the out matrix should be defined
%   old - a [min max] range in which the in matrix is defined
%
% if old is not provided, it is assumed to be [min(in(:)), max(in(:)))]

in = double(in);

if nargin < 2
    error('Please provide a matrix, a new interval, and an old interval');
elseif nargin < 3
    old = [min(in(:)), max(in(:))];
end


% Perform the calculations with as little matrix operations as possible
scale = (new(2) - new(1)) / (old(2) - old(1));
shift = new(1) - old(1) * scale;

out = in * scale + shift;
