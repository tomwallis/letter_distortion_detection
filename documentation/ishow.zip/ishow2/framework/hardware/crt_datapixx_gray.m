function [h, rect] = crt_datapixx_gray(varargin)
%function h_win = open_viewpixx_gray(varargin)
%
% Open the Viewpixx monitor and set the monitor settings to conform with
% 16-bit gray-scale mapping. This means images are defined from 0 to 1, and
% it is possible to specify negative values (which allows you to store
% gratings as deviations around a background color). 
%
% The monitor does *not* automatically check values outside the [0 1]
% range. Make sure that you check for this yourself in your experiment scripts.
%
% If this is the first time using the ResponsePixx monitor on this computer
% or account, be sure to call:
%  BitsPlusImagingPipelineTest(1);
% to allow Psychtoolbox to calibrate and test your setup.
% 
% parameters:
%  bg_color - background color of the window (defaults to 0.5)
%  h_screen - screen handle, defaults to the highest (i.e. secondary monitor)
%  clut     - a color lookup table for gamma correction. It can either be
%             a Mx1 vector or a Mx3 matrix. For details see PsychColorCorrection
%

%% Define defaults and parse inputs

P.bg_color = 0.5;
P.h_screen = max(Screen('Screens'));
P.clut = [];

P = update_struct(P, varargin{:}, 'ignore');

%% Prepare configuration

PsychImaging('PrepareConfiguration');

% Enables the use of Datapixx specific functions from frame-counts and timings
PsychImaging('AddTask', 'General', 'UseDataPixx');

% FastOffscreenWindows increases the speed of texture-drawing
PsychImaging('AddTask', 'General', 'UseFastOffscreenWindows');

% The Datapixx inbuilt 16-bit precision grayscale mode
PsychImaging('AddTask', 'General', 'EnableDataPixxM16Output');



% If lookup table for gamma correctionis specified we prepare the usage of it
if any(P.clut)
    PsychImaging('AddTask', 'FinalFormatting', ...
                 'DisplayColorCorrection', 'LookupTable');
end


%% Create window and return handle + rect

[h, rect] = PsychImaging('OpenWindow', P.h_screen, P.bg_color);

% After opening the screen use the specified clut (if so) to perform gamma
% correction. The 
if any(P.clut)
    PsychColorCorrection('SetLookupTable', h, P.clut);
    % Flip to have the background color
    Screen('Flip', h)
end
