function [h rect] = open_debug_window(varargin)
%function [h rect] = open_debug_window(varargin)
%
% Open a window used for debugging and testing.
%
% For developers: adjust the values inside this function to ease the
% creation of different kinds of debug windows. This function is not written
% with end-users in mind, but for people to hack at inside their own
% environment to ease testing and debugging.
%

%% Setup local settings
% These settings reflect the resolutions and layouts I (David Janssen)
% usually use on my setup. I recommend you either customize these to your
% own local settings, or if sharing this function with many people, create
% debug_window function.

res_small = [1680 1050];
res_big = [2560 1440];
res_beam = [1680 1078];

FULL_BEAMER = [0 0 res_beam];
FULL_BIG = [0 0 res_big];
BIG_SCREEN = [950 0 1250 300];
SMALL_SCREEN = [0 700  300 1000];
FULL_RIGHT = [2560 0 (2560 + 1680) 1050];


%% Setup defaults and parse inputs

P.bg_color = 0.5;
P.rect = SMALL_SCREEN;
P.debug_level = 3;
P.suppress_warnings = 1;
P.skip_sync_tests = 1;
P.screen_id = max(Screen('Screens'));

P = update_struct(P, varargin{:});

if isstr(P.rect)
    if exist(P.rect, 'var')
        P.rect = eval(P.rect);
    else
        error('%s is not a recognized rect name', P.rect);
    end
end
        
    

%% Initialize monitor

% Setup debug and warning level
Screen('Preference', 'VisualDebugLevel', P.debug_level);
Screen('Preference', 'SuppressAllWarnings', P.suppress_warnings);
Screen('Preference', 'SkipSyncTests', P.skip_sync_tests);

% Prepare configuration
PsychImaging('PrepareConfiguration');
PsychImaging('AddTask', 'General', 'FloatingPoint32BitIfPossible');

% Open window
[h rect] = PsychImaging('OpenWindow', P.screen_id, P.bg_color, P.rect);
Screen('ColorRange', h, 1.0, 0);
Screen('FillRect', h, P.bg_color);
Screen('Flip', h);

