classdef button_press
    %RESPONSE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(SetAccess = {?listener_abstract}, GetAccess = public)
        % An array which indicates valid button states
        button_states = [];
        % A vector with times of changes in button states relative to time_init
        button_times = [];
        % Onset time of listening to response device
        time_start = NaN;
        % Offset time of listening to response device
        time_stop = NaN;
        % Array of integers which identify valid keys.
        key_ids = NaN;
        % Cell array of strings which specify the names of valid keys
        names = NaN;
        % String with the name of the response listener;
        listener = NaN;
    end
    
    methods(Access = {?listener_abstract})
        function obj = button_press(names, key_ids, listener)
            if nargin > 0
                obj.names = names;
            end
            if nargin > 1
                obj.key_ids = key_ids;
            end
            if nargin > 2
                obj.listener = listener;
            end
        end
        
        function obj = reset_properties(obj)
            obj = button_press(obj.names, obj.key_ids, obj.listener);
        end
    end
    
    methods(Access = public)
        function [button_press, button_time] = get_presses(obj, type, K)
            if ~exist('type','var')
                type = 'first';
            end
            
            if ~exist('K','var')
                K = 1;
            end
                
            % type - 'first', 'last'
            button_press = NaN;
            button_time = NaN;
            k = 1;
            if strcmpi(type, 'first')
                for i = 2:size(obj.button_states,1)
                    if sum(obj.button_states(i,:)) > sum(obj.button_states(i-1,:))
                        button_press(k,:) = find(xor(obj.button_states(i,:), obj.button_states(i-1,:)));
                        button_time(k) = obj.button_times(i);
                        k = k + 1;
                    end
                    if k > K
                        return;
                    end
                end
            elseif strcmpi(type, 'last')
                for i = 1:size(obj.button_states,1)-1
                    if sum(obj.button_states(end-i+1,:)) > sum(obj.button_states(end-i,:))
                        button_press(k,:) = find(xor(obj.button_states(end-i+1,:), obj.button_states(end-i,:)));
                        button_time(k) = obj.button_times(i);
                        k = k + 1;
                    end
                    if k > K
                        break;
                    end
                end
                % Bring the presses in their original order
                button_press = flipud(button_press);
                button_time = flipud(button_time);                
            else
                display('Please specify a proper type!')
            end
        end
        
        function [button_press, button_time] = get_single_presses(obj, type, K)
            if ~exist('type','var')
                type = 'first';
            end
            
            if ~exist('K','var')
                K = 1;
            end
                
            % type - 'first', 'last'
            button_press = NaN;
            button_time = NaN;
            
            k = 1;
            if strcmpi(type, 'first')
                for i = 2:size(obj.button_states,1)
                    if sum(obj.button_states(i,:)) == 1
                        button_press(k,:) = find(obj.button_states(i,:));
                        button_time(k) = obj.button_times(i);
                        k = k + 1;
                    end
                    if k > K
                        return;
                    end
                end
            elseif strcmpi(type, 'last')
                for i = 1:size(obj.button_states,1)-1
                    if sum(obj.button_states(i,:)) == 1
                        button_press(k,:) = find(obj.button_states(i,:));
                        button_time(k) = obj.button_times(i);
                        k = k + 1;
                    end
                    if k > K
                        break;
                    end
                end
                % Bring the presses in their original order
                button_press = flipud(button_press);
                button_time = flipud(button_time);                
            else
                display('Please specify a proper type!')
            end
        end

    end
end
