classdef listener_abstract < handle
% classdef listener_abstract < handle
%
% The parent class for all response-objects. Should not be used by itself,
% but rather use a subclass like listener_keyboard or
% listener_buttonbox. This class just defines all the properties that all
% response capture objects share.
%

    properties(SetAccess = protected, GetAccess = public)
        % A response object which saves the latest input states 
        response;
        % Array of integers which identify valid keys. 
        key_ids = [];
        % Cell array of strings which specify the names of valid keys
        names = {};
        % Logical which defines whether a listener calls check or not
        does_interrupt = false;
        % Logical which defines whether onset times should be synchronized
        % with the next flip of a VPixx monitor
        uses_datapixx = false;
    end
    
    methods(Abstract)
        start(obj)
        %function start(obj)
        %
        % Called before response retrieval to reset response logs and the onset
        % timestamp for the response retrieval. This function should:
        % (1) - Call reset_properties() on the response object
        % (2) - Initiate a queue for logging responses
        % (3) - Save the intitial input state and the onset time inside of 
        %       the response object. 
        % If uses_datapixx == true the 2nd and 3rd steps are executed at
        % the next flip using PsychDataPixx('ExecuteAtFlipCount', [], ...);
        
        response = stop(obj)
        %function stop(obj)
        %
        % Called after responses have been retrieved. Collects the data and 
        % saves only state changes and their corresponding time stamps 
        % inside of the resposne object. Previously open queues are closed.
        % response.time_stop is set to the time when stop() is called.
        
        check(obj)
        %function check(obj)
        %
        % Called during response retrieval. Checks to see if input has been
        % provided since start() has been executed and throws a 
        % response_interrupt if true. After the response interrupt has been
        % thrown stop() can be called to collect the response object.
    end
end
