classdef listener_buttonbox < listener_abstract
    % classdef listener_buttonbox < listener_abstract
    %
    % The object that listens to and handles buttonbox input. It does not init or
    % deinit anything in the interval, so those functions are left as their
    % empty equivalents in the 'base' object.
    %
    % It does map input-keys to key-codes, which are mapped to functions.
    
    methods
        
        function obj = listener_buttonbox(varargin)
            %function obj = listener_buttonbox(varargin)
            %
            % Return a buttonbox-response handling object.
            %
            % parameters:
            %  names - cell array of button names which specify the valid
            %          buttons. The following names can be used:
            %          'Red', 'Yellow', 'Green', 'Blue', 'White'.
            %          Default: {'Green','Red'}. Outputs will be sorted
            %          according to the ordering of the names.
            %  key_ids - Optional, array of integers specifying the
            %            key_ids of the active keys. If set this overwrites
            %            the specified names. Using this option is useful for
            %            'press any key' usage. In that case hand over a 1:5
            
            % Set defaults and parse input
            P.names =  {'Green','Red'};
            P = update_struct(P, varargin{:},'add');
            
            % Possible key names
            names = {'Red', 'Yellow', 'Green', 'Blue', 'White'};
            
            % Ignore provided key names if key ids have been specified. This
            % easens an 'press any key' option.
            if isfield(P,'key_ids')
                obj.key_ids = P.key_ids;
                obj.names = names(obj.key_ids);
            else
                % Container Map which assigns a key_id to every valid name.
                Bname = containers.Map(names,{1, 2, 3, 4, 5});
                obj.names = P.names;
                % Find the corresponding key-codes to the provided key-names
                for i = 1:length(obj.names)
                    obj.key_ids(i) = Bname(obj.names{i});
                end
            end
            
            % Fill does interrupt if defined by user
            if isfield(P,'does_interrupt')
                obj.does_interrupt = P.does_interrupt;
            end
            
            % Fill does interrupt if defined by user
            if isfield(P,'uses_datapixx')
                obj.uses_datapixx = P.uses_datapixx;
            end
            
            obj.response = button_press(obj.names, obj.key_ids,'Buttonbox');
            
            % Close to make sure that open can be called
            ResponsePixx('Close');
            % ResponsePixx has to be opened in order to get 
            % input from the buttonbox            
            ResponsePixx('Open');
        end
        
        function start(obj)
            % Reset the interval specific properties of the response object
            obj.response = obj.response.reset_properties();
                        
            % If datapixx is used, setting the initial state will be
            % synchronized with the next execution of Screen('Flip').
            % This is to increase timing precision. Otherwise the initial
            % be set immediately.
            if obj.uses_datapixx 
                obj.initial_state;
                %PsychDataPixx('ExecuteAtFlipCount', [], 'disp(''hello'')')
            else
                obj.initial_state;
            end
            
        end
        
        function response = stop(obj)
            %function stop(obj)
            %
            % Deinitialize the interval. For example in the case of the
            % button-box, this is a call to ResponsePixx('Close').
            
            % Stop the buttonbox queue and retrieve the logged responses
            obj.response.time_stop = ResponsePixx('StopNow', 0, zeros(1,5));
            [buttons, times, underflow] = ResponsePixx('GetLoggedResponses');
            
            % Underflow is true if the response queue buffer is full and
            % responses have been lost. Buffer size: 1000
            if underflow
                %NOTE: Should this be warning or error?
                warning('Response Buffer full. Some responses mit have been lost.');
            end
            
            % Append new button states to the already saved ones.
            obj.response.button_states = [obj.response.button_states; ...
                buttons(:,obj.key_ids)];
            obj.response.button_times = [obj.response.button_times; ...
                times(:)];
            
            % Save the timings relative to time_start if it exists
            if ~isnan(obj.response.time_start)
                obj.response.button_times = ...
                    obj.response.button_times - obj.response.time_start;
            end
            
            % Register all states after function start has been executed.
            keep = 1;
            if size(obj.response.button_states,1)
                for i = 2:size(obj.response.button_states,1)
                    if any(obj.response.button_states(i-1,:) ...
                            ~= obj.response.button_states(i,:))
                        keep(end+1) = i;
                    end
                end
                % Save only the state changes
                obj.response.button_states = obj.response.button_states(keep,:);
                obj.response.button_times = obj.response.button_times(keep);
            end
            
            response = obj.response;
        end
        
        function check(obj)
            if obj.does_interrupt
                % NOTE: very brief clicks will not be registered. Reasons are
                % yet to be found.
                [buttons, times] = ResponsePixx('GetLoggedResponses');
                if ~isempty(buttons)
                    % Responses have to be written immediately since
                    % 'GetLoggedResponses' empties the response log for some reason
                    obj.response.button_states = [obj.response.button_states; ...
                                                  buttons(:,obj.key_ids)];

                    obj.response.button_times = [obj.response.button_times; ...
                        times(:)];
                end
                if any(buttons(:))
                    ResponsePixx('StopNow', 0, zeros(1,5));
                    error('iShow:ResponseInterrupt','');
                end
            else
                error('Object is not supposed to run check!')
            end
        end
        
        function initial_state(obj)
            % Record the initial state of the button box
            % Get the initial button states.
            [buttons, ~] = ResponsePixx('GetButtons');
            obj.response.button_states = buttons(obj.key_ids);
            
            % Open the response queue and save timing.
            button_light = zeros(1,5);
            [obj.response.time_start, ~] = ResponsePixx('StartNow', 1, ...
                                                        button_light);
            obj.response.button_times = obj.response.time_start; 
        end
        
        function delete(obj)
            % DESTRUCTOR
            ResponsePixx('Close');
        end
    end
    
end

