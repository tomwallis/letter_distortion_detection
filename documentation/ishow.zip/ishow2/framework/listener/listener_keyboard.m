classdef listener_keyboard < listener_abstract
    % classdef listener_keyboard < listener_abstract
    %
    % The object that listens to and handles keyboard input.
    
    properties (SetAccess = protected, GetAccess = public)
        % Disables matlab to listen to other buttons than the specified ones
        disable_other;
    end
    
    methods
        
        function obj = listener_keyboard(varargin)
            %function obj = listener_keyboard(varargin)
            %
            % Return a keyboard-response handling object.
            %
            % parameters:
            %  names - Cell array of strings which specify the key names of
            %          keys to be used. Valid names can eb found using KbName.
            %          Default {'LeftArrow', 'RightArrow', 'Escape'}
            %          Outputs will be sorted according to the ordering of the
            %          names.
            %  disable_other - Logical value which disables listening to keys
            %                  other than the ones specified if set to 1.
            %                  Default: 1
            %  key_ids - Optional, array of integers specifying the KbName
            %            key_ids of the active keys. If set this overwrites
            %            the specified names. Using this option is useful for
            %            'press any key' usage. In that case hand over a 1:255
            
            % Set class specific defaults
            % Names of the keys to use
            obj.names = {'LeftArrow', 'RightArrow', 'Escape'};
            obj.disable_other = true;
            
            % Set user defined variables
            obj = obj.set_properties(varargin{:});
            
            % Ignore provided key names if key ids have been specified. This
            % easens an 'press any key' option.
            KbName('UnifyKeyNames');
            if ~isempty(obj.key_ids)
                obj.names = KbName(obj.key_ids);
            else
                % Find the corresponding key-codes to the provided key-names
                obj.key_ids = cellfun(@KbName, obj.names);
            end
               
            % Disables logging of not-specified keys
            if obj.disable_other
                DisableKeysForKbCheck(setdiff(1:255, obj.key_ids));
            end
            
            % Makes sure that button presses an not printed out inside of a
            % script or the command line.
            % NOTE: This probably breaks a *lot* of things
            %ListenChar(2)
            
            % Create a botton_press object for saving the button_states and
            % button_times
            obj.response = button_press(obj.names, obj.key_ids,'Keyboard');
        end
        
        function start(obj)
            % Reset the interval specific properties of the response object
            obj.response = obj.response.reset_properties();
            
            % Starts recording keys and writing them into the queue
            KbQueueCreate;
            KbQueueStart;

            
            % TODO: synchronize this timing with the next 'Flip'
            % Save the initial button states
            [~, obj.response.button_times, keycode] = KbCheck;
            obj.response.button_states = keycode(obj.key_ids);
            
            % Save the starting time of the keyboard queue
            obj.response.time_start = obj.response.button_times(1);
        end
        
        function response = stop(obj)
            % Stops filling the keyboard queue with recorded button presses
            KbQueueStop;
            obj.response.time_stop = GetSecs;
            
            % Returns the number of button presses registered in the queue
            n_events = PsychHID('KbQueueFlush');
            
            % Remember first keyboard state and reserve space for the number of
            % registered events.
            temp_button = obj.response.button_states(1,:);
            temp_times = obj.response.button_times(1);
            
            obj.response.button_states = zeros(n_events + 1,length(obj.key_ids));
            obj.response.button_times= zeros(n_events + 1,1);
            
            obj.response.button_states(1,:) = temp_button;
            obj.response.button_times(1) = temp_times;
            
            % Flush out events from the keyboard queue. We start with i = 2
            % since the first entry was filled in start.
            i = 2;
            for n = 1:n_events
                % Remember last keyboard state. Since only one button changes at
                % a time, the others will stay the same.
                obj.response.button_states(i,:) = obj.response.button_states(i-1,:);
                
                % A keyboard event as saved in the queue. Important fields:
                % Keycode - the button that has changed it's state; Pressed -
                % the state of the specified button; Time - the time that the
                % button state has changed.
                event = PsychHID('KbQueueGetEvent');
                
                % Only recognize the event if one of the specified keys has
                % changed the state
                id = find(obj.key_ids == event.Keycode);
                if id
                    % Register the time of the event
                    obj.response.button_times(i) = event.Time;
                    % Change the state of the button that caused the event
                    obj.response.button_states(i,id) =  event.Pressed;
                    i = i + 1;
                end
            end
            
            % Only keep the entries which correspond to state changes of
            % specified keys
            obj.response.button_times = obj.response.button_times(1:i-1);
            obj.response.button_states = obj.response.button_states(1:i-1,:);
            
            % Save keyboard states relative to the onset of recording
            if ~isnan(obj.response.time_start)
                obj.response.button_times = obj.response.button_times ...
                    - obj.response.time_start;
            end
            
            PsychHID('KbQueueRelease')
            
            % Return the response objects
            response = obj.response;
        end
        
        function check(obj)
            %function flag = check(obj)
            %
            % Call KbQueueCheck to see if any keys have been pushed, and if a key
            % that corresponds to our bindings exist. Throw a ResponseInterrupt
            % error in that case.
            if obj.does_interrupt
                [keyIsDown, firstKeyPressTimes]=PsychHID('KbQueueCheck');
                if keyIsDown && any(firstKeyPressTimes(obj.key_ids))
                    PsychHID('KbQueueStop');
                    error('iShow:ResponseInterrupt', ...
                        sprintf('%i', find(firstKeyPressTimes(obj.key_ids))));
                end
            else
                error('Object is not supposed to run check!')
            end
        end
        
        function delete(obj)
            % DESTRUCTOR - frees up all keys again.
            
            % Enables all keys for the use of KbCheck again.
            DisableKeysForKbCheck([]);
            % Keyboard is registered in scripts and command line again.
            %ListenChar(0);
        end
        
        function obj = set_properties(obj, varargin)
            %SET_OBJECT_PROPERTIES Summary of this function goes here
            %Detailed explanation goes here
            
            P = properties(obj);
            S = update_struct(struct(), varargin{:},'add');
            
            for i = 1:length(P)
                if isfield(S, lower(P{i}))
                   	obj.(P{i}) = S.(lower(P{i}));
                end
            end
        end

    end
end
