function response = response_interrupt
%function response = interreupt_session
%
% Interupt the current stimulus. Error is caught by run_interval, run_trial,
% and run_session, and the stimulus presentation is elegantly aborted.

response = NaN;
error('iShow:Interupt', 'Stimulus was aborted')
