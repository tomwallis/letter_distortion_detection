classdef audio_port < handle
% classdef audio_port < handle
%
% An audio-port object meant to handle creating, playing, and storing
% sounds.

    properties(SetAccess=protected)
        sample_rate = 9800;         % Sampling rate
        waves = containers.Map();   % Storage of the sounds
    end
    
    properties
        volume = .25;               % General volume  
        when = 'flip';              % When to play the sound, 'now' or 'flip'
    end
    


    methods
        
        function obj = audio_port(varargin)
        %function obj = audio_port(varargin)
        %
        % Return an audio_port of type 'type'
            
            obj = update_struct(obj, varargin{:}, 'ignore');
            
            if ~isempty(obj.waves) && iscell(obj.waves)
                obj.waves = containers.Map(obj.waves{:});
            end
            
        end
        
        
        function hz = named_frequency(obj, s)
        %function hz = named_frequency(obj, s)
        %
        % Return the frequency in Herz for some frequencies of different
        % names. This allows us to create beeps of variant 'high', 'low', or
        % 'medium'.
        %
            switch lower(s)
              case {'h', 'hi', 'high'}
                hz = 1000;
              case {'m', 'med', 'medium'}
                hz = 400;
              case {'l', 'low'}
                hz = 220;
              otherwise
                error('Unrecognized frequency: ''%s''', s);
            end   
        end

        function wave = create_beep(obj, name, frequency, duration, volume)
        %function wave = create_beep(obj, name, frequency, duration, volume)
        %
        % Create a monotonic beep and store it internally under label
        % 'name'. The 'frequency' variable can either be expressed in Hz, or
        % as a string referring to one of the named frequencies we use.
        %
        % In addition to the global object 'volume' it is possible to pass a
        % volume to the create_beep function, which will scale the beep's
        % volume relative to the other beeps.
            
            if nargin < 5
                volume = 1;
            end
            
            if ischar(frequency)
                frequency = obj.named_frequency(frequency);
            end
            
            n = obj.sample_rate * duration;
            f = 2 * pi * frequency;
            wave = sin(f * (1 : n) / obj.sample_rate);
            wave = wave * volume; %obj.volume * volume;
%             wave = wave .* curve_tapered_cosine('size', length(wave), ...
%                                                      'alpha', .1)';
            obj.waves(name) = wave;
            
        end
    end
    
    
    methods(Abstract)
        play(obj, name)
        %function play(obj, name)
        %
        % Play the sound stored under 'name'
    end
end
