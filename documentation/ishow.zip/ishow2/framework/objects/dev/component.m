classdef component < handle
% classdef component < handle
%
% A stimulus component object that stores all the fixed and random levels
% for a certain stimulus component. Can automatically generate textures our
% sounds based provided stimulus levels.
%
% It distinguishes three different kinds of factors:
%   level-factors: These are factors that determine the different stimuli
%       levels that are shown. For example, if we are running an experiment
%       with gratings of 3 different frequencies, then 'frequency' is a
%       level-factor with 3 values.
%   fixed-factors: These are factors that do not take different values
%       throughout the experiment. For example, we might show different
%       frequency images, but they will always have the same size. In the
%       case image-size is a fixed factor.
%   random-factors: These are factors that are randomly chosen, but are not
%       included because we are interested in their effects. When we want to
%       show a certain frequency image multiple times, but want to randomize
%       the phase so that the peaks and troughs are in different locations,
%       then phase is a random-factor.
%
    

    properties

        type;
        level_factors;
        random_factors;
        fixed_factors;
        

    end


    methods

        function obj = component(type, varargin)
        %function obj = component(type, varargin)
        %
        % Return a component object which codes for the levels that a
        % certain stimulus component can have. It has functions for
        % generating stimuli based on levels.
        %
        % The type argument determines how the 'generate' function uses the
        % provided factors to automatically generate stimuli. It can be set
        % to an empty or nonsense value, in which case the 'generate'
        % function becomes unusable, 
        %
        % parameters:
        %   type - 'audio' or 'visual'
        %
            
            obj.type = type;
            obj.level_factors = containers.Map('uniformValues', false);
            obj.random_factors = containers.Map('uniformValues', false);
            obj.fixed_factors = containers.Map('uniformValues', false);

        end

        function dict = factor_type(obj, type)
        %function dict = factor_type(obj, type)
        %
        % Return the dictionary associated with factor type 'type'. Note,
        % because containers.Map objects (dictionaries) are handle-objects,
        % if you get a dictionary by calling this function, and then change
        % it, the changes will be reflected in this component object.
        %
        % parameters:
        %  type - 'level', 'random', 'fixed'
        %
            switch lower(type)
              case 'level'
                dict = obj.level_factors;
              case 'random'
                dict = obj.random_factors;
              case 'fixed'
                dict = obj.fixed_factors;
              otherwise
                error('Unrecognized factor type: %s', type);
            end
        end
        
        
        function add_factors(obj, type, varargin)
        %function add_factors(obj, type, varargin)
        %
        % Add a set of factors to the component.
        %
        % parameters:
        %  type - 'level', 'random', or 'fixed'
        %  varargin - 'name1', values1, 'name2', values2 etc.
        %
            dict = obj.factor_type(type);
            for i = 1 : 2 : length(varargin)
                dict(varargin{i}) = varargin{i + 1};
            end
        end
        
        
        function keyval = as_keyval(obj, type)
        %function to_keyval(obj, keys, values)
        %
        % Return the specified factor-type dictionary as a series of
        % 'name'-value pairs.
        %
            dict = obj.factor_type(type);
            keyval = cell(dict.Count * 2, 1);
            keyval(1 : 2 : end) = dict.keys;
            keyval(2 : 2 : end) = dict.values;
        end
        
            
        
        function n = n_conditions(obj)
        %function n = n_conditions(obj)
        %
        % Return the amount of specified conditions, i.e., the amount of
        % different states our levels take. For example, if we have 2
        % levels, 1 with 3 values, and 1 with 4 values, this will return 12.
        %
        % Note that this does not include random factors
        %
        % see also: component.n_cases
        %
            n = prod(cellfun(@length, obj.level_factors.values));
        end
        
        
        function out = conditions(obj)
        %function out = conditions(obj)
        %
        % Return an n-dimensional cell array, where n is the amount of
        % level-factors, with each cell containing a set of value-factors so
        % that each combination of level-factors is covered by 1 cell.
        %
            function out = my_size(in)
                if ndims(in) == 2 && any(size(in)) == 1
                    out = length(in);
                elseif ndims(in) == 2
                    out = size(in, 2);
                else
                    error('Only supports 1 or 2 dimensional values')
                end
            end
            
            keys = [obj.level_factors.keys obj.random_factors.keys];
            values = [obj.level_factors.values obj.random_factors.values];
            sizes = cellfun(@my_size, values);
            out = cell(sizes);
            step = arbitrary_loop(sizes);
            
            while true
                try
                    idcs = step();
                    argin = cell(length(idcs) * 2, 1);
                    for i = 1 : length(idcs)
                        argin{2 * i - 1} = keys{i};
                        val = values{i};
                        if ~any(size(val) == 1)
                            argin{2 * i} = val(:, idcs(i));
                        else
                            argin{2 * i} = val(idcs(i));
                        end
                    end
                    idcs = num2cell(idcs);
                    out{idcs{:}} = argin;
                catch e
                    if ~strcmp(e.identifier, 'Iterator:StopIteration')
                        rethrow(e)
                    else
                        break
                    end
                end
            end

        end
        
        
        
        function n = n_cases(obj)
        %function n = n_cases(obj)
        %
        % Return the amount of possible combinations that exist in this
        % component. It is equal to the amount of conditions multiplied by
        % the amount random levels.
        %
        % see also: component.n_conditions
        %
            n = obj.n_conditions;
            n = n * prod(cellfun(@length, obj.random_factors.values));
        end        

        
        function [images textures] = generate_textures(obj, win, f)
        %function generate_textures(obj, win, f)
        %
        % Generate a texture for each case that exists inside this
        % component.
        %
        % parameters
        %   win - ishow window object
        %   f - function handle used to generate images
        %
        % for example obj.generate_textures(win, @grating_sine)
        %
        
            
            
        end
        
            
    end
end
