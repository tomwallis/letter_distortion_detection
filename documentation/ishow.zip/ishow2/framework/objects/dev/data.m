classdef data < level_data
% classdef data < level_data
%
% An object that functions as an interface for saving, loading, tracking,
% and summarizing data. Currently, one data object tracks the data of one
% subject for one experiment.
% 
% This object needs to be exanded and changed when the database is up and
% running, it currently works as a quick fix.
%
    
    properties (Constant = true)
        FNAME = 'tracker.mat';    
    end
    
    properties
        subject;
        dir;
        current_fid;
        comment_char = '#';
    end

    
    methods (Static = true)        
        function obj = load(root, subject)
        %function obj = load(root, subject)
        %
        % Load an existing data-object and return it
        %
            fname = fullfile(root, subject, 'tracker.mat');
            obj = load(fname, 'obj');
            obj = obj.obj;
        end
    end
    

    methods

        function obj = data(root, subject, levels)
        %function obj = data(root, subject, levels)
        %
        % Return a data object.
        %
        % Initializes a data object that keeps track of the data for 1
        % subject in 1 experiment. The data-files themselves will be stored
        % in a subdirectory named 'subject' inside of 'root'.
        %
        % parameters:
        %  root - directory corresponding to this experiment
        %  subject - string identifying the subject
        %  levels - when creating a new data-object, provide a levels-object
        %           that defines in which parameter-levels we are interested
        %
            obj = obj@level_data(levels);            
            obj.dir = fullfile(root, subject);
            obj.subject = subject;
            if ~exist(obj.dir)
                mkdir(obj.dir);
            end
        end
        
        
        function s = fname(obj)
        %function s = fname(obj)
        %
        % Return the filename of the data-object's save location
        %
            s = fullfile(obj.dir, obj.FNAME);
        end
        
        
        function save(obj)
        %function save(obj)
        %
        % Save the data-object
        %
            save(obj.fname, 'obj');
        end
        
        
        
    end
end
