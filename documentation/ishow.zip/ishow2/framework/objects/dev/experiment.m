classdef experiment < handle
% classdef experiment < handle
%
% An object that tracks all the data belonging to one experiment. An
% experiment spans multiple subjects and sessions


    properties

        name;
        data_dir;
        mfile;
        subjects = {};
        levels = {};
        param = {};
        
    end


    methods

        function obj = experiment(name, data_dir, mfile)
        %function obj = experiment(name, data_dir, mfile)
        %
        % Create a new experiment or load an existing one
        %
        % parameters:
        %   name - name of this experiment, also doubles as filename
        %   data_dir - data_dir directory of this experiment
        %   mfile - mfile that runs a session
        %
            [~, mfile] = fileparts(mfile);  % Remove extension
            obj.name = name;
            obj.data_dir = data_dir;
            obj.mfile = mfile;
                        
            if ~exist(obj.mfile)
                error('mfile: %s does not exist', mfile);
            end
            
            if ~exist(obj.dir)
                mkdir(obj.dir)
                fprintf('Created directory: %s\n', obj.dir);
            end
        end
        
    
        function s = dir(obj, subject)
        %function s = dir(obj, subject)
        %
        % If called without arguments, return the data_dir of this
        % experiment, if called with a subject object, return the directory
        % corresponding to that subject.
        %
            s = fullfile(obj.data_dir, obj.name);
            if ~(nargin < 2 || isempty(subject))
                s = fullfile(s, subject.name);
            end
        end
        
        
        function s = file(obj, subject)
        %function s = file(obj, subject)
        %
        % If called without arguments, return the filename of the mat-object
        % storing this experiment. If called with a subject object, return
        % the mat-object corresponding to that subject.
        %
            if nargin < 2, subject = []; end
            dir = obj.dir(subject);
        end
        
        
            
            
            
        
        

    end
end
