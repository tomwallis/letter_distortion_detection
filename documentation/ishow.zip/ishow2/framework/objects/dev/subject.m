classdef subject < handle
% classdef subject < handle
%
% A structure that manages data for one subject per experiment
%


    properties

        

    end


    methods

        function obj = subject(args)
        %function obj = subject(args)
        %
        % docstring

            

        end


    end
end
