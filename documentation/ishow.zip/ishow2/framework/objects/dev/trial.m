classdef trial < handle
% classdef trial < handle
%
% A trial object 

    properties

        properties

    end


    methods

        function obj = trial(args)
        %function obj = trial(args)
        %
        % docstring

            

        end


    end
end
