classdef dpixx_audio_port < audio_port
% classdef dpixx_audio_port < audio_port
%
% An audio-port object that uses the audio-card inside the Datapixx (or
% ViewPixx) hardware.
%
% An important difference between this implementation and the inbuilt one is
% this stores the waveforms in Datapixx RAM. This means that the waves
% properties does not contain the full wave-form, but instead a tuple, with
% the first value being the location in memory, and the second the number of
% samples of the sound.
    
    properties
        next_handle=0;
    end
       
    methods

        function obj = dpixx_audio_port(varargin)
        %function obj = dpixx_audio_port(varargin)
        %
        % Open de Datapixx audio-port
        %
        % The 'when' argument determines whether a sound plays immediately
        % when obj.play is called, (when = 'now'), or if it plays at the
        % next flip of the screen, (when = 'flip').
        %
            
            obj = obj@audio_port(varargin{:});
            obj = update_struct(obj, varargin{:}, 'ignore');
            
            % NOTE: can't debug further than this, come back here when at
            % work again
            if ~Datapixx('isReady')
                Datapixx('Open');
            end
            
            Datapixx('InitAudio');
            obj.set_volume(obj.volume);
            
        end

        
        function set_volume(obj, volume)
        %function set_volume(obj, volume)
        %
        % Set the global volume of the audio-port
        %
            obj.volume = volume;
            Datapixx('SetAudioVolume', obj.volume);
            Datapixx('RegWrRd');
        end
        
        
        function wave = create_beep(obj, name, frequency, duration, volume)
        %function wave = create_beep(obj, name, frequency, duration, volume)
        %
        % Create a monotonic beep and store it internally under label
        % 'name'. The 'frequency' variable can either be expressed in Hz, or
        % as a string referring to one of the named frequencies we use.
        %
        % In addition to the global object 'volume' it is possible to pass a
        % volume to the create_beep function, which will scale the beep's
        % volume relative to the other beeps.
        %
            wave = create_beep@audio_port(obj, name, frequency, duration, volume);
            h = Datapixx('WriteAudioBuffer', wave, obj.next_handle);
            obj.waves(name) = {obj.next_handle, length(wave)};
            obj.next_handle = h;

        end
        
        
        function play(obj, name)
        %function play(obj, name)
        %
        % Play the sound referenced by label 'name'. If the obj.when is set
        % to 'flip', the sound will start playing at the next flip of the
        % screen. If obj.when is set to 'now', the sound will start playing
        % immediatly.
        %
            data = obj.waves(name);
            h = data{1};
            n = data{2};
            
            Datapixx('SetAudioSchedule', 0, obj.sample_rate, n, 0, h, n);
            if strcmp(obj.when, 'now')
                Datapixx('StartAudioSchedule')
            elseif strcmp(obj.when, 'flip')
                PsychDataPixx('ExecuteAtFlipCount', [], ...
                              'Datapixx(''StartAudioSchedule'')');
            end
            Datapixx('RegWrRd');
        end
            
    end
end
