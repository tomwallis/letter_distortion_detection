classdef level_data < levels
% classdef level_data < handle
%
% An object that stores data in a hash-table and indexes it with a
% level-object. It allows for easy indexed storage, can enter a subset of a
% level and operate within it, an has customizable functions for how it
% stores and retrieves entries.

    properties
        
        data;                 % Data storage per param-combination
        current_subset;       % Enter a subset of the data
        
    end


    methods

        
        function obj = level_data(varargin)
        %function obj = level_data(varargin)
        %
        % Return a level_data object. The current selection is set to all.
        %
        %
            obj = obj@levels(varargin{:});
            obj.data = containers.Map();
            obj.select();
            obj.clear();
        end

        
        function display(obj)
        %function display(obj)
        %
        % The function that is called when an object is displayed on the
        % screen.
        %
            fprintf('level_data object with levels:\n')
            keys = obj.param.keys;
            vals = obj.param.values;
            for i = 1 : length(keys)
                fprintf('  %-16s%s\n', [keys{i} ':'], hashstring(vals{i}));
            end

            fprintf('\n')
        end
        
        
        function clear(obj)
        %function clear(obj)
        %
        % Assign every entry in obj an empty cell-array
        %
            keys = obj.all_keys();
            for i = 1 : length(keys)
                obj.data(keys{i}) = {};
            end
        end

        
        function fill(obj, f, varargin)
        %function fill(obj, f, varargin)
        %
        % Fill the level_data by calling function f on each entry, and
        % storing the results in the data hashtable. The values provided to
        % varargin are unzipped into the levels.map_fun function.
        %
        % see also: levels.map_fun
            keys = obj.all_keys;
            vals = obj.current_subset.map_fun(f, varargin{:});
            obj.set_items(keys, vals);
        end
        
        
        function set_items(obj, keys, vals)
        %function set_items(obj, keys, vals)
        %
        % Store values in the internal data hashtable.
        %
        % keys : either a string or cellstring of hash-keys.
        % vals : either a value or cell-array of values to store
        %
            if ischar(keys) && ~iscell(vals)
                keys = {keys};
                vals = {vals};
            end
            assert(numel(keys) == numel(vals), ...
                   'Length of keys and values does not match')
            
            for i = 1 : length(keys)
                obj.data(keys{i}) = vals{i};
            end
        end
        
            
        
        function out = all_keys(obj)
        %function all_keys(obj)
        %
        % Return all hash-keys for the current subset
            out = obj.current_subset.map_fun(@hashstring);
        end
        
        
        function select(obj, varargin)
        %function select(obj, varargin)
        %
        % Select a subset of all levels.
        %
            obj.current_subset = obj.subset(varargin{:});
        end
        

        function pairs = choose(obj, as_string)
        %function choose(obj, as_string)
        %
        % As levels.choose, but performed on the current-subset.
        %
            if nargin < 2, as_string = true; end
            pairs = obj.current_subset.choose(as_string);
        end

        
        function out = choose_data(obj)
        %function out = choose_data(obj)
        %
        % Chooses a random-entry and returns the data associated with it
        %
            s = obj.choose();
            out = obj.data(s);
        end
        
            
    end
end
