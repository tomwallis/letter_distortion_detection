classdef levels < handle
% classdef levels < handle
%
% A levels object manages different stimuli levels and provides methods for
% easily creating subsets of levels and representing them in different
% formats.
%

    properties
        param;           % Stores all the levels
        random;          % Specify which levels are random
        fixed;           % Specify which levels are fixed
    end
    
    methods

        
        function obj = levels(varargin)
        %function obj = levels(varargin)
        %
        % Return a level object.
        %
        % parameters:
        %  varargin - a series of key-value pairs specifying level-names and
        %             level-values. An additional third argument specifies
        %             if a level is random or not.
        %
        % see also:
        %   obj.add_levels
        %
        % example:
        %   foo = levels('bar', {1, 2, 3}, 'baz', {'blue', 'green'})
        %     Two levels, bar with 3 values, baz with 2 values. All levels
        %     are fixed.
        %   foo = levels({...
        %                   'abba', {1, 2, 3, 4}, true, ...
        %                   'baab', {'cow', 'horse', 'mule'}, ...
        %                   'abab', {@sin, @cos, @tan}})
        %     Three levels containing a number of different values. 'baab'
        %     and 'abab' are fixed levels, 'abba' is a random level.
        %
            obj.param = containers.Map();
            obj.add_levels(varargin{:});
        end

        
        function out = size(obj)
        %function out = size(obj)
        %
        % Return the size of the object
        %
            out = cellfun(@length, obj.param.values);
        end
        
        
        function display(obj)
        %function display(obj)
        %
        % The function that is called when an object is displayed on the
        % screen.
        %
            fprintf('levels object with levels:\n')
            keys = obj.param.keys;
            vals = obj.param.values;
            for i = 1 : length(keys)
                fprintf('  %-16s%s\n', [keys{i} ':'], hashstring(vals{i}));
            end

            fprintf('\n')
        end
        
        
        function show_entries(obj)
        %function show_entries(obj)
        %
        % Print all entry-combinations to the screen
            fprintf('all entries:\n')
            s = obj.map_fun(@hashstring);
            fprintf(['  ' strjoin(s, '\n  ') '\n']);
        end
        
        
        
        function out = n(obj)
        %function out = n(obj)
        %
        % Return the amount of combinations stored in this object
        %
            out = prod(obj.size());
        end
        
        
        function add_levels(obj, varargin)
        %function add_levels(obj, varargin)
        %
        % Add levels to this object. They must be provided as series of
        % 'level-name', {values} pairs. If any of these levels are random,
        % a third entry may be added after this pair. This entry may not a
        % string and must evaluate to true.
        %
        % examples:
        %  obj.add_levels('a', [1 2 3], 'b', [2 3 4])
        %   Create two levels, 'a' and 'b'. Both are fixed levels.
        %
        %  obj.add_levels('a', [1 2 3], true, 'b', [2 3 4])
        %   Create two levels, a is a random level while b is fixed.
        %
        %  obj.add_levels('a', [1 2 3], ...
        %                 'b', [2 3 4], true, ...
        %                 'c', [3 4 5], false)
        %   Create three levels, only b is random.
        %
            while ~isempty(varargin)
                key = varargin{1};
                val = varargin{2};
                if ~isset(val)
                    error('level values may not contain duplicates');
                end
                    
                if ~iscell(val)
                    if isnumeric(val)
                        val = num2cell(val);
                    elseif isstr(val)
                        val = {val};
                    else
                        error('Unrecognized value type');
                    end
                end
                    
                varargin(1:2) = [];
                obj.param(key) = val;
                is_fixed = true;
                
                if ~isempty(varargin) && ~ischar(varargin{1})
                    if varargin{1}
                        obj.random{end + 1} = key;
                        is_fixed = false;
                    end
                    varargin(1) = [];
                end
                if is_fixed
                    obj.fixed{end + 1} = key;
                end
            end
        end

        
        function mat = matrix(obj)
        %function mat = matrix(obj)
        %
        % Return all the levels in matrix-form, i.e., an n-dimensional cell
        % array where n equals the amount of levels, each dimension has
        % length equal to the amount of values in its corresponding level,
        % and each cell contains a cell-array of a unique combination of
        % level-values.
        %            
            mat = cell(obj.size);
            vals = obj.param.values;
            h = arbitrary_loop(obj.size);
            entry = cell(ndims(mat), 1);
            
            try
                while true
                    idx = num2cell(h());
                    for i = 1 : length(idx)
                        entry{i} = vals{i}{idx{i}};
                    end
                    mat{idx{:}} = entry;
                end
            catch e
                if ~strcmp(e.identifier, 'Iterator:StopIteration')
                    rethrow(e)
                end
            end                
        end
        
        
        function out = subset(obj, varargin)
        %function out = subset(obj, varargin)
        %
        % Return a new levels-object that is a subset of this one. Subsets
        % are selected by name-value pairs. Any level that occurs in this
        % object that is not named is included fully in the new object.
        %
        % If the set of values to select for a certain key is empty, that
        % key is not included in the returned levels-object.
        %
            temp = containers.Map(obj.param.keys, obj.param.values);
            for i = 1 : 2 : length(varargin)
                % Extract param from obj.param
                key = varargin{i};
                new_vals = varargin{i + 1};
                
                if isempty(new_vals)
                    temp.remove(key);
                    continue
                end
                
                if ~iscell(new_vals)
                    if ischar(new_vals)
                        new_vals = {new_vals};
                    elseif isnumeric(new_vals)
                        new_vals = num2cell(new_vals);
                    else
                        error('I do not know what you are trying to do')
                    end
                end
                
                % Check if key and values occur in this levels-object
                if ~obj.param.isKey(key)
                    error('Level-name: %s does not exist', key);
                end
                
                vals = obj.param(key);
                if iscellstr(new_vals) && ~all(ismember(new_vals, vals)) || ...
                    ~all(ismember(cell2mat(new_vals), cell2mat(vals)))
                    error('A value in %s does not occur', key);
                end
                
                % Overwrite entry in temp
                temp(key) = new_vals;
            end
            
            % Create new levels object
            keys = temp.keys;
            vals = temp.values;
            argin = {};
            for i = 1 : length(keys)
                argin{end + 1} = keys{i};
                argin{end + 1} = vals{i};
                if ismember(keys{i}, obj.random)
                    argin{end + 1} = true;
                end
            end
            out = levels(argin{:});
        end

        
        function pairs = choose(obj, as_string)
        %function val = choose(obj, as_string)
        %
        % Return one series of level-values pairs by randomly choosing from all
        % the random levels. All the non-random levels *must* contain only 1
        % value or an error will be thrown.
        %
        % If as_string is true (default), returns a hash-string, otherwise
        % returns a cell-array of name-value pairs.
        %
            if nargin < 2, as_string = true; end;
            
            keys = obj.param.keys;
            vals = obj.param.values;
            pairs = {};

            for i = 1 : length(keys)
                key = keys{i};
                val = vals{i};
                if ismember(key, obj.random)
                    val = choose(val, 1);
                elseif ismember(key, obj.fixed)
                    if length(val) > 1
                        error(['A fixed level with more than 1 value was ' ...
                               'encountered'])
                    end
                else
                    error('An unclassified level has been encountered')
                end
                pairs(end + 1 : end + 2) = {key, val{1}};
            end
            if as_string
                pairs = hashstring(pairs);
            end
        end
        
        
        function h = iter(obj)
        %function h = iter(obj)
        %
        % Return an iterator that returns a set of entries from the matrix
        % representation of the levels every time its called. When iteration
        % is done, an error is raised with identifier
        % "Iterator:StopIteration".
        %
            h = iterate({obj.matrix{:}});
        end
        
        
        function vec = pairs_cell(obj)
        %function vec = pairs_cell(obj)
        %
        % Return all the combinations of levels as a cell array containing
        % cell-arrays of 'name'-value series.
        %
            vec = {obj.matrix{:}};
            keys = obj.param.keys();
            vec = cellfun(@(vals) obj.as_pairs(keys, vals), vec, ...
                          'UniformOutput', false);
        end
        
        function vec = my_pairs(obj)
        %function vec = my_pairs(obj)
        %
        % Return a key-value series describing this levels object.
        %
            vec = cell(obj.param.Count * 2, 1);
            vec(1 : 2 : end) = obj.param.keys;
            vec(2 : 2 : end) = obj.param.values;
        end
        
        
        function h = pairs_iter(obj)
        %function h = pairs_iter(obj)
        %
        % Like obj.iter, but instead each time h is called, a series of
        % name-value pairs are returned instead of just the values.
        %
            h = iterate(obj.pairs_cell());
        end
        
        
        function out = map_fun(obj, f, static, pairs_mode)
        %function out = map_fun(obj, f, static, pairs_mode)
        %
        % Loop through all the combinations of levels and pass their input
        % to f. Each time f is called, all the arguments in static are
        % unzipped into its arguments, in addition to all the arguments in 1
        % entry of level-combinations.
        %
        % If pairs_mode is provided (defaults to true) the arguments stored
        % in the levels object are provided as series of 'name'-value pairs,
        % otherwise, only the values are passed.
        %
            if nargin < 3, static = {}; end;
            if nargin < 4, pairs_mode = true; end
            
            
            if pairs_mode
                next = obj.pairs_iter();
            else
                next = obj.iter();
            end
            
            out = cell(obj.n, 1);
            for i = 1 : obj.n
                entry = next();
                out{i} = f(static{:}, entry{:});
            end
        end
    end

    
    
    methods (Static = true)
        
        
        function pairs = as_pairs(names, values)
        %function pairs = as_pairs(names, values)
        %
        % Return names and values as a series of pairs
        %
            pairs = cell(2 * length(names), 1);
            pairs(1 : 2 : end) = names;
            pairs(2 : 2 : end) = values;
        end
                    
    end
    
end

