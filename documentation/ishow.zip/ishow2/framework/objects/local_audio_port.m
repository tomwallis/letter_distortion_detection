classdef local_audio_port < audio_port
% classdef local_audio_port < audio_port
%
% An audio-port object that the machines inbuilt audio-port (as opposed to
% the Datapixx inbuilt one). This is usefull for debugging purposes, but
% does not offer the same level of flip-synchronization accuracy as the
% datapixx_audio_port object.

    properties

        h;                % Psychtoolbox handle to audio-port
        
    end


    methods

        function obj = local_audio_port(varargin)
        %function obj = local_audio_port(varargin)
        %
        % Create, open, and return a local_audio_port object
        %
        % The local audio-port has a sampling rate that cannot be
        % changed. We extract it from the info and store it internally. The
        % Datapixx audio-port can be set to different sampling rates. Be
        % aware of this difference.
        %
        % This object can only play sounds now, never at flip. The parameter
        % exists though, so this doesn't break when used for debugging.
        %
            obj = obj@audio_port(varargin{:});
            obj.h = PsychPortAudio('Open', [], [], 0, [], 1);
            
            info = obj.info;
            obj.sample_rate = info.SampleRate;
            
        end
        
        function info = info(obj)
        %function info(obj)
        %
        % Return information about the device
            
            info = PsychPortAudio('GetStatus', obj.h);
        
        end
        
        function set_volume(obj, volume)
        %function set_volume(obj, volume)
        %
        % Try to change the global volume setting for all sound
        % creation. Allow this only if the internal sound-storage is still
        % empty. We can only create sounds with a certain volume, not adjust
        % this volume later in processing
            
            if ~isempty(obj.waves)
                error('Cannot adjust volume after creating sounds');
            end
            
            obj.volume = volume;
        end
        
        
        function h = play(obj, name)
        %function h = play(obj, name)
        %
        % Play the sound referenced by label 'name'. Returns the handle to
        % the currently playing sound, which can be used to stop playback
        % before it finishes.
        %
            
            PsychPortAudio('FillBuffer', obj.h, obj.waves(name));
            h = PsychPortAudio('Start', obj.h, 1, 0 , 1);
            
        end
        
    
        function delete(obj)
        %function delete(obj)
        %
        % When deleting, make sure to close the port
            
            PsychPortAudio('Close')
        end
    end
end
