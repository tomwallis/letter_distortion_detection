classdef window < handle
% classdef window < handle
%
% The window-object which collects the properties and manages the functions
% that involve windows.

    properties
        type;                % Type of monitor (i.e. color, gray, etc.)
        textures = [];       % List of textures defined on this window
        h;                   % psychtoolbox handle
        rect;                % rect describing position/size of window
        bg_color = 0.5;      % background color        
        framerate;           % The refresh rate of the window in Hz
        resolution;          % Resolution of the window in pixels
    end

    methods

%--------------------------------- General ------------------------------------        
        
        function obj = window(type, varargin)
        %function obj = window(type, varargin)
        %
        % Initialize a window-object of a certain type, and pass all
        % varargin to its initialization function.
            
            obj = update_struct(obj, varargin{:}, 'ignore');
            
            switch lower(type)
              case 'crt_gray'
                [h rect] = crt_datapixx_gray(varargin{:});
              case 'debug'
                [h rect] = open_debug_window(varargin{:});
              case 'lcd_gray'
                [h rect] = lcd_viewpixx_gray(varargin{:});    
              otherwise
                error('Unrecognized window type: %s', type);
            end
            
            obj.h = h;
            obj.rect = rect;
            obj.framerate = Screen('FrameRate', obj.h);
            res = Screen('Resolution', obj.h);
            obj.resolution = [res.width res.height];
        end
        
        
        function delete(obj)
        %function delete(obj)
        %
        % Close the Psychtoolbox window
            
            Screen('Close', obj.h);
        end

        
        function S = info(obj)
        %function S = info(obj)
        %
        % Return a structure containing a lot of info on this window. This
        % calls PsychDataPixx('GetStatus'), which does not always return
        % correctly. Repeated calling of this function might not get the
        % same results.
        %            
        %
            S = Screen('GetWindowInfo', obj.h);
            P = PsychDataPixx('GetStatus', obj.h);
            if isstruct(P)
                S = update_struct(S, P, 'add');
            end
            
        end
        
    
%----------------------------- Texture Creation -------------------------------
        
        function tex = make_texture(obj, img)
        %function tex = make_texture(obj, img)
        %
        % Convert an image to a texture, and store its handle
            
            tex = Screen('MakeTexture', obj.h, img, [], [], 1);
            obj.textures(end + 1) = tex;
            
        end

       
        function tex = make_mask_texture(obj, mask, varargin)
        %function tex = make_mask_texture(obj, mask, varargin)
        %
        % Create a texture used for masking other stimuli. This is done by
        % storing the background color in its image-layer, and placing the
        % mask in its alpha-layer.
            
            if isstr(mask)
                cmd = ['distrib_' mask];
                if exist(cmd) == 2
                    cmd = str2func(cmd);
                    mask = cmd(varargin{:});
                else
                    error('Distribution %s not found', cmd);
                end
            end
            
            img(:, :, 1) = obj.bg_color * ones(size(mask));
            img(:, :, 2) = mask;

            tex = obj.make_texture(img);
        
        end
                
%---------------------------------- Drawing -----------------------------------

        function set_blend(obj, src, dest)
        %function set_blend(obj, src, dest)
        %
        % Set the alpha-blending factors. The src value determines by which
        % factor the pixels in the image are scaled, and the dest determines
        % by which factor the pixels in the destination are scaled.
        %
        % When drawing, the new value of a pixel equals:
        % src * img_pixel + dest * dest_pixel
        %
        % Calling this empty resets the blending to simple 'overwrite'
        % drawing.
        %
        % Possible values for src and dest:
        %   GL_ONE - equals 1
        %   GL_ZERO - equals 0
        %   GL_SRC_ALPHA - use the alpha-layer from the image
        %   GL_DEST_ALPHA - use the alpha-layer from the destination
        %   GL_ONE_MINUS_SRC_ALPHA - use 1 minus image alpha-layer
        %   GL_ONE_MINUS_DEST_ALPHA - use 1 minus destination alpha-layer
        %
        % For example:
        %   src = GL_ONE, dest = GL_ZERO: 
        %      normal 'overwrite' drawing
        %   src = GL_SRC_ALPHA, dest = GL_ONE_MINUS_SRC_ALPHA:
        %      transparency drawing, where the alpha layer of the image 
        %      determines the opacity at which it is drawn
        %
            if nargin < 2
                src = GL_ONE;
                dest = GL_ZERO;
            end
            Screen('BlendFunction', obj.h, src, dest);
        end
        
        
        function draw(obj, textures, contrast, rects)
        %function draw(obj, textures, contrast, rects)
        %
        % Draw the provided textures on the window specified by h_win at the
        % locations specified by rects. Providing a contrast value draws the
        % textures at the specified contrast, with 1 being maximum, and 0 being
        % minimum.
        %
        % When specifying locations via the rects parameter, you can either
        % leave it empty, and all textures will be drawn centered, provide 1
        % rect vector at which all the textures will be drawn, or provide a
        % matrix where each column is seen as 1 rect, and the matrix must have
        % the same amount of columns as there are textures.
        %
        % This function uses alpha-mapping to perform the contrast adjustments,
        % this means that if your image contains an alpha-layer, this function
        % might not perform as you might intend.
        %
        % parameters
        %  textures - vector of texture handles
        %  contrast - global contrast at which to draw all textures
        %  rects - drawing locations for the textures
        %
            if nargin < 3
                contrast = 1;
            end

            if nargin < 4
                rects = [];
            end

            obj.set_blend(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            Screen('DrawTextures', obj.h, textures, [], rects, [], 1, contrast);
            obj.set_blend();

        end
        
        function draw_additive(obj, textures, contrast, rects)
        %function draw_additive(obj, textures, contrast, rects)
        %
        % Draw a set of textures on the window, adding their values to the
        % already existing value of the screen. When multiple textures are
        % provided, they are summed together with the destination values to
        % produce the resulting image.
        %
        % If the PsychToolbox window has been properly initialized as a 16-bit
        % or 32-bit version, negative textures are possible. This setting is
        % essential for a lot of the demos, which will not work on normal 8-bit
        % mode.
        %
        % It is faster to draw multiple textures in one go, than to call this
        % function multiple times.n
        %
        % parameters:
        %  textures - vector of texture-handles
        %  rects - a matrix in which each column specifies one rect
        %
        % If no rects are provided, this is set to the empty matrix, which
        % results in all textures being drawn centered.
        %
            if nargin < 3
                contrast = 1;
            end
            
            if nargin < 4
                rects = [];
            end
            
            obj.set_blend(GL_SRC_ALPHA, GL_ONE);
            Screen('DrawTextures', obj.h, textures, [], rects, [], 1, ...
                contrast);
            obj.set_blend();
        end
        
        
        function draw_at_contrast(obj, textures, contrast, rects)
        %function draw_at_contrast(obj, textures, contrast, rect)
        %
        % Patricks draw_at_contrast changed-function: document better
        %
            if nargin < 4
                rects = [];
            end
            
            obj.set_blend(GL_SRC_ALPHA, GL_ONE);
            Screen('DrawTextures', obj.h, textures, [], rects, [], 1, ...
                   contrast);
            obj.set_blend();
        end

        
        function draw_mask(obj, mask, rect, contrast)
        %function draw_mask(obj, mask, rect, contrast)
        %
        % Use a texture generated by make_window_texture to apply a windowing
        % of on an area of the screen. This step should take place after all
        % the relevant signals have been drawn. This then blends the
        % destination with the background color, depending on the values of the
        % window.
        %
        % Additionally, the value of contrast can apply a global scaling of the
        % contrast. This is useful for fading a stimulus in and out, while
        % maintaining the spatial distribution. You can specify the timecourse
        % as values between 0 and 1 (0 = no signal, 1 = signal at specified
        % contrast) and passes these values to the contrast parameter.
        %
        % If rect is unspecified, the masking will occur in the center of the screen
        %
        %
        % parameters:
        %  mask - handle to the windowing texture
        %  rect - the rect specifying where to mask
        %
        % see also: window.set_blend

            if nargin < 3
                rect = [];
            end
            
            if nargin < 4 || isempty(contrast)
                contrast = 1;
            end
            
            obj.set_blend(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
            Screen('DrawTexture', obj.h, mask, [], rect, [], 1, contrast);
            obj.set_blend();

        end
        
        
        function draw_text(obj, msg, pos, wrap, color)
        %function draw_text(obj, msg, pos, wrap, color)
        %
        % Draw text on the screen.
        %
        % parameters:
        %  msg - string containing message, \n will work as a line-break
        %  pos - tuple of locations, defaults to {'center', 'center'}
        %  wrap - max line length before automatic wrapping, defaults to 300
        %  color - color of the text, defaults to 0 (i.e., black)
        %
        % see also: DrawFormattedText
        %
            if nargin < 3 || isempty(pos)
                pos = {'center', 'center'};
            end
            
            if nargin < 4 || isempty(wrap)
                wrap = 300;
            end
            
            if nargin < 5 || isempty(color)
                color = 0;
            end
            
            DrawFormattedText(obj.h, msg, pos{:}, color, wrap);
        end

        
        function clear(obj, flip)
        %function clear(obj, flip)
        %
        % Clear the screen, if flip is provided and is true, the screen is
        % flipped as well.
        %
            Screen('FillRect', obj.h, obj.bg_color);
            if nargin > 1 && flip
                obj.flip;
            end
        end
        
           

%------------------------------- Flips and Trials -----------------------------

        function t = flip(obj)
        %function flip(obj)
        %
        % Flip the window
            
            %NOTE: Here we should handle checking for missed flips etc.
            [VBL_t, onset, t, missed, pos] = Screen('Flip', obj.h);
        end


        function empty_flips(obj, n)
        %function empty_flips(obj, n)
        %
        % Empty the screen and flip n times
        %
            
            for i = 1 : n
                Screen('Flip', obj.h);
            end
            
        end
        

        function pause_trial(obj, listener, varargin)
        %function pause_trial(obj, listener, varargin)
        %
        % Clear the screen and wait for an interupting listener object to
        % give a response. The exact content of the response is
        % ignored. After pausing is done, the screen is cleared again.
        %
        % varargin can be used to pass parameters that will be passed to
        % obj.draw_text to display a message.
        %
        % see also: obj.draw_text
        %
            if ~listener.does_interrupt
                error(['You can only run a pause_trial with an interrupting ' ...
                       'response-listener. If you want to wait for a fixed ' ...
                       'time, use empty_flips instead'])
            end
            
            obj.clear;
            
            % If a message is provided, draw it to the screen
            if length(varargin) > 0
                obj.draw_text(varargin{:});
            end
            obj.flip;

            % Wait for a response
            listener.start();
            while true
                try 
                    listener.check();
                catch e
                    if ~strcmp(e.identifier, 'iShow:ResponseInterrupt')
                        rethrow(e)
                    end
                    break
                end
            end            
            obj.clear(true);

        end
    end
end

