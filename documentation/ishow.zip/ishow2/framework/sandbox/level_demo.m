% A demonstration of how levels and level_data objects work, and how they
% can easily be used to generate and manage textures for different stimulus
% parameters.
%

%% Defining a levels object
% On an explanation how to create a levels-object see:
% help levels
% help levels.add_levels
%
lvls = levels('frequency', [10, 20, 40], ...
              'theta', [.1, .2, .4], ...
              'phase', [0, .2, .4], true)

% We have just defined a levels-object that describes three different
% stimulus levels that we are interested in, namely the frequency, contrast,
% and phase of a grating. Additionally, we have set the phase to random by
% including a 'true' behind its definition.
%
% You can inspect all the levels by displaying it on the screen. If you want
% to look at all the seperate level combinations, call:

lvls.show_entries();
lvls.size
lvls.n


%% Creating a level_data for this level
% A level_data object manages data via a levels object. We want to generate
% textures based on the levels we stipulated, and we want to store those
% textures somewhere, so we create a level_data object.
%

dat = level_data(lvls);

% Now we can fill the data. This means we have to pass it a function, and it
% will call this function on each possible combination of level-entry, and
% store the result of that function internally.

dat.fill(@grating_sine);

% dat.fill calls the grating_sine function for every entry that exists in
% lvls. Unzipping its contents into the grating_sine function, and since the
% grating_sine function is designed to use name-value inputs, we generate 3
% * 3 * 3 = 27 different gratings, one for each combination possible in
% levels.

% This way, however, we can only pass arguments to grating_sine that we
% define in levels. All other arguments have to be the default as defined in
% grating_sine. But what if we want all our images to have a size of
% 512x512? There are two ways around this:
% 1. Add a 'size' level into the lvls object with only 1 value: [512 512]
% lvls.add_levels('size', {[512 512]});
% 
% CAREFUL: in the above line of code we added the size as {[512 512]}. If we
% had ommited the curly braces, levels would have thought we were supplying
% two values for 'size'.
%
% 2. Pass a size argument inside the function call:

dat.fill(@(varargin) grating_sine('size', [512 512], varargin{:}));

