function screen_saver(monitor,bg_color, clut)

if nargin <1
    error('at least specify the monitor please!')
end
if nargin < 2
    bg_color = 0.1;
end
if nargin < 3
    clut = linspace(0,1,2^14)';
end

% Open onscreen window
win = window(monitor, 'bg_color', bg_color, 'clut', clut);


button_stop = listener_buttonbox('does_interrupt', true);
%keyb_stop = listener_keyboard('does_interrupt', true);

% Open onscreen window on screen with maximum id:
screen_id=max(Screen('Screens'));

screen_res = Screen('Resolution', screen_id);
noisesize = [screen_res.height, screen_res.width];

% Hide the mouse cursor
HideCursor(screen_id);

try
    button_stop.start();
    %keyb_stop.start();
    
    % Main stimulus drawing loop:
    for i = 1:100
        noisematrix = rand(noisesize) * 2 - 1;
        % Convert Matlab 'noisematrix' to 16 bpc floating point noise texture:
        noisetex(i) = win.make_texture(noisematrix);
        
    end
    
    while true
        contrast = 0;
        for i = 1:10000
            contrast = contrast + 1/10000;
            win.draw_at_contrast(noisetex(randi(length(noisetex))), ...
                michelson_to_scale(contrast, bg_color))
            win.flip();
            
            win.draw_at_contrast(noisetex(randi(length(noisetex))), ...
                -michelson_to_scale(contrast, bg_color))
            win.flip();
            %keyb_stop.check();
            button_stop.check();
        end
    end
    
catch e
    Screen('Close', noisetex);
    ShowCursor;
    if ~strcmp(e.identifier, 'iShow:ResponseInterrupt')
        rethrow(e)
    end   
end

end
