%% demo_002: The example from the paper
% in this demo we show the whole analysis, which was presented as an
% example in the paper Schuett, Harmeling, Macke and Wichmann (2014)

% we begin by reading the data.
