%% demo_004 statistical tests for psychometric functions
% In this demo we will fit multiple different psychometric functions and
% see whether they differ. 

%% prepare results from psignifit
%As an example we use simulated data which comes with the toolbox.

% first we set our options, which we reuse for all the datasets:
% The data comes from a 2AFC experiment
options.expType     = '2AFC';
% We fit a logistic function in this case.
options.sigmoidName = 'logistic';  

% load the data and fit each dataset with psignifit
% first group
for i = 1:5
    % the file contains a nx3 matrix data in the right format
    load (fullfile('exampleData',sprintf('data_1_000%d',i))) %load file
    
    % fit and put into ith part of the struct result_1
    result_1(i) = psignifit(data, options); 
end

% second group
for i = 1:5
    % the file contains a nx3 matrix data in the right format
    load (fullfile('exampleData',sprintf('data_2_000%d',i))) %load file
    
    % fit and put into ith part of the struct result_1
    result_2(i) = psignifit(data, options); 
end


%% meanTest
% With meanTest you can compare two sets of psychometric functions to test
% the whether and how much they differ in a specific parameter

% as the prime example we test wheter group 1 and group 2 had different
% thresholds. The threshold is the first parameter, thus the 1 in the call.
[p,diff,diffCI] = meanTest(result_1,result_2,1);

% We receive 3 values:
% p:
%An analogon to a two sided p value from classical hypothesis tests
% 2 times the posterior probability to get the other sign than estimated
% We truncate this value at .0001, which is thus the least value you can
% get.
p
% diff:
%An estimate for the sice of the difference. In absolute value.
diff
% diffCI:
%A 95% confidence interval for the difference. 
diffCI

% In our example the p value is very small (<=.0001) indicating that we are
% very sure that the two groups differ.
% The estimate for the difference with the confidence interval tells us
% that the difference between the two groups is roughly 1.53 and we are
% confident that it is between 1.5727 and 1.4141. The negative sign
% indicates that the parameter value of the first group is smaller than the
% one of the second.

% Note that this test does not include an estimate for the differences
% between measurements in a group. Thus generalization out of the measured
% sample are not tested with this.



%% meanTestPaired
% This test compares two matched samples of psychometric functions to test
% whether they differ in a specific parameter.

[p,diff,diffCI] = meanTestPaired(result_1,result_2,1);

% We receive 3 values:
% p:
%An analogon to a two sided p value from classical hypothesis tests
% 2 times the posterior probability to get the other sign than estimated
% We truncate this value at .0001, which is thus the least value you can
% get.
p
% diff:
%An estimate for the sice of the difference. In absolute value.
diff
% diffCI:
%A 95% confidence interval for the difference. 
diffCI

% In our example the p value is very small (<=.0001) indicating that we are
% very sure that the two groups differ.
% The estimate for the difference with the confidence interval tells us
% that the difference between the two groups is roughly 1.49 and we are
% confident that it is between 1.5723 and 1.4144.

% Note that this test does not include an estimate for the differences
% between measurements in a group. Thus generalization out of the measured
% sample are not tested with this.


%% equalityTest
% this test calculates a Bayesfactor, which discribes the evidence that
% multiple psychometric functions share parameters. This is
% especially usefull to check whether some group you want to pool is
% actually uniform.

% as an example, we can test whether our two groups are actually uniform:

% First we check whether the threshold might be the same in all functions
% we begin with first group
equalityTest(result_1,1)
% The result is 0.3630 which is a small factor smaller than 1 indicating
% that we found a tiny bit of evidence against the equality of the
% thresholds

% now the second group
equalityTest(result_2,1)
% The result is 530.8001, which is a large factor larger than 1, which
% means that we found a lot of evidence in favor of equal thresholds in
% this group.


% similarly we can also test whether they are equal in multiple parameters
