function Bayesfactor = equalityTest(result,dim)
% performs a Bayesfactor test whether the functions have equal values
% on some parameters
%function equalityTest(result,dim)
% result should be a struct with multiple entries for the functions to test
% and dim a vector of numbers between 1 and 5 for the dimensions which are
% to be tested
% dim defaults to 1 -> a test whether the thresholds are the same
%
% The Bayesfactor is the factor in favor of equal parameters. Larger Values
% than 1 indicate that it is more likely that they are the same than that
% they are different.
%
% For a more detailed explanation for the logic and calculations behind
% this test refer to
%
% Heiko Schuett, 2014-04-09

if ~exist('dim','var') || isempty(dim),      dim = 1; end

assert(isstruct(result),'result should be a struct of results from psignifit')
assert(numel(result)>=2,'You should pass at least 2 results, otherwise this test is useless')

opt=[result(:).options];
assert(all(strcmp(result(1).options.sigmoidName,{opt(:).sigmoidName})),'You fit your data with different sigmoids! This might invalidate the equality test');


%% calculate evidence for equal values on dims

% marginalize each result to the shared parameters
% and divide by the prior
margins = cell(size(result));
weights = cell(size(result));
X       = cell(size(result));
for ires = 1:numel(result)
    if length(dim)>1
        [margins{ires},X{ires},weights{ires}] = marginalize(result(ires),dim);
    else
        [margins{ires},X{ires}{1},weights{ires}] = marginalize(result(ires),dim);
    end
    %divide out prior (for all but the first result)
    if ires>1
        for idim = dim
            if length(dim)>1
            switch idim
                case 1
                    x = result(ires).X1D{idim}(:);
                case 2
                    x = reshape(result(ires).X1D{idim},1,[]);
                case 3
                    x = reshape(result(ires).X1D{idim},1,1,[]);
                case 4
                    x = reshape(result(ires).X1D{idim},1,1,1,[]);
                case 5
                    x = reshape(result(ires).X1D{idim},1,1,1,1,[]);
            end
            priorValues   = result(ires).options.priors{idim}(x);
            margins{ires} = bsxfun(@rdivide, margins{ires}, priorValues);
            else
                priorValues   = result(ires).options.priors{idim}(result(ires).X1D{idim}');
                margins{ires} = margins{ires}./priorValues;
            end
        end
    end
end



%% multiply marginal distributions to obtain evidence for equal parameters

%the first result is taken as the grid for the evaluation
X_all = cell(length(dim),1);
xes   = cell(length(dim),1);
[X_all{:}]= ndgrid(X{1}{:});

% as prior on the shared parameters we take the prior of the first result
% (we skipped dividing out in the upper loop!


Posterior = squeeze(margins{1}.*weights{1});

% interpolation of the other results and multiplication

for ires = 2:numel(result)
    [xes{:}]  = ndgrid(X{ires}{:});
    Posterior = Posterior.*interpn(xes{:},squeeze(margins{ires}),X_all{:});
end
Posterior(isnan(Posterior))=0;

% calculate evidence as integral over Posterior

Bayesfactor = sum(Posterior(:));