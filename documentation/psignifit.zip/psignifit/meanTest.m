function [p,m,CI,xdiff,mdiff] = meanTest(result1,result2,dim,pCI)
% this function calculates the believe about the difference of the two
% means and a "p-value" for it to be 0
%function [p,m,CI]=meanTest(result1,result2,dim,pCI)
% p  = the p value
% m  = mean estimate for the difference
% CI = confidence interval for the difference
%
%
% you should provide a concatinated struct for each of the two groups in
% result1 and result2.(See demo_004)
% You may provide a confidence level for the confidence interval
% between 0 and 1 in pCI
% dim is the number of the dimension you want to compare. Defaults 
% to 1= threshold comparison

if ~exist('pCI','var') || isempty(pCI),     pCI = .95; end
if ~exist('dim','var') || isempty(dim),     dim = 1;   end

%alpha = (1-pCI)/2;
alpha = pCI;

% calculate mean distribution for result 1;
m1 = result1(1).marginals{dim};
x1 = result1(1).marginalsX{dim};
w1 = result1(1).marginalsW{dim};
for ires = 2:numel(result1)
    [m1,x1,w1] = addMarginals(m1,x1,w1,result1(ires).marginals{dim},result1(ires).marginalsX{dim},result1(ires).marginalsW{dim});
end
[m1,x1,w1] = prodMarginals(m1,x1,w1,1/length(result1));


% calculate mean distribution for result 2;
m2 = result2(1).marginals{dim};
x2 = result2(1).marginalsX{dim};
w2 = result2(1).marginalsW{dim};
for ires = 2:numel(result2)
    [m2,x2,w2] = addMarginals(m2,x2,w2,result2(ires).marginals{dim},result2(ires).marginalsX{dim},result2(ires).marginalsW{dim});
end

[m2,x2,w2] = prodMarginals(m2,x2,w2,1/length(result2));

% calculate difference of means

[mdiff, xdiff, wdiff] = addMarginals(m1,x1,w1,m2,-x2,w2);

% find m the mean estimate
m  = sum(mdiff.*xdiff.*wdiff);
% calculate p = 2 times the probability that the difference is of different
% sign than m
p  = sum(mdiff(xdiff <= 0) .* wdiff(xdiff <= 0));

p  = 2* min(p,1-p);   % 2 sided p-value 
p(p<.0001)= .0001;    % to avoid rounding errors

% 
% mdiff    = cumsum(mdiff.*wdiff);
% CIbinary = (mdiff > alpha) & (mdiff < 1-alpha);
% 
% startIndex = find(CIbinary, 1, 'first');
% if startIndex > 1
%     CI(1) = xdiff(startIndex - 1) + (alpha - mdiff(startIndex - 1)) / (mdiff(startIndex) - mdiff(startIndex - 1)) * (xdiff(startIndex) - xdiff(startIndex - 1));
% else
%     CI(1) = xdiff(startIndex);
% end
% 
% stopIndex = find(CIbinary, 1, 'last');
% if stopIndex < length(xdiff)
%     CI(2) = xdiff(stopIndex) + (1 - alpha - mdiff(stopIndex)) / (mdiff(stopIndex+1) - mdiff(stopIndex)) * (xdiff(stopIndex + 1) - xdiff(stopIndex));
% else
%     CI(2) = xdiff(stopIndex);
% end

% more exact version of confidence intervals
[~,order] = sort(mdiff,'descend');

Mass = mdiff.*wdiff;
MassSort = cumsum(Mass(order));
% find smallest possible percentage above confP
confP1      = min(MassSort(MassSort>alpha));
confRegionM = true(size(mdiff));
confRegionM(order(MassSort>confP1))=false;

% Now we have the confidence regions
% put the borders between the nearest contained and the first
% not contained point

% we move in from the outer points to collect the half of the
% leftover confidence from each side

startIndex=find(confRegionM,1,'first');
pleft = confP1-alpha;
if startIndex>1,
    CI(1) = (xdiff(startIndex)+xdiff(startIndex-1))/2;
    CI(1) = CI(1) + pleft/2/mdiff(startIndex);
else                CI(1) = xdiff(startIndex);                end
stopIndex=find(confRegionM,1,'last');
if stopIndex < length(xdiff)
    CI(2) = (xdiff(stopIndex)+xdiff(stopIndex+1))/2;
    CI(2) = CI(2) - pleft/2/mdiff(stopIndex);
else                     CI(2) = xdiff(stopIndex);            end
