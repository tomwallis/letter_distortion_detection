function [p,m,CI] = meanTestPaired(result1,result2,dim,pCI)
% a paired test for the difference between two sets of psychometric
% functions
%function [p,m,CI] = meanTestPaired(result1,result2,dim,pCI)
% p  = the p value
% m  = mean estimate for the difference
% CI = confidence interval for the difference
%
%
% you should provide a concatinated struct for each of the two groups in
% result1 and result2.(See demo_004)
% You may provide a confidence level for the confidence interval
% between 0 and 1 in pCI
% dim is the number of the dimension you want to compare. Defaults to 1=
% threshold comparison

%% init
if ~exist('pCI','var') || isempty(pCI),     pCI = .95; end
if ~exist('dim','var') || isempty(dim),     dim = 1;   end

alpha = (1-pCI)/2;

assert(numel(result1)==numel(result2),'For the paired test the number of functions in the two groups must be the same')

%% main calculation
% initialize result with first difference
[mAll,xAll,wAll] = addMarginals(result1(1).marginals{dim},result1(1).marginalsX{dim},result1(1).marginalsW{dim},result2(1).marginals{dim},-result2(1).marginalsX{dim},result2(1).marginalsW{dim}); 


for ires = 2:numel(result1)
    m1 = result1(ires).marginals{dim};      % probability of the marginal result1
    x1 = result1(ires).marginalsX{dim};     % value/place of the marginal result1
    w1 = result1(ires).marginalsW{dim};     % Integration weight result1
    m2 = result2(ires).marginals{dim};      % probability of the marginal result2
    x2 = result2(ires).marginalsX{dim};     % value/place of the marginal result2
    w2 = result2(ires).marginalsW{dim};     % Integration weight result2
    [mdiff,xdiff,wdiff] = addMarginals(m1,x1,w1,m2,-x2,w2);   % calculate difference marginal
    [mAll,xAll,wAll] = addMarginals(mAll,xAll,wAll,mdiff,xdiff,wdiff); % add difference to mean difference
end

[mAll,xAll,wAll] = prodMarginals(mAll,xAll,wAll,1/length(result1)); % divide by number of samples for mean instead of sum


m  = sum(mAll.*xAll.*wAll);
p  = sum(mAll(xAll <= 0) .* wAll(xAll <= 0));

p  = 2*min(p,1-p);  % two sided p value
p(p<.0001) = .0001;

mAll    = cumsum(mAll.*wAll);
CIbinary = (mAll > alpha) & (mAll < 1-alpha);

startIndex = find(CIbinary, 1, 'first');
if startIndex > 1
    CI(1) = xAll(startIndex - 1) + (alpha - mAll(startIndex - 1)) / (mAll(startIndex) - mAll(startIndex - 1)) * (xAll(startIndex) - xAll(startIndex - 1));
else
    CI(1) = xAll(startIndex);
end

stopIndex = find(CIbinary, 1, 'last');
if stopIndex < length(xAll)
    CI(2) = xAll(stopIndex) + (1 - alpha - mAll(stopIndex)) / (mAll(stopIndex+1) - mAll(stopIndex)) * (xAll(stopIndex + 1) - xAll(stopIndex));
else
    CI(2) = xAll(stopIndex);
end

