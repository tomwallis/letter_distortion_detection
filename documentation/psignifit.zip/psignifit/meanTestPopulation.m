function meanTestPopulation(results1,results2, dim)
% computes a gaussian population level generalization
% function meanTestPopulation(results1,results2, dim)

% input checks
assert(isstruct(results1),'Please pass result struct');
assert(isstruct(results2),'You need to pass a second result struct to compare to');
assert(isnumeric(dim) && ismember(dim,1:2),'Please pass a dimension (1 or 2 for threshold or width)');


%% generate grid for the mean and variance of the population

% find min and max of all data;
minData = min(results1(1).data(:,1));
maxData = max(results1(1).data(:,1));
minDist = min(results1(1).data(2:end,1)-results1(1).data(1:(end-1),1));
for ires = 1:numel(results1)
    minData = min(minData,min(results1(ires).data(:,1)));
    maxData = max(maxData,max(results1(ires).data(:,1)));
    minDist = min(minDist,min(results1(ires).data(2:end,1)-results1(ires).data(1:(end-1),1)));
end
for ires = 1:numel(results2)
    minData = min(minData,min(results2(ires).data(:,1)));
    maxData = max(maxData,max(results2(ires).data(:,1)));
    minDist = min(minDist,min(results2(ires).data(2:end,1)-results2(ires).data(1:(end-1),1)));
end

meanX = linspace(minData,maxData,1000);
stdX  = linspace(minDist,maxData-minData,1000);

%% calculate the (log-) likelihood

for ires = 1:numel(results1)