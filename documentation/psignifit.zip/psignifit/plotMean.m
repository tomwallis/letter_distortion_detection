function plotMean(results,dim,h,plotOptions)
% This function plots the posteriors of multiple results on one axis
% together with the posterior on the mean value. 

if exist('h','var') && ~isempty(h),     axes(h);                                      end
if ~exist('plotOptions','var'),         plotOptions           = struct;               end
assert(isstruct(plotOptions),'If you pass a option file it must be a struct!');

if ~isfield(plotOptions,'subjectColor'), plotOptions.subjectColor = [0,105/255,170/255]; end
if ~isfield(plotOptions,'meanColor'),    plotOptions.meanColor    = [0,105/255,170/255]; end
if ~isfield(plotOptions,'labelSize'),    plotOptions.labelSize    = 14;                  end
if ~isfield(plotOptions,'tufteAxis'),    plotOptions.tufteAxis    = true;                end

if ~isfield(plotOptions,'xLabel')
    switch dim
        case 1
            plotOptions.xLabel = 'threshold';
        case 2
            plotOptions.xLabel = 'width';
        case 3
            plotOptions.xLabel = 'lambda';
        case 4
            plotOptions.xLabel = 'gamma';
        case 5
            plotOptions.xLabel = 'sigma';
    end
end

cla;
hold on;

%% plot individual subjects
xmin = results(1).marginalsX{dim}(1);
xmax = results(1).marginalsX{dim}(end);
for ires = 1:length(results)
    plot(results(ires).marginalsX{dim}, results(ires).marginals{dim},'Color', plotOptions.subjectColor);
    if min(results(ires).marginalsX{dim}) < xmin
        xmin = min(results(ires).marginalsX{dim});
    end
    if max(results(ires).marginalsX{dim}) > xmax
        xmax = max(results(ires).marginalsX{dim});
    end
end

%% calculate and plot mean distribution 
m1 = results(1).marginals{dim};
x1 = results(1).marginalsX{dim};
w1 = results(1).marginalsW{dim};
for ires = 2:numel(results)
    [m1,x1,w1] = addMarginals(m1,x1,w1,results(ires).marginals{dim},results(ires).marginalsX{dim});
end
[m1,x1,w1]   = prodMarginals(m1,x1,w1,1/length(results));
meanEstimate = sum(m1.*x1.*w1);


plot(x1,m1, 'lineWidth',2,'Color', plotOptions.meanColor)

%% axis settings
xlabel(plotOptions.xLabel,'Fontsize',plotOptions.labelSize);
if plotOptions.tufteAxis
    tufteaxis([xmin,meanEstimate,xmax],[0,max(m1)]);
end