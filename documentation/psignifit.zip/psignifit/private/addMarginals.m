function [Msum,Xsum,Wsum] = addMarginals(M1,X1,W1,M2,X2,W2)
% this function convolves two 1-dimensional distributions to find the
% distribution of the sum of the two random variables
% function [Msum,Xsum,Wsum] = AddMarginals(M1,X1,W1,M2,X2,W2)

minValue = 10^-13;

%to check this compute what mean & variance should be
mean1    = sum(M1.*W1.*X1);
mean2    = sum(M2.*X2.*W2);
mean     = mean1+mean2;

X1x      = linspace(min(X1),max(X1),1000)';
W1x      = conv(diff(X1x),[.5,.5]);
M1x      = interp1(X1,M1,X1x,'linear',0);
X2x      = linspace(min(X2),max(X2),1000);
W2x      = conv(diff(X2x),[.5,.5]);
M2x      = interp1(X2,M2,X2x,'linear',0);

variance = sum(M1x.*W1x.*(X1x-mean1).^2) + sum(M2x.*W2x.*(X2x-mean2).^2);

% the reason for the interpolation
%variance2 = sum(M1.*W1.*(X1-mean1).^2) + sum(M2.*W2.*(X2-mean2).^2);
%disp(variance-variance2);

Xsum = linspace(min(X1)+min(X2),max(X1)+max(X2),2000); % places to evaluate the sum distribution at
Mat  = bsxfun(@minus,Xsum,X1x);                         % interpolation places
Mat  = interp1(X2,M2,Mat,'linear',0);                  % interpolate second function
Mat  = bsxfun(@times,Mat,M1x);                          % multiply with first probability density
Mat  = bsxfun(@times,Mat,W1x);                          % multiply with first integral mass

Msum = sum(Mat,1);                                     % "integrate" = sum up
Wsum = conv(diff(Xsum),[.5,.5]);                       % calculate weights for further sums...


Msum = Msum(:);
Xsum = Xsum(:);
Wsum = Wsum(:);

% remove very improbable parts
remove = (Msum.*Wsum<minValue);
Msum(remove) = [];
Wsum(remove) = [];
Xsum(remove) = [];


%% to check numerical issues 
mean_sum     = sum(Msum.*Wsum.*Xsum);
variance_sum = sum(Msum.*Wsum.*(Xsum-mean_sum).^2);
%disp((mean_sum-mean)./mean);
%disp((variance-variance_sum)./variance)
if abs((variance-variance_sum)./variance) > 10^-4 || abs((mean_sum-mean)./sqrt(variance))>10^-3
    warning('Numerically unstable convolution detected')
end