function L = likelihoodPopulaton(result,mean,std)
% calculates the likelihood for one result and and one grid on mean and
% std.
%function L = likelihoodPopulaton(result,mean,std)
% result = the result struct
% mean   = mean gridpoint values
% std    = std  gridpoint values

assert(isvector(mean),'mean gridpoints must be one dimensional')
assert(isvector(std), 'std must be one dimensional')

thresh = result.marginalsX{1};
thresh = linspace(min(thresh),max(thresh),250);

marg   = interp1(result.marginalsX{1},result.marginals{1},thresh);

mean   = reshape(mean  ,[],1);
std    = reshape(std   ,1 ,[]);
thresh = reshape(thresh,1 ,1,[]);
marg   = reshape(log(marg),1 ,1 ,[]);
%marg   = reshape(log(result.marginals{1}.*result.marginalsW{1}),1,1,[]);



L = bsxfun(@minus,thresh,mean);
L = bsxfun(@rdivide,L,std);
L = -.5.*L.^2;
L = bsxfun(@plus,L,marg);
L = bsxfun(@rdivide,exp(L),sqrt(2*pi).*std);
L = sum(L,3);



