function y = mygammaln(x)

y=gammaln(x);
end