function [M,X,W] = prodMarginals(M,X,W,k)
% this function computes the distribution of a random variable multiplied
% by a skalar

X = X .* k;
W = W .* abs(k);
M = M ./ abs(k);