function borders=setBorders2(sigmoid,data,cutoff)
%function Borders=setBorders2(sigmoid,data,cutoff)
% set borders by "walking away from MLE"
% cutoff is the maximum value you would accept at the border for
% likelihood/likelihood in log units (base e)

% set cutoff value default to -10
if ~exist('cuoff','var') || isempty(cutoff) || cutoff>=0
    cutoff=-20;
end

borders=zeros(4,2);

typeHandle=@(X,alpha,beta) getSigmoidValue(X,sigmoid,alpha,beta);

% find MLE
% do not to bad seed! Then fminsearch sometimes goes wrong!
% THIS IS A SERIOUS PROBLEM!!

% For gauss or similar things
% Threshold alpha = median of points measured
MLE(1)=median(data(:,1));
MLE(2)=1;
MLE(3)=1-max(data(:,2));
MLE(4)=min(data(:,2));
MLE=fminsearch(@(X) -logLikelihood(typeHandle,data,X(1),X(2),X(3),X(4)),MLE);

%evaluate at MLE for reference
MLEcell=num2cell(MLE);
valMLE=logLikelihood(typeHandle,data,MLEcell{:});


for id=1:length(MLE)
    % Do a divide & conquer to reach cutoff along dimension id
    % This was first done with a sekant method but for the largely
    % concave/convex functions one of the borders was never moved...
    
    % init
    Xcell1=MLEcell;
    val1=0;
    
    % catch lambda & gamma
    if id ==3
        Xcell2=MLEcell;
        Xcell2{id}=.6;
        val2=logLikelihood(typeHandle,data,Xcell2{:})-valMLE;
    elseif id ==4
        Xcell2=MLEcell;
        Xcell2{id}=.6;
        val2=logLikelihood(typeHandle,data,Xcell2{:})-valMLE;
    else
        Xcell2=MLEcell;
        Xcell2{id}=2*Xcell1{id};
        val2=logLikelihood(typeHandle,data,Xcell2{:})-valMLE;
        
        % make sure val2 is smaller than cutoff
        % in case val2 is above threshold we move x1 to that place
        while val2>cutoff
            Xcell1{id}=Xcell1{id};
            val1=val2;
            Xcell2{id}=2*Xcell2{id};
            val2=logLikelihood(typeHandle,data,Xcell2{:})-valMLE;
        end
    end
    
    Xtest=Xcell1;
    while abs(val2-val1)>.1
        % this should always be a positive change, because val1>val2 and
        % Xcell2{id} > Xcell1{id}
        % this is commented out because in concave functions the val2 is
        % never moved
        %Xtest{id}=Xcell1{id}+(cutoff-val1)*(Xcell2{id}-Xcell1{id})/(val2-val1);
        Xtest{id}=.5*(Xcell1{id}+Xcell2{id});
        valt=logLikelihood(typeHandle,data,Xtest{:})-valMLE;
        if valt>cutoff
            Xcell1{id}=Xtest{id};
            val1=valt;
        else
            Xcell2{id}=Xtest{id};
            val2=valt;
        end
    end
    
    borders(id,2)=.5*(Xcell1{id}+Xcell2{id});
    
    % same thing for lower bound
    
    Xcell1=MLEcell;
    val1=0;
    
    % catch lambda & gamma
    if id ==3
        Xcell2=MLEcell;
        Xcell2{id}=0;
        val2=logLikelihood(typeHandle,data,Xcell2{:})-valMLE;
    elseif id ==4
        Xcell2=MLEcell;
        Xcell2{id}=0;
        val2=logLikelihood(typeHandle,data,Xcell2{:})-valMLE;
    else
        Xcell2=MLEcell;
        % ONLY FOR STRICTLY POSITIVE VALUES
        Xcell2{id}=.5*Xcell1{id};
        val2=logLikelihood(typeHandle,data,Xcell2{:})-valMLE;
        
        % make sure val2 is smaller than cutoff
        % in case val2 is above threshold we move x1 to that place
        while val2>cutoff
            Xcell1{id}=Xcell1{id};
            val1=val2;
            Xcell2{id}=.5*Xcell2{id};
            val2=logLikelihood(typeHandle,data,Xcell2{:})-valMLE;
        end
    end
    
    Xtest=Xcell1;
    while abs(val2-val1)>.1
        % this should always be a positive change, because val1>val2 and
        % Xcell2{id} > Xcell1{id}
        % this is commented out because in concave functions the val2 is
        % never moved
        %Xtest{id}=Xcell1{id}+(cutoff-val1)*(Xcell2{id}-Xcell1{id})/(val2-val1);
        Xtest{id}=.5*(Xcell1{id}+Xcell2{id});
        valt=logLikelihood(typeHandle,data,Xtest{:})-valMLE;
        if valt>cutoff
            Xcell1{id}=Xtest{id};
            val1=valt;
        else
            Xcell2{id}=Xtest{id};
            val2=valt;
        end
    end
    
    borders(id,1)=.5*(Xcell1{id}+Xcell2{id});
    
end