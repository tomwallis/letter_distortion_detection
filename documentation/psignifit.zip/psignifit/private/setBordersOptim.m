function penalty=setBordersOptim(sigmoid,data,phi,corner)
%function penalty=setBordersOptim(sigmoid,data,phi,corner)
% this function gives the penalty for a parameter configuration
% phi=[alpha,beta]
% sigmoid MUST be the name of known distribution



switch corner
    case 1 % max(data) = threshold + high slope
           % -> sigmoid value at maximum of data =.5
           % -> slope there = 1 / minimal difference of two data points
        penalty=10000*(cdf(sigmoid,max(data(:,1)),phi(1),phi(2))-.5)^2;
        minDiff=min(diff(sort(unique(data(:,1)))));
        penalty=penalty+(pdf(sigmoid,max(data(:,1)),phi(1),phi(2))-1./minDiff)^2;
    case 2 % min(data) = threshold + high slope
           % -> sigmoid value at minimum of data =.5
           % -> slope there = 1 / minimal difference of two data points
        penalty=10000*(cdf(sigmoid,min(data(:,1)),phi(1),phi(2))-.5)^2;
        minDiff=min(diff(sort(unique(data(:,1)))));
        penalty=penalty+(pdf(sigmoid,min(data(:,1)),phi(1),phi(2))-1./minDiff)^2;
    case 3 % max(data) = threshold + low slope
           % -> sigmoid value at minimum of data =.5
           % -> slope there = .2 / datarange
        penalty=10000*(cdf(sigmoid,max(data(:,1)),phi(1),phi(2))-.5)^2;
        maxDiff=max(data(:,1))-min(data(:,1));
        penalty=penalty+(pdf(sigmoid,max(data(:,1)),phi(1),phi(2))-.2./maxDiff)^2;
    case 4 % min(data) = threshold + low slope
           % -> sigmoid value at minimum of data =.5
           % -> slope there = .2 / datarange
        penalty=10000*(cdf(sigmoid,min(data(:,1)),phi(1),phi(2))-.5)^2;
        maxDiff=max(data(:,1))-min(data(:,1));
        penalty=penalty+(pdf(sigmoid,min(data(:,1)),phi(1),phi(2))-.2./maxDiff)^2;  
end